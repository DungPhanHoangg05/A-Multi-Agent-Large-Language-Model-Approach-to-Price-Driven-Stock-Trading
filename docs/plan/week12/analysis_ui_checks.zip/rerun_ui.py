"""Kiểm lại đúng caller UI sau khi ghi rõ native/common Alpha và đơn vị giá."""
import hashlib
import json
from pathlib import Path
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f09'
for name in ('utils/analysis_ui.py','tests/analysis_ui/fixture.py'):
    py_compile.compile(str(ROOT/name),doraise=True)
results = json.loads((QA/'test_results.json').read_bytes())
for name,command in [('tests_analysis_ui_test_pages.log',[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests/analysis_ui','-p','test_pages.py','-v']),
                     ('analysis_ui.log',['node','--test','tests/js/analysis_ui.test.mjs'])]:
    result = subprocess.run(command,cwd=ROOT,capture_output=True)
    raw = result.stdout+b'\n'+result.stderr; (QA/name).write_bytes(raw)
    results[name].update(returncode=result.returncode,log_sha256=hashlib.sha256(raw).hexdigest())
    print(name,result.returncode,flush=True)
(QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
for name in ('chart','view'):
    subprocess.run(['node','--check',str(ROOT/f'static/js/analysis/{name}.js')],check=True,capture_output=True)
sys.exit(int(any(v['returncode'] for v in results.values())))
