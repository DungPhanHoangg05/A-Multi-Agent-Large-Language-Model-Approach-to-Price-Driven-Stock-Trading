"""Đóng QA UI mới theo log/source thật; không nâng browser hoặc scientific gate."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import unicodedata
import zipfile

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f09'
TARGET = ROOT/'docs/plan/week12/analysis_ui_checks.zip'


def binding(raw: bytes) -> dict:
    """Băm bytes để có thể kiểm lại sau checkout/merge."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def slug(text: str) -> str:
    """Anchor Unicode theo catalogue Markdown hiện có."""
    text = re.sub('<[^>]+>','',text).lower().replace(' ','-')
    return ''.join(c for c in text if c in '-_' or unicodedata.category(c)[0] in 'LN')


results = json.loads((QA/'test_results.json').read_bytes())
assert len(results) == 14 and all(v['returncode'] == 0 for v in results.values())
assert sum(v['tests'] for k,v in results.items() if k.startswith('tests_')) == 108
assert sum(v['tests'] for k,v in results.items() if not k.startswith('tests_')) == 18
for name,record in results.items():
    raw = (QA/name).read_bytes()
    assert binding(raw)['sha256'] == record['log_sha256'],name
    if name.startswith('tests_'):
        assert re.search(rb'\nOK\s*$',raw) and b'skipped=' not in raw,name
    else:
        assert re.search(rb'(?:#|\xe2\x84\xb9) fail 0',raw),name
compiled = json.loads((QA/'compiled.json').read_bytes())
syntax = json.loads((QA/'syntax.json').read_bytes())
assert compiled['count'] == 5 and len(syntax['js_files']) == 7
integrity = json.loads((QA/'integrity.json').read_bytes())
assert integrity['status'] == 'PASS_F09_INTEGRITY'
TARGET.touch(exist_ok=True)
docs = ['docs/plan/plan.md','docs/plan/week12/README.md','docs/plan/week12/final_paper_ui_plan.md',
        'docs/plan/week12/variant_serving_contract.md']
links = 0
for name in docs:
    path = ROOT/name
    for target in re.findall(r'(?<!!)\[[^]\n]*\]\(([^)\n]+)\)',path.read_text(encoding='utf-8')):
        if '://' in target or target.startswith('mailto:'): continue
        rel,_,anchor = target.partition('#')
        dest = (path.parent/rel).resolve() if rel else path
        assert dest.exists(),(name,target)
        if anchor:
            assert anchor in [slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$',dest.read_text(encoding='utf-8'),re.M)],(name,target)
        links += 1
readme,plan = ((ROOT/docs[i]).read_text(encoding='utf-8') for i in (1,2))
assert '- [x] F09' in readme and '| F09 | ☑ Hoàn tất |' in plan
for task in ('F10','F11','F12'):
    assert '- [ ] '+task in readme and '| '+task+' | ☐ Chưa bắt đầu |' in plan
files = sorted(set(subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).decode().splitlines()
    + subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT).decode().splitlines()))
files = [name for name in files if name != TARGET.relative_to(ROOT).as_posix()]
checks = {'status':'PASS_F09_OFFLINE_SCOPE','base_commit':'943b7b61','python_tests_passed':108,'dom_tests_passed':18,
    'new_page_api_tests':7,'new_dom_tests':12,'leakage_regressions':18,'native_parity_tests':11,
    'compiled':compiled,'javascript_syntax':syntax,'test_suites':results,
    'runtime':subprocess.check_output(['py','-3.13','--version']).decode().strip(),
    'node':subprocess.check_output(['node','--version']).decode().strip(),
    'source_bindings':{name:binding((ROOT/name).read_bytes()) for name in files},
    'new_query':'MWG 2026-07-02; ACTUAL_PROVIDER_ALL_SIX_REQUESTED_EIGHT_SLOTS; FIXTURE_HTTP_ONLY',
    'ui_scope':'FORM_ANALYZE_COMPARE_RESULT; BACKTEST_UI_F10_PENDING',
    'report_language':'VI_ONLY; UI_VI_EN',
    'initial_findings':['Test worker join30s was too short; changed test timeout to180s and reran full file',
        'Test assertion confused registry legacy URL with inline handler; now asserts event ownership',
        'Both native/common Alpha shown separately; heartbeat keeps report nodes and open decision details'],
    'browser_visual':'NOT_RUN_BROWSER_HOST_UNAVAILABLE; F11_PENDING','local_links':links,
    'checklist_synchronized':True,'integrity':integrity}
members = {'checks.json':(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()}
for name in (*results,'test_results.json','compiled.json','syntax.json','integrity.json','initial_pages.log',
             'run_checks.py','rerun_ui.py','rerun_dom.py','check_integrity.py','seal_checks.py'):
    members[name] = (QA/name).read_bytes()
members['manifest.json'] = (json.dumps({n:binding(raw) for n,raw in members.items()},indent=2)+'\n').encode()
with zipfile.ZipFile(TARGET,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in members.items(): archive.writestr(name,raw)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    for name,raw in members.items(): assert archive.read(name) == raw
print(json.dumps({'status':checks['status'],'python':108,'dom':18,'links':links,'members':len(members),
    'bound_files':len(files),'package':binding(TARGET.read_bytes())}))
