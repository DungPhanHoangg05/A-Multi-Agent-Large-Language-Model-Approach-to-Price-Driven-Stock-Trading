"""Đối soát nguồn scientific đã khóa và phép tách UI legacy, không chạy lại study."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f09'
DOC = ROOT/'docs/plan/week12'
BASE = '943b7b61'


def binding(raw: bytes) -> dict:
    """Giữ đúng byte, không chuẩn hóa bằng chứng scientific."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def old(name: str) -> bytes:
    """Đọc source trước task từ Git, không dùng file mới làm oracle."""
    return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)


with zipfile.ZipFile(DOC/'unified_analysis_results.zip') as archive:
    pins = {name:{k:v[k] for k in ('bytes','sha256')}
            for name,v in json.loads(archive.read('manifest.json'))['sources'].items()}
with zipfile.ZipFile(DOC/'final_evidence_snapshot.zip') as archive:
    snap = json.loads(archive.read('snapshot_manifest.json'))
    for name,expected in pins.items(): assert binding(archive.read(name)) == expected,name
    for group in ('frozen_packages','legacy_archives'):
        for name,expected in snap[group].items(): assert binding((ROOT/name).read_bytes()) == expected,name
changed = sorted(name for name,expected in pins.items() if binding((ROOT/name).read_bytes()) != expected)
assert changed == ['scripts/.gitattributes','templates/demo_new.html','templates/experiments.html',
                   'templates/output.html','utils/experiment_web.py','web_interface.py'],changed
release = ROOT/'outputs/revision/manuscript_unified_final_v1'
assert binding((release/'manifest.json').read_bytes()) == {'bytes':55249,'sha256':'8e5ce2a4ca6f3a52945047cb8e1e1e99e8c00dfcd959a6fc6cdadcd701013de9'}
manifest = json.loads((release/'manifest.json').read_bytes())
for name,expected in manifest['outputs'].items(): assert binding((release/name).read_bytes()) == expected,name
for name,expected in manifest['sources'].items(): assert binding((ROOT/name).read_bytes()) == expected,name
assert old('docs/plan/week12/serving_runner_checks.zip') == (DOC/'serving_runner_checks.zip').read_bytes()
assert old('docs/plan/week12/serving_resources_v1.json') == (DOC/'serving_resources_v1.json').read_bytes()
with zipfile.ZipFile(DOC/'serving_runner_checks.zip') as archive:
    f08 = json.loads(archive.read('checks.json'))['source_bindings']
for name in ('core/unified_methods.py','core/variant_registry.py','core/backtest_engine.py',
             'core/serving_runtime/providers.py','core/serving_runtime/service.py','core/serving_runtime/transport.py',
             'core/serving_runtime/quota.py','core/serving_runtime/resources.py','utils/serving_web.py',
             'templates/backtest.html','templates/experiments.html'):
    if name in f08:
        assert binding((ROOT/name).read_bytes()) == f08[name],name
    elif name in pins and name not in changed:
        assert binding((ROOT/name).read_bytes()) == pins[name],name
    else:
        assert old(name) == (ROOT/name).read_bytes(),name
css_checks,js_checks = [],[]
for name,asset in [('demo_new','legacy_form'),('output','legacy_output')]:
    source = old('templates/'+name+'.html').decode().replace('\r\n','\n')
    css = re.search(r'    <style>\n(.*?)    </style>',source,re.S)[1]
    assert css == (ROOT/f'static/css/analysis/{asset}.css').read_text(encoding='utf-8')
    css_checks.append(asset)
    if name == 'output':
        js = re.search(r'    <script>\n(.*?)    </script>',source,re.S)[1]
        js = js.replace('const T = {{ T | tojson }};', 'const T = JSON.parse(document.getElementById("legacy-config").textContent).messages;')
        js = js.replace('const LANG = {{ LANG | tojson }};', 'const LANG = JSON.parse(document.getElementById("legacy-config").textContent).language;')
        assert js == (ROOT/f'static/js/analysis/{asset}.js').read_text(encoding='utf-8')
        js_checks.append(asset)
before = ast.parse(old('web_interface.py').decode()); after = ast.parse((ROOT/'web_interface.py').read_text(encoding='utf-8'))
nodes = lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
before,after = nodes(before),nodes(after)
assert {name for name in before if before[name] != after[name]} == {'render_localized','output'}
result = {'status':'PASS_F09_INTEGRITY','base_commit':BASE,'u09_source_pins':729,'current_matches':723,
    'historical_snapshot_restores':729,'intentional_changed_pins':changed,
    'frozen_packages_unchanged':20,'legacy_archives_unchanged':30,'f05_outputs_unchanged':11,'f05_sources_unchanged':68,
    'f08_resources_and_qa_unchanged':True,'legacy_css_extracted_exact':css_checks,
    'legacy_output_js_extracted_exact_except_json_bootstrap':js_checks,
    'legacy_python_handlers_ast_unchanged_except':['render_localized','output'],
    'new_hosted_llm_calls':0,'new_market_calls':0,'new_hmm_student_bank_training':0,
    'native_rowwise_causal_gate':'FAIL','whole_system_causal_gate':'NOT_CERTIFIED',
    'browser_visual_status':'NOT_RUN_BROWSER_HOST_UNAVAILABLE; F11_PENDING'}
(QA/'integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
