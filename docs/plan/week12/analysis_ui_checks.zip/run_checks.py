"""Hồi quy đúng caller UI/result, native và PIT; source cố định trong khi worker chạy."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f09'
sources = sorted(set(subprocess.check_output(['git','diff','--name-only','--','*.py'],cwd=ROOT).decode().splitlines()
    + subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.py'],cwd=ROOT).decode().splitlines()))
for name in sources: py_compile.compile(str(ROOT/name),doraise=True)
(QA/'compiled.json').write_text(json.dumps({'status':'PASS','files':sources,'count':len(sources)},indent=2)+'\n',encoding='utf-8')
plans = [('tests/analysis_ui','test_pages.py'),('tests/serving_runtime','test_resources.py'),
         ('tests/serving_runtime','test_runtime.py'),('tests/serving_runtime','test_api.py'),
         ('tests','test_variant_serving.py'),('tests','test_unified_experiment.py'),
         ('tests','test_web_json_serialization.py'),('tests','test_research_results_viewer.py'),
         ('tests','test_original_fix_parity.py'),('tests','test_unified_execution_leakage.py'),
         ('tests','test_unified_preflight_leakage.py'),('tests/unified_live','test_leakage.py')]


def run(plan: tuple[str,str]) -> tuple[str,dict]:
    """Mỗi suite có process riêng; stdout/stderr nguyên byte, không bị shell bọc lỗi."""
    directory,pattern = plan
    command = [sys.executable,'-X','utf8','-m','unittest','discover','-s',directory,'-p',pattern,'-v']
    process = subprocess.run(command,cwd=ROOT,capture_output=True)
    name = directory.replace('/','_')+'_'+pattern.replace('.py','.log')
    raw = process.stdout+b'\n'+process.stderr; (QA/name).write_bytes(raw)
    count = re.search(rb'Ran (\d+) tests?',process.stderr)
    return name,{'returncode':process.returncode,'tests':int(count[1]) if count else None,
        'command':command[1:],'log_sha256':hashlib.sha256(raw).hexdigest()}


results = {}
with ThreadPoolExecutor(max_workers=2) as pool:
    for future in as_completed([pool.submit(run,plan) for plan in plans]):
        name,result = future.result(); results[name] = result
        (QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
        print(name,result['returncode'],result['tests'],flush=True)
for name in ('analysis_ui','research_viewer'):
    command = ['node','--test','tests/js/'+name+'.test.mjs']
    process = subprocess.run(command,cwd=ROOT,capture_output=True)
    raw = process.stdout+b'\n'+process.stderr; filename = name+'.log'; (QA/filename).write_bytes(raw)
    results[filename] = {'returncode':process.returncode,'command':command,'log_sha256':hashlib.sha256(raw).hexdigest(),
                         'tests':int(re.search(rb'(?:\xE2\x84\xB9 |# )tests (\d+)',raw)[1])}
    print(filename,process.returncode,results[filename]['tests'],flush=True)
(QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
js = sorted((ROOT/'static/js/analysis').glob('*.js'))
for path in js: subprocess.run(['node','--check',str(path)],cwd=ROOT,check=True,capture_output=True)
(QA/'syntax.json').write_text(json.dumps({'status':'PASS','js_files':[p.relative_to(ROOT).as_posix() for p in js]},indent=2)+'\n',encoding='utf-8')
sys.exit(int(any(row['returncode'] for row in results.values())))
