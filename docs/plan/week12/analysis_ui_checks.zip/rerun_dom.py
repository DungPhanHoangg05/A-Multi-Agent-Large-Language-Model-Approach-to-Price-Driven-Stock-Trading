"""Khóa log DOM cuối sau tối ưu heartbeat không đóng chi tiết đang đọc."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f09'
result = subprocess.run(['node','--test','tests/js/analysis_ui.test.mjs'],cwd=ROOT,capture_output=True)
raw = result.stdout+b'\n'+result.stderr
(QA/'analysis_ui.log').write_bytes(raw)
results = json.loads((QA/'test_results.json').read_bytes())
results['analysis_ui.log'].update(returncode=result.returncode,log_sha256=hashlib.sha256(raw).hexdigest())
(QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
assert result.returncode == 0
for path in (ROOT/'static/js/analysis').glob('*.js'):
    subprocess.run(['node','--check',str(path)],cwd=ROOT,check=True,capture_output=True)
print('PASS_DOM_12_JS_7')
