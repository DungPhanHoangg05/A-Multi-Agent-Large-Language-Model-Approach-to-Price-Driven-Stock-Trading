"""Bản dịch trình bày được rà thủ công từ ba report FPT; không suy luận lại thị trường."""
REPLACEMENTS={
    'n18':{
        'Loại':'Type','Giá trị':'Value','Tín hiệu':'Signal','Kết hợp decay-delta-corr':'Decay-delta-corr combination',
        'Dài hạn + Trung hạn':'Long term + Medium term','Đột phá từ đáy':'Breakout from the bottom',
        'Khối lượng:':'Volume:','thực':'actual','Công thức đầy đủ:':'Full formula:',
        'Các bước tính toán:':'Calculation steps:','Diễn giải:':'Interpretation:',
        'Kết quả cuối cùng:':'Final value:','phiên':'sessions',
        'Triple rank với decay tạo tín hiệu bền vững; sign(corr) xác nhận..':'Triple rank with decay produces a sustained signal; sign(corr) confirms it..',
        'Kết hợp corr adv20-thấp với vị trí giá so với HL/2 để đo fair value gap..':'Combines the correlation of adv20 and low with the price position relative to HL/2 to measure the fair value gap..',
        'Kết hợp sai lệch SMA7 với tương quan VWAP dài hạn 230 phiên..':'Combines the SMA7 deviation with the long-term VWAP correlation over 230 sessions..',
        'Đảo chiều tín hiệu do tương quan lịch sử âm':'Signal inverted because the historical correlation is negative',
        'Vị trí VWAP dưới đỉnh 15 phiên khuếch đại theo delta close 5 phiên..':'The VWAP position below the 15-session high is amplified by the 5-session close delta..',
        'Kết hợp bật từ đáy, momentum tương đối dài hạn và volume tăng..':'Combines a rebound from the bottom, relatively long-term momentum and increasing volume..',
        'TỔNG HỢP:':'CONSENSUS:','TRUNG TÍNH':'NEUTRAL','Trung tính':'Neutral','TĂNG':'BULLISH','GIẢM':'BEARISH',
    },
    'n19':{
        'Mô hình:':'Pattern:','Xu hướng giảm rõ rệt.':'Clear downtrend.','Độ tin cậy:':'Confidence:',
        'Cao.':'High.','Thiên lệch dự báo:':'Forecast bias:','Giảm.':'Bearish.','Bằng chứng:':'Evidence:',
        'Chuỗi các đỉnh và đáy liên tục thấp dần từ mức 67.5 xuống vùng 50.0.':'A series of successively lower highs and lows from 67.5 down to the 50.0 area.',
        'Nến quan trọng:':'Key candles:',
        'Nến xanh mạnh ngày 02/11 bị nến đỏ ngày 03/11 phủ nhận hoàn toàn.':'The strong green candle on 02/11 was completely negated by the red candle on 03/11.',
        'Hàm ý giao dịch:':'Trading implication:',
        'Bán khi giá hồi về vùng kháng cự 57.5 hoặc chờ phá vỡ đáy 50.0.':'Sell on a rebound to the resistance area at 57.5, or wait for a break below the 50.0 low.',
    },
    'n20':{
        'Hướng xu hướng:':'Trend direction:','Giảm.':'Downward.','Mức hỗ trợ:':'Support level:',
        'Mức kháng cự:':'Resistance level:','Độ dốc đường xu hướng:':'Trendline slope:',
        'Đang giảm.':'Declining.','Giá so với hỗ trợ:':'Price relative to support:','Nén lại.':'Compressing.',
        'Phân tích chi tiết:':'Detailed analysis:',
        'Giá đóng cửa liên tục nằm dưới đường kháng cự đỏ và đang tiến sát đường hỗ trợ xanh. Khoảng cách giữa hai đường xu hướng đang thu hẹp lại, cho thấy áp lực bán đang giảm dần.':'Closing prices have remained below the red resistance line and are approaching the blue support line. The gap between the two trendlines is narrowing, indicating that selling pressure is gradually easing.',
        'Dự đoán xu hướng:':'Trend forecast:',
        'Giá có khả năng đi ngang hoặc hồi phục nhẹ trong 3 phiên tới do đã chạm vùng hỗ trợ kỹ thuật. Nếu vượt qua kháng cự 51.5, xu hướng giảm sẽ bị vô hiệu hóa.':'Prices may move sideways or recover slightly over the next 3 sessions after reaching technical support. A break above resistance at 51.5 would invalidate the downtrend.',
        'Độ tin cậy:':'Confidence:','Trung bình.':'Medium.',
    },
}


def translate(name: str, text: str) -> str:
    """Thay các cụm dài trước; mọi byte số/code được guard đối chiếu sau dịch."""
    for source,target in sorted(REPLACEMENTS[name].items(),key=lambda pair:-len(pair[0])):
        text=text.replace(source,target)
    return text
