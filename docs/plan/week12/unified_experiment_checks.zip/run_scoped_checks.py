"""Kiểm đúng vùng U04, lưu log và IDs test; không chạy full suite/E2E."""
from contextlib import redirect_stdout, redirect_stderr
import json
from pathlib import Path
import sys
import unittest

root = Path.cwd()
sys.path[:0] = [str(root), str(root / 'tests')]
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
groups = {
    'unified': ['test_unified_experiment'],
    'contracts': ['test_account_risk', 'test_target_contract', 'test_free_pilot_statistics',
                  'test_web_json_serialization', 'test_historical_adapter_journal'],
    'data': ['test_improvement_prior', 'test_improvement_leakage', 'test_prior_quality_gate_leakage',
             'test_mt_bicl_decision', 'test_mt_bicl_adapter_leakage', 'test_mt_bicl_features_leakage'],
    'native': ['test_original_fix_parity', 'test_backtest_token_budget', 'test_paired_protocol'],
}


def ids(suite):
    """Giữ danh sách case thực thi trước unittest dọn object."""
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from ids(item)
        else:
            yield item.id()


group, output = sys.argv[1], Path(sys.argv[2])
with output.open('w', encoding='utf-8', newline='\n') as handle, redirect_stdout(handle), redirect_stderr(handle):
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(module) for module in groups[group])
    test_ids = list(ids(suite))
    result = unittest.TextTestRunner(stream=handle, verbosity=2).run(suite)
summary = {'group': group, 'modules': groups[group], 'test_ids': test_ids, 'tests': result.testsRun,
           'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped)}
output.with_suffix('.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summary | {'test_ids': []}), flush=True)
sys.exit(not result.wasSuccessful() or bool(result.skipped))
