"""Cold consumer gói U04: kiểm bytes/source/runtime rồi dựng lại policy/ledger từ journal."""
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root = Path.cwd().resolve()
package, destination = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
if destination.exists():
    raise FileExistsError('Không ghi đè thư mục restore đã có')
with zipfile.ZipFile(package) as archive:
    names = archive.namelist()
    manifest = json.loads(archive.read('manifest.json'))
    if len(names) != len(set(names)) or set(names) != {'manifest.json', *manifest['members']}:
        raise ValueError('Gói U04 có tập thành viên không hợp lệ')
    for name, expected in manifest['members'].items():
        raw = archive.read(name)
        if len(raw) != expected['bytes'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
            raise ValueError('Sai hash thành viên: ' + name)
    sources = json.loads(archive.read('source_bindings.json'))
    for name, expected in sources.items():
        path = root / name
        if not path.resolve().is_relative_to(root) or hashlib.sha256(path.read_bytes()).hexdigest() != expected['sha256']:
            raise ValueError('Nguồn hiện hành khác gói: ' + name)
    runtime = json.loads(archive.read('runtime.json'))
    if sys.version.split()[0] != runtime['python'] or any(version(name) != value for name, value in runtime['packages'].items()):
        raise ValueError('Runtime khác gói U04')
    destination.mkdir(parents=True)
    for name in names:
        if not name.startswith('fixture/'):
            continue
        path = destination / name.removeprefix('fixture/')
        if not path.resolve().is_relative_to(destination):
            raise ValueError('Đường dẫn restore không an toàn')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(archive.read(name))
    expected = json.loads(archive.read('fixture/cold_run.json'))
command = [sys.executable, '-I', '-X', 'utf8', str(root / 'scripts/run_unified_experiment.py'),
           '--root', str(destination), 'verify', str(destination / 'outputs/unified_integration/u04_fixture')]
result = subprocess.run(command, capture_output=True, check=True)
if json.loads(result.stdout) != expected:
    raise ValueError('Ledger cold restore khác golden')
print(json.dumps({'status': 'PASS', 'members': len(names), 'source_bindings': len(sources),
    'runtime_packages': len(runtime['packages']), 'cold_policy_ledger_exact': True, 'hosted_calls': 0,
    'scope': 'SYNTHETIC_CONTRACT_FIXTURE_NOT_MARKET_OR_HOSTED_REPRODUCTION'}))
