﻿from pathlib import Path
import sys,tempfile,unittest,json,py_compile,hashlib
root=Path.cwd()
sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
loader=unittest.TestLoader()
suite=loader.discover(str(root/'tests/unified_live'),pattern='test_*.py')
extra=['test_unified_execution_recovery','test_unified_execution_leakage','test_unified_experiment','test_unified_preflight_leakage']
for name in extra:suite.addTests(loader.loadTestsFromName(name))
def ids(value):
 for item in value:
  if isinstance(item,unittest.TestSuite):yield from ids(item)
  else:yield item.id()
testids=list(ids(suite))
p=Path(tempfile.gettempdir())
with (p/'u08_scoped_tests.log').open('w',encoding='utf8') as stream:
 result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
names=[f.relative_to(root).as_posix() for folder in ('core/unified_live','scripts/unified_live','tests/unified_live') for f in sorted((root/folder).rglob('*')) if f.is_file() and '__pycache__' not in f.parts]
compiled=[]
if result.wasSuccessful():
 for name in names:
  if name.endswith('.py'):
   py_compile.compile(str(root/name),doraise=True);compiled.append(name)
from core.unified_protocol import binding
record={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'test_ids':testids,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'compiled':compiled,'sources':{n:binding(root,n) for n in names},'log_sha256':hashlib.sha256((p/'u08_scoped_tests.log').read_bytes()).hexdigest(),'scope':'U08_LIVE_RELEASE_TRANSPORT_RUNNER_LABEL_FIREWALL_AND_DIRECT_U07_CALLERS_NO_FULL_SUITE','inference_requests':0}
(p/'u08_scoped_tests.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:record[k] for k in ('status','tests','failures','errors','skips')},ensure_ascii=False))
if not result.wasSuccessful():print((p/'u08_scoped_tests.log').read_text(encoding='utf8')[-7500:])
raise SystemExit(not result.wasSuccessful())
