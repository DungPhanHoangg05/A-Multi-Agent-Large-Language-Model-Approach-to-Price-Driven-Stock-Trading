"""Gói QA F06 nhỏ, gồm log và hash code đã kiểm; không chứa bằng chứng nghiên cứu mới."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import unicodedata
import zipfile

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f06'
TARGET = ROOT/'docs/plan/week12/variant_serving_checks.zip'


def binding(raw):
    """Hash byte nguyên bản."""
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def slug(text):
    """Anchor Unicode tương thích quy ước link trong tài liệu hiện hành."""
    text = re.sub('<[^>]+>', '', text).lower().replace(' ', '-')
    return ''.join(c for c in text if c in '-_' or unicodedata.category(c)[0] in 'LN')


TARGET.touch(exist_ok=True)
documents = ('docs/plan/plan.md', 'docs/plan/week12/README.md',
             'docs/plan/week12/final_paper_ui_plan.md', 'docs/plan/week12/variant_serving_contract.md')
count = 0
for name in documents:
    path = ROOT/name
    for target in re.findall(r'(?<!!)\[[^]\n]*\]\(([^)\n]+)\)', path.read_text(encoding='utf-8')):
        if '://' in target or target.startswith('mailto:'):
            continue
        rel, _, anchor = target.partition('#')
        destination = (path.parent/rel).resolve() if rel else path
        assert destination.exists(), (name, target)
        if anchor:
            headings = [slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$', destination.read_text(encoding='utf-8'), re.M)]
            assert anchor in headings, (name, target)
        count += 1
readme = (ROOT/documents[1]).read_text(encoding='utf-8')
plan = (ROOT/documents[2]).read_text(encoding='utf-8')
assert '- [x] F06' in readme and '| F06 | ☑ Hoàn tất |' in plan
for task in range(7, 13):
    name = f'F{task:02}'
    assert '- [ ] '+name in readme and '| '+name+' | ☐ Chưa bắt đầu |' in plan
link_result = {'status': 'PASS_F06_LINKS_CHECKLIST', 'documents': list(documents), 'local_links': count}
(QA/'links.json').write_text(json.dumps(link_result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

sources = ('core/serving_registry.py', 'core/serving_contracts.py', 'utils/serving_web.py',
           'web_interface.py', 'tests/test_variant_serving.py')
expected = {'contracts_final.log': 15, 'experiment.log': 15, 'web_json.log': 3}
logs = {}
for name, total in expected.items():
    raw = (QA/name).read_bytes()
    decoded = raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert re.search(r'Ran '+str(total)+r' tests in', decoded) and re.search(r'^OK\s*$', decoded, re.M), name
    logs[name] = raw
checks = {'status': 'PASS_F06_SCOPED_CHECKS', 'base_commit': 'cb2df984',
          'runtime': subprocess.check_output(['py', '-3.13', '--version']).decode().strip(),
          'test_counts': expected, 'tests_passed': 33, 'compiled_files': list(sources),
          'source_bindings': {name: binding((ROOT/name).read_bytes()) for name in sources},
          'compile_command': 'py -3.13 -m py_compile '+' '.join(sources),
          'contract_test_command': 'py -3.13 -X utf8 tmp/f06/run_contract_checks.py',
          'experiment_test_command': 'py -3.13 -X utf8 -m unittest discover -s tests -p test_unified_experiment.py -v',
          'web_test_command': 'py -3.13 -X utf8 -m unittest discover -s tests -p test_web_json_serialization.py -v',
          'historical_replay': 'docs/plan/week12/final_evidence_map.md', 'new_api_calls': 0, 'training': 0}
members = {**logs, 'checks.json': (json.dumps(checks, ensure_ascii=False, indent=2)+'\n').encode()}
for name in ('integrity.json', 'links.json', 'check_integrity.py', 'run_contract_checks.py', 'seal_checks.py'):
    members[name] = (QA/name).read_bytes()
members['manifest.json'] = (json.dumps({name: binding(raw) for name, raw in members.items()}, indent=2)+'\n').encode()
with zipfile.ZipFile(TARGET, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in members.items():
        archive.writestr(name, raw)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    for name, raw in members.items():
        assert archive.read(name) == raw
print(json.dumps({'status': checks['status'], 'test_count': 33, 'local_links': count,
                  'members': len(members), 'package': binding(TARGET.read_bytes())}))
