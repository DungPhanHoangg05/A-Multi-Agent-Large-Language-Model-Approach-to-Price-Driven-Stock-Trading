"""Đối soát phạm vi F06 và bằng chứng khóa; không tái chạy nghiên cứu hoặc đổi expected pin."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = 'cb2df984'
DOC = ROOT / 'docs/plan/week12'


def binding(raw):
    """Hash byte thực, không chuẩn hóa newline."""
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


with zipfile.ZipFile(DOC / 'unified_analysis_results.zip') as archive:
    pins = {name: {key: row[key] for key in ('bytes', 'sha256')}
            for name, row in json.loads(archive.read('manifest.json'))['sources'].items()}
    assert len(pins) == 729
with zipfile.ZipFile(DOC / 'final_evidence_snapshot.zip') as archive:
    historical = json.loads(archive.read('snapshot_manifest.json'))
    for name, expected in pins.items():
        assert binding(archive.read(name)) == expected, name
    mismatches = [name for name, expected in pins.items() if binding((ROOT/name).read_bytes()) != expected]
    assert mismatches == ['web_interface.py'], mismatches
    for group in ('frozen_packages', 'legacy_archives'):
        for name, expected in historical[group].items():
            assert binding((ROOT/name).read_bytes()) == expected, name

release = ROOT/'outputs/revision/manuscript_unified_final_v1'
manifest = json.loads((release/'manifest.json').read_bytes())
assert binding((release/'manifest.json').read_bytes()) == {'bytes': 55249, 'sha256': '8e5ce2a4ca6f3a52945047cb8e1e1e99e8c00dfcd959a6fc6cdadcd701013de9'}
for name, expected in manifest['outputs'].items():
    assert binding((release/name).read_bytes()) == expected, name
for name, expected in manifest['sources'].items():
    assert binding((ROOT/name).read_bytes()) == expected, name

old_web = subprocess.check_output(['git', 'show', BASE+':web_interface.py'], cwd=ROOT)
new_web = (ROOT/'web_interface.py').read_bytes()
added = b'from utils.serving_web import serving\napp.register_blueprint(serving)\n'
assert new_web.replace(added, b'').replace(b'\r\n', b'\n') == old_web.replace(b'\r\n', b'\n')
for name in ('core/variant_registry.py', 'core/unified_contracts.py', 'core/unified_methods.py',
             'core/unified_experiment.py', 'core/backtest_engine.py', 'utils/experiment_web.py',
             'templates/demo_new.html', 'templates/output.html', 'templates/backtest.html', 'templates/experiments.html'):
    assert binding((ROOT/name).read_bytes()) == pins[name], name
    assert subprocess.check_output(['git', 'diff', '--exit-code', BASE, '--', name], cwd=ROOT) == b'', name

result = {'status': 'PASS_F06_INTEGRITY', 'base_commit': BASE, 'u09_source_pins_total': 729,
          'current_source_pins_match': 728, 'intentional_new_serving_source': mismatches,
          'historical_pins_restorable_from_snapshot': 729,
          'frozen_w12_packages_unchanged': len(historical['frozen_packages']),
          'legacy_archives_unchanged': len(historical['legacy_archives']),
          'f05_outputs_unchanged': len(manifest['outputs'])+1, 'f05_sources_unchanged': len(manifest['sources']),
          'new_api_calls': 0, 'training': 0}
(ROOT/'tmp/f06/integrity.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
