"""Lưu log UTF-8 của contract test cuối, tránh PowerShell đổi định dạng stderr."""
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
suite = unittest.defaultTestLoader.discover(str(ROOT/'tests'), pattern='test_variant_serving.py')
with (ROOT/'tmp/f06/contracts_final.log').open('w', encoding='utf-8') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
print('PASS' if result.wasSuccessful() else 'FAIL', result.testsRun)
sys.exit(0 if result.wasSuccessful() else 1)
