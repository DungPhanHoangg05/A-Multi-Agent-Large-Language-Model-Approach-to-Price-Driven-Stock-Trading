"""Chạy đúng các nhóm test được chọn, chặn socket và lưu log nguyên byte UTF-8."""
from contextlib import redirect_stdout, redirect_stderr
import importlib
import os
from pathlib import Path
import socket
import sys
import unittest

root = Path.cwd().resolve()
os.chdir(root)
sys.path[:0] = [str(root), str(root / 'tests')]
os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', MPLBACKEND='Agg')


original_connect, original_connect_ex = socket.socket.connect, socket.socket.connect_ex


def guarded_connect(sock, address):
    """Cho socketpair Windows dùng loopback; mọi mạng ngoài máy đều bị chặn."""
    if isinstance(address, tuple) and address[0] in ('127.0.0.1', '::1', 'localhost'):
        return original_connect(sock, address)
    raise AssertionError('Kiểm U02 không cho phép kết nối mạng ngoài máy')


def guarded_connect_ex(sock, address):
    """Áp cùng guard cho đường không ném lỗi của socket."""
    if isinstance(address, tuple) and address[0] in ('127.0.0.1', '::1', 'localhost'):
        return original_connect_ex(sock, address)
    raise AssertionError('Kiểm U02 không cho phép kết nối mạng ngoài máy')


socket.socket.connect, socket.socket.connect_ex = guarded_connect, guarded_connect_ex
groups = {
    'economics': ['test_account_pnl', 'test_account_risk', 'test_target_contract', 'test_unified_contract_integration',
                  'test_ablation_matrix', 'test_robustness_sweep', 'test_web_json_serialization',
                  'test_chart_convention', 'test_quantagent_attribution'],
    'callers': ['test_prior_backtest_integration', 'test_prior_backtest_leakage', 'test_prior_checkpoint',
                'test_prior_checkpoint_leakage', 'test_prior_stage_recovery', 'test_mt_bicl_analysis',
                'test_mt_bicl_analysis_leakage', 'test_free_pilot_statistics'],
    'graphs': ['test_paired_protocol', 'test_backtest_token_budget', 'test_prior_graph_integration',
               'test_prior_prompt_contract', 'test_mt_bicl_decision', 'test_alpha_leakage', 'test_sentiment_leakage'],
    'locks': ['test_research_input_lock', 'test_research_input_lock_leakage', 'test_unified_contract_integration'],
}
name = sys.argv[1]
with Path(sys.argv[2]).open('w', encoding='utf-8', newline='\n') as handle, redirect_stdout(handle), redirect_stderr(handle):
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(module) for module in groups[name])
    result = unittest.TextTestRunner(stream=handle, verbosity=2).run(suite)
print(name, result.testsRun, len(result.failures), len(result.errors), len(result.skipped), flush=True)
sys.exit(not result.wasSuccessful())
