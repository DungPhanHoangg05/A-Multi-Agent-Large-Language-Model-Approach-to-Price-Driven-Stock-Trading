"""Restore U05: kiểm byte/source/runtime, tái fit selector, projection/bridge và ledger trong tiến trình mới."""
from contextlib import redirect_stdout
from importlib.metadata import version
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
import zipfile

root = Path.cwd().resolve()
package, destination = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
if destination.exists():
    raise FileExistsError('Không ghi đè thư mục restore đã có')
with zipfile.ZipFile(package) as archive:
    names = archive.namelist()
    manifest = json.loads(archive.read('manifest.json'))
    if len(names) != len(set(names)) or set(names) != {'manifest.json', *manifest['members']}:
        raise ValueError('Tập thành viên QA U05 không hợp lệ')
    for name, expected in manifest['members'].items():
        raw = archive.read(name)
        if len(raw) != expected['bytes'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
            raise ValueError('Sai hash thành viên: ' + name)
    sources = json.loads(archive.read('source_bindings.json'))
    for name, expected in sources.items():
        path = root / name
        if not path.resolve().is_relative_to(root) or hashlib.sha256(path.read_bytes()).hexdigest() != expected['sha256']:
            raise ValueError('Source khác gói U05: ' + name)
    runtime = json.loads(archive.read('runtime.json'))
    if sys.version.split()[0] != runtime['python'] or any(version(name) != value for name, value in runtime['packages'].items()):
        raise ValueError('Runtime U05 không khớp')
    destination.mkdir(parents=True)
    for name in names:
        if name.startswith('fixture/'):
            path = destination / name.removeprefix('fixture/')
            if not path.resolve().is_relative_to(destination):
                raise ValueError('Đường dẫn restore không an toàn')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.read(name))
sys.path.insert(0, str(root))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
from scripts.manage_causal_profile import prices
from agents import alpha_agent as native
from utils.json_util import to_json_compatible

bundle = json.loads((destination / 'bundle.json').read_bytes())
point = bundle['spec']['points'][0]
manage = [sys.executable, '-I', '-X', 'utf8', str(root / 'scripts/manage_causal_profile.py')]
price = ['--prices', str(destination / 'causal-prices.json')]
model = ['--selector', str(destination / 'causal-selector.json')]
commands = [
 [*manage, 'fit', *price, '--schedule', str(destination / 'schedule.json'), '--output', str(destination / 'restore-selector.json')],
 [*manage, 'predict', *price, *model, '--cutoff', point['cutoff'], '--output', str(destination / 'restore-prediction.json')],
 [*manage, 'bridge', *price, *model, '--snapshot', str(destination / 'native_snapshot.json'), '--decision', str(destination / 'decision.json'), '--output', str(destination / 'restore-bridge.json')]]
for command in commands:
    subprocess.run(command, capture_output=True, check=True)
for actual, expected in (('restore-selector.json', 'causal-selector.json'), ('restore-prediction.json', 'prediction.json'), ('restore-bridge.json', 'bridge.json')):
    if json.loads((destination / actual).read_bytes()) != json.loads((destination / expected).read_bytes()):
        raise ValueError('Restore không tái lập: ' + actual)
command = [sys.executable, '-I', '-X', 'utf8', str(root / 'scripts/run_unified_experiment.py'),
           '--root', str(destination), 'verify', str(destination / bundle['spec']['namespace'])]
result = subprocess.run(command, capture_output=True, check=True)
if json.loads(result.stdout) != json.loads((destination / 'cold_run.json').read_bytes()):
    raise ValueError('Ledger/policy cold khác golden')
frame = prices(destination / 'causal-prices.json')
prefix = frame.loc[frame.Datetime <= point['cutoff']].tail(600)
original = native.select_top_alphas
observed = []


def observe(*args, **kwargs):
    """Ghi top IDs từ selector thật, không thay return hoặc dữ liệu."""
    rows = original(*args, **kwargs)
    observed.append([row['alpha_id'] for row in rows])
    return rows


with redirect_stdout(io.StringIO()), patch.object(native, 'select_top_alphas', side_effect=observe):
    factors, _ = native._compute_all_alphas(prefix.tail(45).to_dict(orient='list'), {}, {}, point['symbol'],
        historical_df=prefix, as_of_date=point['cutoff'], is_backtest=True, strict_research_mode=True)
numeric = json.loads((destination / 'numeric_bridge.json').read_bytes())
if observed != [numeric['native_ids']] or to_json_compatible(factors) != numeric['native_factors']:
    raise ValueError('Native numeric bridge không tái lập')
print(json.dumps({'status': 'PASS', 'members': len(names), 'source_bindings': len(sources),
    'runtime_packages': len(runtime['packages']), 'selector_projection_bridge_ledger_exact': True,
    'native_numeric_exact': True, 'hosted_calls': 0,
    'scope': 'SYNTHETIC_ALPHA_LOCAL_ONLY_NOT_MARKET_OR_WHOLE_SYSTEM_CAUSAL_RELEASE'}))
