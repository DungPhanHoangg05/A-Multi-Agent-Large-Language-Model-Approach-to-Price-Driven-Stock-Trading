"""Fixture cold U05, thêm native alpha thật trên cùng giá; không phải thử nghiệm thị trường."""
from contextlib import redirect_stdout
from copy import deepcopy
import io
from pathlib import Path
import sys
from unittest.mock import patch
from uuid import NAMESPACE_URL, uuid5

import pandas as pd

root = Path.cwd()
sys.path[:0] = [str(root), str(root / 'tests')]
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
from agents import alpha_agent as native_agent
from causal_profile_support import causal_fixture
from core.causal_bridge import CausalSources
from core.unified_contracts import digest, json_bytes
from core.unified_experiment import make_record, outcome_from_frame, slot_id
from core.unified_methods import snapshot_from_graph, validate_prepared
from core.variant_registry import VARIANTS, execution_order
from mt_bicl_support import original, reply
from utils.json_util import to_json_compatible

destination = Path.home() / 'AppData/Local/Temp/u05-causal-proof-accepted'
destination.mkdir(exist_ok=False)
fixture, _, artifact = causal_fixture(destination)
prefix = fixture.frame.loc[fixture.frame.Datetime <= pd.Timestamp(fixture.point['cutoff'])].tail(600)
selected = []
original_select = native_agent.select_top_alphas


def observe(*args, **kwargs):
    """Chỉ ghi return của selector thật; không thay dữ liệu, ranking hoặc source."""
    result = original_select(*args, **kwargs)
    selected.append(result)
    return result


with (destination / 'native_numeric.log').open('w', encoding='utf-8') as log, redirect_stdout(log), patch.object(native_agent, 'select_top_alphas', side_effect=observe):
    alphas, tv = native_agent._compute_all_alphas(prefix.tail(45).to_dict(orient='list'), {}, {}, fixture.point['symbol'],
        historical_df=prefix, as_of_date=fixture.point['cutoff'], is_backtest=True, strict_research_mode=True)
assert len(selected) == 1 and len(selected[0]) == len(alphas) == 5
fixture.payload.update(alpha_report=native_agent._build_alpha_report(alphas, tv, {}, fixture.point['symbol']),
                       alpha_factors=to_json_compatible(alphas))
fixture.snapshot = snapshot_from_graph(fixture.point, 0, fixture.payload, prefix, fixture.source_sha, [])
bound = CausalSources(fixture.spec, destination).bind(fixture.snapshot)
projection = bound.document()['payload']['causal_alpha']['projection']
native_ids = [row['alpha_id'] for row in selected[0]]
causal_ids = [row['alpha_id'] for row in projection['factors']]
overlap = len(set(native_ids) & set(causal_ids))
comparison = {'scope': 'SYNTHETIC_NUMERIC_AND_REQUEST_BRIDGE_NOT_HOSTED_OR_MARKET_EFFECT',
    'point_id': fixture.point['id'], 'native_history_rows': 600, 'causal_history_rows': 1297,
    'native_ids': native_ids, 'native_factors': to_json_compatible(alphas),
    'causal_ids': causal_ids, 'causal_factors': projection['factors'], 'top5_intersection': overlap,
    'top5_jaccard': overlap / (10-overlap), 'native_rowwise_causal_gate': 'FAIL',
    'causal_scope': 'ALPHA_ONLY; WHOLE_SYSTEM_GATE_PENDING_U06_U07', 'native_numeric_calls': 1, 'hosted_calls': 0}
(destination / 'numeric_bridge.json').write_bytes(json_bytes(comparison))
(destination / 'native_snapshot.json').write_bytes(json_bytes(fixture.snapshot.document()))
(destination / 'decision.json').write_bytes(json_bytes(fixture.spec['decision']))
(destination / 'schedule.json').write_bytes(json_bytes(artifact['payload']['schedule']))
methods = fixture.methods()
outputs, preparations, responses = {}, {}, {}
for variant in execution_order(fixture.spec['variants']):
    dependencies = {key: outputs[key] for key in next(v for v in VARIANTS if v.id == variant).dependencies}
    prepared = methods.prepare(variant, bound, deepcopy(dependencies), 0)
    validate_prepared(variant, bound, prepared, fixture.spec['decision'], 0)
    slot = slot_id(fixture.point['id'], 0, 0, variant)
    preparations[slot] = prepared
    raw = None
    if prepared['request'] is not None:
        value = reply(fixture.facts, 'SHORT' if variant == 'MT_BICL' else 'LONG', anchor=variant == 'Fact_Anchor') if variant in ('Fact_Anchor', 'MT_BICL') else original()
        raw = {'request_sha256': digest(prepared['request']), 'source_request_id': str(uuid5(NAMESPACE_URL, slot)),
               'source_sha256': digest(value), 'reply': value}
        responses[slot] = raw
    outputs[variant] = make_record(fixture.point, bound, variant, 0, prepared, raw, dependencies)
bundle = {'spec': fixture.spec, 'snapshots': {fixture.point['id']+'/u0': bound.document()},
          'preparations': preparations, 'responses': responses,
          'outcomes': {fixture.point['id']: outcome_from_frame(fixture.point, fixture.frame, fixture.source_sha)}}
(destination / 'bundle.json').write_bytes(json_bytes(bundle))
print(destination)
