"""Cold replay U05 trên fixture đã khóa; không gọi hosted hoặc đo market effect."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

p = Path(sys.argv[1]).resolve()
root = Path.cwd()
python = [sys.executable, '-I', '-X', 'utf8']
manage = [*python, str(root / 'scripts/manage_causal_profile.py')]
unified = [*python, str(root / 'scripts/run_unified_experiment.py'), '--root', str(p)]
price = ['--prices', str(p / 'causal-prices.json')]
model = ['--selector', str(p / 'causal-selector.json')]
bundle = json.loads((p / 'bundle.json').read_bytes())
point = bundle['spec']['points'][0]
checksum = hashlib.sha256((p / 'bundle.json').read_bytes()).hexdigest()
commands = {
 'cold_fit': [*manage, 'fit', *price, '--schedule', str(p / 'schedule.json'), '--output', str(p / 'refitted-selector.json')],
 'cold_selector_verify': [*manage, 'verify', *price, *model],
 'cold_predict': [*manage, 'predict', *price, *model, '--cutoff', point['cutoff'], '--output', str(p / 'prediction.json')],
 'cold_bridge': [*manage, 'bridge', *price, *model, '--snapshot', str(p / 'native_snapshot.json'), '--decision', str(p / 'decision.json'), '--output', str(p / 'bridge.json')],
 'cold_run': [*unified, 'replay', str(p / 'bundle.json'), '--sha256', checksum],
 'cold_verify': [*unified, 'verify', str(p / 'outputs/unified_integration/fixture')],
 'cold_export': [*unified, 'export', str(p / 'outputs/unified_integration/fixture'), '--format', 'csv', '--output', str(p / 'table.csv')]}
for name, args in commands.items():
    with (p / (name + '.json')).open('xb') as out, (p / (name + '.log')).open('xb') as err:
        subprocess.run(args, stdout=out, stderr=err, check=True)
    print(name, 'PASS', flush=True)
assert json.loads((p / 'causal-selector.json').read_bytes()) == json.loads((p / 'refitted-selector.json').read_bytes())
a = json.loads((p / 'cold_run.json').read_bytes())
assert a == json.loads((p / 'cold_verify.json').read_bytes())
bridge = json.loads((p / 'bridge.json').read_bytes())
assert bridge['native_request_unchanged']
assert bridge['shared']['payload']['causal_alpha']['projection'] == json.loads((p / 'prediction.json').read_bytes())
requests = [x['request'] for x in bundle['preparations'].values() if x['request'] is not None]
artifact = json.loads((p / 'causal-selector.json').read_bytes())['payload']
numeric = json.loads((p / 'numeric_bridge.json').read_bytes())
report = {'status': 'PASS', 'scope': 'SYNTHETIC_ALPHA_AND_PAIRED_REQUEST_BRIDGE_NOT_MARKET_OR_HOSTED_EFFECT',
 'bundle_sha256': checksum, 'selector_sha256': json.loads((p / 'causal-selector.json').read_bytes())['sha256'],
 'planned_slots': a['planned_slots'], 'complete_slots': a['complete_slots'], 'accounts': len(a['accounts']),
 'offline_response_consumptions': len(requests), 'max_prompt_chars': max(len(x['messages'][0]['content']) for x in requests),
 'train_cycles': len(artifact['train_dates']), 'validation_common_cycles': len(artifact['validation_dates']),
 'purged': artifact['purged'], 'selected': artifact['selected'], 'threshold': artifact['threshold'],
 'native_top5_intersection': numeric['top5_intersection'], 'native_top5_jaccard': numeric['top5_jaccard'],
 'cold_selector_exact': True, 'native_request_unchanged': True, 'cold_policy_ledger_exact': True,
 'native_rowwise_causal_gate': 'FAIL', 'whole_system_causal_gate': 'PENDING_U06_U07',
 'hosted_calls': 0, 'synthetic_selector_fit': True, 'market_model_fit': False}
(p / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
