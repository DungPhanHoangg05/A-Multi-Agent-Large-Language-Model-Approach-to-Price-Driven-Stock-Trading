from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
import sys,json,tempfile,numpy as np
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
with ExitStack() as stack:
 for name in ('httpx.Client','httpx.AsyncClient','httpx.HTTPTransport','langchain_groq.ChatGroq','dotenv.dotenv_values','core.unified_execution_providers.StudyProviders'):
  stack.enter_context(patch(name,side_effect=AssertionError('Đối soát cấm key/client: '+name)))
 from core.unified_analysis.inputs import accept
 from core.backtest_engine import TestPoint, compute_account_metrics
 from utils.target_contract import target_record_fields
 from collections import defaultdict
 bundle=accept(root)
 point_map={v['id']:v for v in bundle['points']};groups=defaultdict(list);observations=defaultdict(list)
 selected=[(v['forecast']['variant'],v['forecast']['point_id'],v['forecast']['repeat'],v['policy']['final_action']) for v in bundle['records']]
 for method,action in (('CASH_EVERY_CYCLE','CASH'),('ALWAYS_LONG_EVERY_CYCLE_WITH_FULL_COSTS','LONG')):
  selected.extend((method,p['id'],repeat,action) for p in bundle['points'] for repeat in range(3))
 for method,pid,repeat,action in selected:
  point=point_map[pid];outcome=bundle['outcomes'][pid];t=outcome['target'];dates=outcome['dates'];prediction='LONG' if action=='LONG' else 'SHORT';correct=(action=='LONG')==(t['label_net']=='UP')
  group=groups[(method,point['symbol'],point['fold'],repeat)]
  group.append(TestPoint(len(group)+1,point['cutoff'],point['cutoff'],t['decision_close'],t['exit_close'],t['label_net'],t['net_return']*100.,prediction,correct,'N/A','N/A',prediction,correct,'N/A','N/A',0.,0.,entry_open=t['entry_open'],exit_close=t['exit_close'],entry_time=dates[1],exit_time=dates[3],**target_record_fields(t)))
  observations[(method,repeat)].append((action=='LONG',t['label_net']=='UP'))
 account_values={key:compute_account_metrics(value)['full'].total_return_pct for key,value in groups.items()}
 result=json.loads((root/'outputs/unified_integration/u09_analysis_r1/results.json').read_bytes())
 checks=[]
 for row in result['summary']:
  method=row['method'];accounts=[value for key,value in account_values.items() if key[0]==method]
  assert len(accounts)==153
  assert np.isclose(np.mean(accounts),row['mean_account_return_pct'],rtol=0,atol=1e-10)
  bas=[]
  for repeat in range(3):
   obs=observations[(method,repeat)];positive=sum(y for p,y in obs);negative=sum(not y for p,y in obs)
   bas.append(.5*(sum(p and y for p,y in obs)/positive+sum(not p and not y for p,y in obs)/negative)*100.)
  ba=float(np.mean(bas))
  assert np.isclose(ba,row['balanced_accuracy_pct'],rtol=0,atol=1e-12)
  checks.append({'method':method,'accounts':len(accounts),'mean_account_return_pct':float(np.mean(accounts)),'BA_pct':ba})
 proof={'status':'PASS_U09_INDEPENDENT_EVALUATOR_CROSSCHECK','methods':checks,'accounts_compared':1530,'forecast_records':2448,'source':'FROZEN_BACKTEST_ENGINE_CANONICAL_ACCOUNT_AND_SCALAR_BA_ORACLE','return_tolerance':1e-10,'BA_tolerance':1e-12,'new_api_calls':0}
 (Path(tempfile.gettempdir())/'u09_crosscheck.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(proof,ensure_ascii=False))
