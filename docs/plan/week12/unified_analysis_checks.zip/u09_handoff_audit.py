from pathlib import Path
import sys,json,hashlib,tempfile,zipfile,subprocess
root=Path.cwd();sys.path.insert(0,str(root))
from core.historical_evaluation_journal import load
from core.unified_contracts import digest
from core.unified_analysis.runtime import require,artifact_bindings,DIRECTORY
runtime=require(root);directory=root/DIRECTORY;p=Path(tempfile.gettempdir())
raw=(p/'u09_cold_verify.log').read_bytes()
if raw[:2]==bytes([255,254]):raw=raw.decode('utf-16').encode('utf-8');(p/'u09_cold_verify.log').write_bytes(raw)
cold=json.loads(raw);assert cold['status']=='PASS_U09_COLD_REPLAY' and cold['byte_identical'] and cold['artifact_count']==15
assert cold['artifacts']==artifact_bindings(directory)
cross=json.loads((p/'u09_crosscheck.json').read_text(encoding='utf-8'));assert cross['status']=='PASS_U09_INDEPENDENT_EVALUATOR_CROSSCHECK' and cross['accounts_compared']==1530
leak=json.loads((p/'u09_leakage.json').read_text(encoding='utf-8'));assert leak['status']=='PASS' and leak['tests']==4
old_package=root/'docs/plan/week12/unified_live_research.zip'
assert hashlib.sha256(old_package.read_bytes()).hexdigest()=='5936bc971bebf1b139a34b93f154ad8e54d0a0e37fdaa6ac4673295f8b60a11c'
with zipfile.ZipFile(old_package) as archive:
 sources=json.loads(archive.read('acceptance/u08_acceptance_sources.json'))
 journal=json.loads(archive.read('acceptance/u08_acceptance_inventory.json'))
 for name,value in journal.items():
  raw=(root/name).read_bytes();assert len(raw)==value['bytes'] and hashlib.sha256(raw).hexdigest()==value['sha256'],name
sources.update(runtime['sources'])
assert len(sources)==729
for name,value in sources.items():
 raw=(root/name).read_bytes();assert len(raw)==value['bytes'] and hashlib.sha256(raw).hexdigest()==value['sha256'],name
changes=set(subprocess.check_output(['git','diff','--name-only','2ead2bc9','HEAD'],text=True).splitlines())
assert not (set(sources)-set(runtime['sources'])) & changes
r=json.loads((directory/'results.json').read_bytes())
assert len(r['summary'])==10 and len(r['contrasts'])==20 and len(r['bridge'])==3
assert r['primary_joint_family']['joint_finite_draws']==10000 and r['primary_joint_family']['undefined_draws']==0
assert r['primary_joint_family']['index_sha256']=='09374ae6e221b701c9b2b88241135fd70a701e611e752a8b8ec5bf82b669b9a7'
assert set(r['sensitivity'])=={'BLOCK_LENGTH_1','BLOCK_LENGTH_3','LEAVE_ONE_FOLD_OUT','LEAVE_ONE_SYMBOL_OUT','CORE4_FIXED_SUBSET'}
proof={'status':'PASS_U09_HANDOFF','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtime_sha256':digest(runtime),'source_pins':len(sources),'u08_source_pins_unchanged':718,'u08_journal_files_unchanged':len(journal),'artifact_count':15,'accounts_checked_independently':1530,'tests':25,'related_leakage_tests':4,'compiled_python_files':8,'cold_replay':'PASS_BYTE_IDENTICAL_NEW_PROCESS','constructors_blocked':6,'external_network_blocked':True,'new_api_calls':0,'training':False,'numeric_provider_replay':False,'native_rowwise_causal_gate':'FAIL','whole_system_causal_gate':'NOT_CERTIFIED'}
(p/'u09_handoff_audit.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False))
