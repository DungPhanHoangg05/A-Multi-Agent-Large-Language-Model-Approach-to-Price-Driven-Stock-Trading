from pathlib import Path
import sys,tempfile,unittest,json,py_compile,hashlib
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
loader=unittest.TestLoader();suite=loader.discover(str(root/'tests/unified_analysis'),pattern='test_*.py')
for name in ('test_confusion_and_undefined_are_not_zero_filled','test_ratios_are_cycle_only_and_zero_downside_is_null','test_account_matches_independent_cash_math_and_keeps_gap_sessions','test_daily_mark_to_market_differs_from_cycle_end_drawdown','test_wrong_label_overlap_and_invalid_action_raise'):
 suite.addTests(loader.loadTestsFromName('test_free_pilot_statistics.PilotStatisticsTests.'+name))
def ids(value):
 for item in value:
  if isinstance(item,unittest.TestSuite):yield from ids(item)
  else:yield item.id()
test_ids=list(ids(suite));p=Path(tempfile.gettempdir())
with (p/'u09_tests.log').open('w',encoding='utf-8') as stream:result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
from core.unified_analysis.runtime import sources
pins=sources(root);compiled=[]
if result.wasSuccessful():
 for name in pins:
  if name.endswith('.py'):py_compile.compile(str(root/name),doraise=True);compiled.append(name)
record={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'test_ids':test_ids,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'compiled':compiled,'sources':pins,'log_sha256':hashlib.sha256((p/'u09_tests.log').read_bytes()).hexdigest(),'scope':'PAIRED_FOLD_BOOTSTRAP_20_JOINT_BANDS_ESTIMAND_REPEATS_MASKS_ECONOMICS_UNITS_ARCHIVE_INTEGRITY','inference_requests':0}
(p/'u09_tests.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:record[k] for k in ('status','tests','failures','errors','skips')},ensure_ascii=False))
if not result.wasSuccessful():print((p/'u09_tests.log').read_text(encoding='utf-8')[-14000:])
raise SystemExit(not result.wasSuccessful())
