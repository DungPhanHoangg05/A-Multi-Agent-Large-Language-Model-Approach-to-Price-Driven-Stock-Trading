from pathlib import Path
import sys,tempfile,unittest,json,hashlib
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
suite=unittest.TestLoader().loadTestsFromName('unified_live.test_leakage')
ids=[test.id() for group in suite for test in group]
p=Path(tempfile.gettempdir())
with (p/'u09_leakage.log').open('w',encoding='utf-8') as stream:r=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
record={'status':'PASS' if r.wasSuccessful() else 'FAIL','tests':r.testsRun,'test_ids':ids,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped),'log_sha256':hashlib.sha256((p/'u09_leakage.log').read_bytes()).hexdigest(),'scope':'SEALED_QUERY_LABEL_FIREWALL_AND_NINE_SYMBOL_FUTURE_POISON','new_api_calls':0}
(p/'u09_leakage.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record))
raise SystemExit(not r.wasSuccessful())
