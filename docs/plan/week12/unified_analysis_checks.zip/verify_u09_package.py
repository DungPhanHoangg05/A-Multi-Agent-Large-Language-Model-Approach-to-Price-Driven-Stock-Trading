"""Kiểm gói kết quả U09 nguyên byte bằng thư viện chuẩn, không inference."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile

def main() -> None:
    """Đối soát inventory, full cold proof và source pins local tùy chọn."""
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package',type=Path);parser.add_argument('--root',type=Path);args=parser.parse_args()
    with zipfile.ZipFile(args.package) as archive:
        manifest=json.loads(archive.read('manifest.json'));names=archive.namelist()
        assert len(names)==len(set(names)) and set(names)==set(manifest['members'])|{'manifest.json'}
        assert all(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts for name in names)
        for name,binding in manifest['members'].items():
            raw=archive.read(name)
            assert len(raw)==binding['bytes'] and hashlib.sha256(raw).hexdigest()==binding['sha256'],name
        result=json.loads(archive.read(manifest['namespace']+'/results.json'))
        assert result['status']=='PASS_U09_ANALYSIS' and result['points']==102 and result['repeats']==3
        assert len(result['contrasts'])==20 and len(result['bridge'])==3
        cold=json.loads(archive.read('evidence/u09_cold_verify.json'))
        assert cold['status']=='PASS_U09_COLD_REPLAY' and cold['byte_identical'] and cold['artifact_count']==15
        for name,binding in cold['artifacts'].items():assert manifest['members'][manifest['namespace']+'/'+name]==binding
        cross=json.loads(archive.read('evidence/u09_crosscheck.json'))
        assert cross['status']=='PASS_U09_INDEPENDENT_EVALUATOR_CROSSCHECK' and cross['accounts_compared']==1530
        if args.root:
            for name,binding in manifest['sources'].items():
                path=(args.root/name).resolve();assert path.is_relative_to(args.root.resolve())
                raw=path.read_bytes();assert len(raw)==binding['bytes'] and hashlib.sha256(raw).hexdigest()==binding['sha256'],name
            raw=(args.root/'docs/plan/week12/unified_live_research.zip').read_bytes()
            assert hashlib.sha256(raw).hexdigest()==manifest['u08_package_sha256']
        print(json.dumps({'status':'PASS_U09_RESULTS_PACKAGE','members':len(names),'analysis_artifacts':15,'source_pins_verified':729 if args.root else 0,'points':102,'forecast_slots':2448,'new_api_calls':0},ensure_ascii=False))

if __name__=='__main__':main()
