"""Kiểm bất biến nội dung và nguồn khóa cho chỉnh sơ đồ/layout F04."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT/'tmp/f04'
BASE = '9439e54e'


def bind(raw: bytes) -> dict:
    """Hash nguyên byte; không chuẩn hóa nguồn đã khóa."""
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def old(name: str) -> str:
    """Nội dung trước F04 từ commit Git, chuẩn LF chỉ cho đối chiếu cú pháp."""
    return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT).decode().replace('\r\n','\n')


content_release = json.loads((ROOT/'outputs/revision/manuscript_content_v1/manifest.json').read_bytes())
changed = []
for name, row in content_release['sources'].items():
    if bind((ROOT/name).read_bytes()) != row:
        changed.append(name)
assert set(changed) == {'paper/figs/final_flow.tex', 'paper/figs/revised_alpha_pipeline.tex',
    'paper/figs/revised_decision_pipeline.tex', 'paper/figs/revised_walkforward.tex',
    'paper/sections/04_system_architecture.tex', 'paper/sections/05_experimental_setup.tex',
    'paper/sections/06_backtest_results.tex'}, changed
blocks = 0
for path in (ROOT/'paper/sections').glob('*.tex'):
    name = path.relative_to(ROOT).as_posix()
    before, after = old(name), path.read_text(encoding='utf-8')
    titles = r'\\(?:section|subsection|subsubsection)\*?\{[^\n]+\}'
    assert re.findall(titles,before) == re.findall(titles,after), name
    math = r'\\begin\{(equation|align)\}(.*?)\\end\{\1\}'
    before_math, after_math = re.findall(math,before,re.S), re.findall(math,after,re.S)
    assert before_math == after_math, name
    blocks += len(before_math)
tex = '\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'paper').rglob('*.tex'))
labels = re.findall(r'\\label\{([^}]+)\}',tex)
assert len(labels) == len(set(labels))
assert set(re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',tex)) <= set(labels)
keys = re.findall(r'@\w+\{([^,]+),',(ROOT/'paper/references.bib').read_text(encoding='utf-8'))
assert {k.strip() for g in re.findall(r'\\cite\w*\{([^}]+)\}',tex) for k in g.split(',')} <= set(keys)
f02 = json.loads((ROOT/'outputs/revision/u09_manuscript_assets_v1/manifest.json').read_bytes())
for group in ('sources','inputs'):
    for name,row in f02[group].items():
        assert bind((ROOT/name).read_bytes()) == row, name
for name,row in f02['outputs'].items():
    assert bind((ROOT/'outputs/revision/u09_manuscript_assets_v1/artifacts'/name).read_bytes()) == row
for name in f02['installation']['members']:
    assert bind((ROOT/'paper/generated/u09'/name).read_bytes()) == f02['outputs'][name]
for name,row in content_release['outputs'].items():
    assert bind((ROOT/'outputs/revision/manuscript_content_v1'/name).read_bytes()) == row
for name,row in content_release['inputs'].items():
    assert bind((ROOT/name).read_bytes()) == row,name
assert bind((ROOT/'docs/plan/week12/unified_manuscript_checks.zip').read_bytes()) == {
    'bytes':5226,'sha256':'b1b00e3d26e724f2d164286196f4cc5b6f68d5053f797162c9c1c3ac5fe84b6c'}
assert bind((ROOT/'docs/plan/week12/manuscript_content_checks.zip').read_bytes()) == {
    'bytes':17791977,'sha256':'1eab72eb5591c98dd9a906a229328f23fd7b248f64738c41dc86cf5672809170'}
assert bind((ROOT/'outputs/revision/manuscript_content_v1/manifest.json').read_bytes()) == {
    'bytes':20696, 'sha256':'3de4994c93c76a810351a8101ff612b8b7736c4cc9c2bf27ea71ea5beb2ecb31'}
with zipfile.ZipFile(ROOT/'docs/plan/week12/final_evidence_snapshot.zip') as archive:
    snapshot = json.loads(archive.read('snapshot_manifest.json'))
    frozen = {**snapshot['frozen_packages'],**snapshot['legacy_archives']}
    for name,row in frozen.items():
        assert bind((ROOT/name).read_bytes()) == row, name
    # Đối soát đủ pin U09 từ bản inventory F01; không thay nguồn expected.
    u09_members = {name:row for name,row in snapshot['source_members'].items()
        if not name.startswith(('paper/','revision/'))}
    for name,row in u09_members.items():
        assert bind((ROOT/name).read_bytes()) == {k:row[k] for k in ('bytes','sha256')}, name
diagram_checks = {
    'upstream_once_and_shared_parent':'final_flow.tex',
    'native_common_and_separate_sentiment':'revised_alpha_pipeline.tex',
    'same_repeat_dependencies_fallback_raw_final_utility':'revised_decision_pipeline.tex',
    'prior_exit_cutoff_frozen_fits_all_test_ids_outcome_barrier':'revised_walkforward.tex'}
assert 'Q_{0.10}(\\Delta U)>0' in (ROOT/'paper/figs/revised_decision_pipeline.tex').read_text(encoding='utf-8')
assert 'exclude all 102 evaluation IDs' in (ROOT/'paper/figs/revised_walkforward.tex').read_text(encoding='utf-8')
proof = {'status':'PASS_F04_SOURCE_AND_CONTENT_CHECKS','baseline_commit':BASE,
    'original_paper_files':64,'changed_paper_files':changed,'unchanged_paper_files':64-len(changed),
    'all_equation_align_blocks_preserved':blocks,'comparison_normalization':'LF_ONLY_FOR_TEX_SYNTAX',
    'metadata_abstract_highlights_appendices_references_unchanged':True,
    'all_generated_tables_macros_chart_png_svg_unchanged':True,
    'f02_artifacts_unchanged':26,'f03_release_unchanged':True,
    'historical_packages_and_archives_unchanged':len(frozen),
    'snapshot_non_paper_revision_bindings_unchanged':len(u09_members),
    'diagram_semantics_reviewed_against':['core/variant_registry.py','core/unified_methods.py',
        'core/causal_alpha.py','core/mt_bicl_policy.py','paper/sections/03_problem_formulation.tex'],
    'diagram_checks':diagram_checks,'new_figure_label':'fig:u09-return-contrasts',
    'figure_display':'Two enlarged vertically stacked panels clipped in LaTeX from the same frozen PNG; source bytes unchanged',
    'runtime_code_changed':False,'unit_compile_e2e_leakage_rerun':False,
    'new_llm_market_api_calls':0,'new_inference_training_refit':False,
    'F05_reviewer_final_locators_and_publication_release_pending':True}
(WORK/'source_content_checks.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False))
