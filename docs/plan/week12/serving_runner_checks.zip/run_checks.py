"""Chạy hồi quy chọn lọc ở process riêng, không đổi source trong khi source guard chạy."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f08'
tracked = subprocess.check_output(['git','diff','--name-only','--','*.py'],cwd=ROOT).decode().splitlines()
added = subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.py'],cwd=ROOT).decode().splitlines()
sources = sorted(set(tracked+added))
for name in sources:
    py_compile.compile(str(ROOT/name),doraise=True)
(QA/'compiled.json').write_text(json.dumps({'status':'PASS','files':sources,'count':len(sources)},indent=2)+'\n',encoding='utf-8')
plans = [('tests/serving_runtime','test_runtime.py'),('tests/serving_runtime','test_api.py'),
         ('tests/serving_runtime','test_resources.py'),('tests','test_variant_serving.py'),
         ('tests','test_unified_experiment.py'),('tests','test_web_json_serialization.py'),
         ('tests','test_unified_execution_recovery.py'),('tests','test_unified_execution_leakage.py'),
         ('tests','test_unified_preflight_leakage.py'),('tests/unified_live','test_leakage.py'),
         ('tests','test_backtest_token_budget.py')]


def run(plan):
    """Log stdout/stderr nguyên byte UTF-8, không để PowerShell bọc NativeCommandError."""
    directory,pattern = plan
    command = [sys.executable,'-X','utf8','-m','unittest','discover','-s',directory,'-p',pattern,'-v']
    result = subprocess.run(command,cwd=ROOT,capture_output=True)
    name = directory.replace('/','_')+'_'+pattern.replace('.py','.log')
    (QA/name).write_bytes(result.stdout+b'\n'+result.stderr)
    text = result.stderr.decode('utf-8',errors='replace')
    import re
    count = re.search(r'Ran (\d+) tests?',text)
    return name,{'returncode':result.returncode,'tests':int(count[1]) if count else None,'command':command[1:],
                 'log_sha256':__import__('hashlib').sha256((QA/name).read_bytes()).hexdigest()}


results = {}
with ThreadPoolExecutor(max_workers=2) as pool:
    for future in as_completed([pool.submit(run,p) for p in plans]):
        name,result = future.result()
        results[name] = result
        print(name,result['returncode'],result['tests'],flush=True)
        (QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
if any(result['returncode'] for result in results.values()):
    sys.exit(1)
print('PASS',sum(r['tests'] for r in results.values()),flush=True)
