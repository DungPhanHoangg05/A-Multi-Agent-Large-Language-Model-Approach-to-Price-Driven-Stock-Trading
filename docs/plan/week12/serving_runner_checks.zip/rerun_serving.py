"""Kiểm lại đúng runtime mới sau guard không dùng model text thành pacing instruction."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f08'
for name in ('core/serving_runtime/transport.py','tests/serving_runtime/test_runtime.py'):
    py_compile.compile(str(ROOT/name),doraise=True)
plans = [('test_runtime.py',17),('test_api.py',4),('test_resources.py',5)]


def run(plan):
    """Mỗi process có model/module riêng; giữ source cố định tới khi xong."""
    pattern,count = plan
    command = [sys.executable,'-X','utf8','-m','unittest','discover','-s','tests/serving_runtime','-p',pattern,'-v']
    result = subprocess.run(command,cwd=ROOT,capture_output=True)
    raw = result.stdout+b'\n'+result.stderr
    name = 'tests_serving_runtime_'+pattern.replace('.py','.log')
    (QA/name).write_bytes(raw)
    return name,{'returncode':result.returncode,'tests':count,'command':command[1:],'log_sha256':hashlib.sha256(raw).hexdigest()}


results = json.loads((QA/'test_results.json').read_bytes())
with ThreadPoolExecutor(max_workers=2) as pool:
    for future in as_completed([pool.submit(run,p) for p in plans]):
        name,result = future.result(); results[name] = result
        print(name,result['returncode'],flush=True)
(QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
sys.exit(0 if all(r['returncode']==0 for r in results.values()) else 1)
