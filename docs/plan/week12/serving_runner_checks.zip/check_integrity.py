"""Kiểm evidence cũ nguyên byte và resource serving riêng, không chạy lại nghiên cứu."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
DOC = ROOT/'docs/plan/week12'


def binding(raw):
    """Digest byte thực."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


with zipfile.ZipFile(DOC/'unified_analysis_results.zip') as archive:
    pins = {name:{key:row[key] for key in ('bytes','sha256')}
            for name,row in json.loads(archive.read('manifest.json'))['sources'].items()}
with zipfile.ZipFile(DOC/'final_evidence_snapshot.zip') as archive:
    snapshot = json.loads(archive.read('snapshot_manifest.json'))
    for name,expected in pins.items():
        assert binding(archive.read(name)) == expected,name
    changed = sorted(name for name,expected in pins.items() if binding((ROOT/name).read_bytes()) != expected)
    assert changed == ['scripts/.gitattributes','templates/experiments.html','utils/experiment_web.py','web_interface.py'],changed
    for group in ('frozen_packages','legacy_archives'):
        for name,expected in snapshot[group].items():
            assert binding((ROOT/name).read_bytes()) == expected,name
release = ROOT/'outputs/revision/manuscript_unified_final_v1'
manifest = json.loads((release/'manifest.json').read_bytes())
assert binding((release/'manifest.json').read_bytes()) == {'bytes':55249,'sha256':'8e5ce2a4ca6f3a52945047cb8e1e1e99e8c00dfcd959a6fc6cdadcd701013de9'}
for name,expected in manifest['outputs'].items():
    assert binding((release/name).read_bytes()) == expected,name
for name,expected in manifest['sources'].items():
    assert binding((ROOT/name).read_bytes()) == expected,name
for name in ('core/variant_registry.py','core/unified_methods.py','core/unified_contracts.py','core/unified_experiment.py',
             'core/backtest_engine.py','core/unified_live','core/unified_asset_providers.py',
             'templates/demo_new.html','templates/output.html','templates/backtest.html','templates/experiments.html'):
    assert subprocess.check_output(['git','diff','--exit-code','5fd45e2b','--',name],cwd=ROOT) == b'',name
from core.serving_runtime.resources import Resources, MANIFEST_SHA256
resources = Resources(ROOT)
resources.verify()
import pandas as pd
protocol = json.loads((ROOT/'docs/plan/week11/historical_evaluation_protocol.json').read_bytes())['payload']
calendar = pd.DatetimeIndex(pd.read_csv(ROOT/protocol['effective_mt_bicl']['calendar']['source'],
                                     parse_dates=['Datetime']).Datetime).strftime('%Y-%m-%d').tolist()
windows = 0
for symbol in resources.document()['support']['symbols']:
    dates = json.loads((ROOT/f'outputs/unified_integration/u06_assets_v2/prices/{symbol}.json').read_bytes())['Datetime']
    for cutoff in resources.document()['support']['calendar']:
        master_index, price_index = calendar.index(cutoff), dates.index(cutoff)
        assert calendar[master_index:master_index+4] == dates[price_index:price_index+4],(symbol,cutoff)
        assert len(calendar[master_index:master_index+4]) == 4
        windows += 1
assert windows == 522
result = {'status':'PASS_F08_INTEGRITY','base_commit':'5fd45e2b','u09_source_pins':729,'current_source_matches':725,
    'historical_snapshot_restores':729,'intentional_changed_pins':changed,
    'frozen_packages_unchanged':20,'legacy_archives_unchanged':30,'f05_outputs_unchanged':11,'f05_sources_unchanged':68,
    'resource_manifest_sha256':MANIFEST_SHA256,'resource_bindings':len(resources.document()['bindings']),
    'symbols':resources.document()['support']['symbols'],'sessions':len(resources.document()['support']['calendar']),
    'entry_exit_calendar_windows_verified':windows,'calendar_mismatches':0,
    'new_hosted_llm_calls':0,'new_market_calls':0,'new_hmm_student_bank_training':0}
(ROOT/'tmp/f08/integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
