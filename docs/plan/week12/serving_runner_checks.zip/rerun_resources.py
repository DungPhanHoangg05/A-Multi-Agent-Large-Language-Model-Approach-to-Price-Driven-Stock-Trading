"""Chạy lại file resource sau sửa fixture tín hiệu, giữ nguyên log thất bại ban đầu."""
from pathlib import Path
import hashlib
import json
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f08'
name = 'tests_serving_runtime_test_resources.log'
old = (QA/name).read_bytes()
if not (QA/'initial_resource_fixture_failure.log').exists():
    (QA/'initial_resource_fixture_failure.log').write_bytes(old)
py_compile.compile(str(ROOT/'tests/serving_runtime/test_resources.py'),doraise=True)
command = [sys.executable,'-X','utf8','-m','unittest','discover','-s','tests/serving_runtime','-p','test_resources.py','-v']
result = subprocess.run(command,cwd=ROOT,capture_output=True)
raw = result.stdout+b'\n'+result.stderr
(QA/name).write_bytes(raw)
results = json.loads((QA/'test_results.json').read_bytes())
results[name] = {'returncode':result.returncode,'tests':5,'command':command[1:],'log_sha256':hashlib.sha256(raw).hexdigest()}
(QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print('resource',result.returncode,flush=True)
if result.returncode:
    print(result.stderr.decode('utf-8',errors='replace'))
sys.exit(result.returncode)
