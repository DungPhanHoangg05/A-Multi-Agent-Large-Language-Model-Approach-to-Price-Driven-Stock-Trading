"""Đóng QA serving mới, giữ source/runtime/log và ranh giới không chạy hosted smoke."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import unicodedata
import zipfile

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f08'
TARGET = ROOT/'docs/plan/week12/serving_runner_checks.zip'


def binding(raw):
    """Giữ byte gốc khi archive."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def slug(text):
    """Anchor Unicode theo tài liệu hiện có."""
    text = re.sub('<[^>]+>','',text).lower().replace(' ','-')
    return ''.join(c for c in text if c in '-_' or unicodedata.category(c)[0] in 'LN')


results = json.loads((QA/'test_results.json').read_bytes())
assert len(results) == 11 and sum(v['tests'] for v in results.values()) == 105
assert all(v['returncode'] == 0 for v in results.values())
for name,record in results.items():
    raw = (QA/name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == record['log_sha256']
    assert re.search(rb'\nOK\s*$',raw),name
    assert b'skipped=' not in raw,name
compiled = json.loads((QA/'compiled.json').read_bytes())
assert compiled['count'] == 18
TARGET.touch(exist_ok=True)
documents = ('docs/plan/plan.md','docs/plan/week12/README.md','docs/plan/week12/final_paper_ui_plan.md',
             'docs/plan/week12/variant_serving_contract.md')
links = 0
for name in documents:
    path = ROOT/name
    for target in re.findall(r'(?<!!)\[[^]\n]*\]\(([^)\n]+)\)',path.read_text(encoding='utf-8')):
        if '://' in target or target.startswith('mailto:'):
            continue
        rel,_,anchor = target.partition('#')
        destination = (path.parent/rel).resolve() if rel else path
        assert destination.exists(),(name,target)
        if anchor:
            assert anchor in [slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$',destination.read_text(encoding='utf-8'),re.M)],(name,target)
        links += 1
readme,plan = ((ROOT/documents[i]).read_text(encoding='utf-8') for i in (1,2))
assert '- [x] F08' in readme and '| F08 | ☑ Hoàn tất |' in plan
for task in range(9,13):
    name = f'F{task:02}'
    assert '- [ ] '+name in readme and '| '+name+' | ☐ Chưa bắt đầu |' in plan
sources = {name:binding((ROOT/name).read_bytes()) for name in compiled['files']}
sources['docs/plan/week12/serving_resources_v1.json'] = binding((ROOT/'docs/plan/week12/serving_resources_v1.json').read_bytes())
sources['scripts/.gitattributes'] = binding((ROOT/'scripts/.gitattributes').read_bytes())
integrity = json.loads((QA/'integrity.json').read_bytes())
checks = {'status':'PASS_F08_SCOPED_SERVING','base_commit':'5fd45e2b','test_suites':results,'tests_passed':105,
    'leakage_regressions':18,'compiled_python_files':18,'source_bindings':sources,
    'runtime':subprocess.check_output(['py','-3.13','--version']).decode().strip(),
    'support_version':'serving_asof_q3_2026_v1','resource_bindings':188,'symbols':9,'calendar_sessions':58,
    'first_date':'2026-07-01','last_date':'2026-09-23','max_points_per_job':30,'repeat_range':[1,3],
    'artifact_verify_command':'py -3.13 -X utf8 scripts/prepare_serving_resources.py --restore-assets --verify',
    'real_provider_smoke':'NEW_QUERY_2026_07_02; ACTUAL_RESOURCES_AND_ADAPTERS; FIXTURE_HTTP_ONLY',
    'required_mt_path':'RAW_MT_RESPONSE_ASSERTED_WHEN_ELIGIBLE; NUMERIC_VETO_UNCHANGED',
    'initial_findings':['SQLite connections now explicitly closed on Windows; temp cleanup regression PASS',
                        'OOD test fixture signal labels repaired; entire resource test file rerun PASS',
                        'Successful LLM response text cannot set retry delay; 26 serving tests rerun PASS'],
    'new_hosted_llm_calls':0,'new_market_calls':0,'new_hmm_student_bank_training':0,
    'selector_integrity':'REPLAY_LOCKED_TRAIN_VALIDATION_ONLY','native_alpha':'EXISTING_NATIVE_PROFILE_BEHAVIOR',
    'ui_template_changes':0,'hosted_smoke':'NOT_RUN; F11_SCOPE_REQUIRED_IF_NEEDED',
    'scientific_limits':{'native_rowwise_causal_gate':'FAIL','whole_system_causal_gate':'NOT_CERTIFIED'},
    'local_links':links,'checklist_synchronized':True,'integrity':integrity}
members = {'checks.json':(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()}
for name in (*results,'test_results.json','compiled.json','integrity.json','initial_resource_fixture_failure.log',
             'run_checks.py','rerun_resources.py','rerun_serving.py','check_integrity.py','seal_checks.py'):
    members[name] = (QA/name).read_bytes()
members['manifest.json'] = (json.dumps({n:binding(v) for n,v in members.items()},indent=2)+'\n').encode()
with zipfile.ZipFile(TARGET,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in members.items():
        archive.writestr(name,raw)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    for name,raw in members.items():
        assert archive.read(name) == raw
print(json.dumps({'status':checks['status'],'tests':105,'compiled':18,'links':links,'members':len(members),
                  'package':binding(TARGET.read_bytes())}))
