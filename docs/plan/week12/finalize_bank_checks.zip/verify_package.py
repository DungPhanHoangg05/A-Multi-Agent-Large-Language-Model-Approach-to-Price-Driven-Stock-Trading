"""Kiểm byte nguồn, đầu ra và runtime FIN06 trong tiến trình độc lập."""
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys
import zipfile


def sha(data: bytes) -> str:
    """Băm nguyên byte nguồn hoặc log."""
    return hashlib.sha256(data).hexdigest()


def envelope(data: bytes) -> dict:
    """Kiểm checksum trước khi dùng payload."""
    document = json.loads(data)
    payload = document["payload"]
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    assert sha(raw) == document["sha256"]
    return payload


archive, root = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(archive) as package:
    manifest = envelope(package.read("manifest.json"))
    assert set(package.namelist()) == set(manifest["members"]) | {"manifest.json"}
    for name, pin in manifest["members"].items():
        raw = package.read(name)
        assert len(raw) == pin["bytes"] and sha(raw) == pin["sha256"], name
    for pin in manifest["bindings"]:
        raw = (root / pin["path"]).read_bytes()
        assert len(raw) == pin["bytes"] and sha(raw) == pin["sha256"], pin["path"]
    assert platform.python_version() == manifest["runtime"]["python"]
    assert all(version(name) == expected for name, expected in manifest["runtime"]["packages"].items())
    for name, count in manifest["test_counts"].items():
        log = package.read(name + ".log")
        assert f"Ran {count} tests".encode() in log and log.strip().endswith(b"OK")
    build, replay = (json.loads(package.read(name + ".log")) for name in ("build", "replay"))
    assert build == replay and build["bank_numeric_records"] == 852 and build["signal_ready"] == 0
    assert build["query_input_count"] == 102 and not build["FIN06_complete"]
    assert build["hosted_api_calls"] == 0 and not build["query_outcomes_computed"]
    print("PASS: nguồn, đầu ra, runtime và nhật ký FIN06. Bank tín hiệu còn chờ xác minh.")
