﻿from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
from datetime import datetime,timezone
import sys,json,tempfile,hashlib
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
from core.unified_provider_quota.runtime import audit
with ExitStack() as stack:
 for name in ('httpx.Client','httpx.AsyncClient','httpx.HTTPTransport','langchain_groq.ChatGroq','dotenv.dotenv_values','core.unified_execution_providers.StudyProviders'):
  stack.enter_context(patch(name,side_effect=AssertionError('Cold audit cấm key/client/provider: '+name)))
 result=audit(root)
assert result['status']=='PARTIAL_U08' and result['complete_points']==38
assert result['forecast_slots']==912 and result['http_attempts']==591
assert result['first_model_scoped_http_sequence']==487 and result['first_provider_scoped_http_sequence']==591
assert len(result['current_admission_probe'])==10
assert all(item['reserve']==8000 and item['admission']=='READY' for item in result['current_admission_probe'])
p=Path(tempfile.gettempdir());before=json.loads((p/'provider_quota_original_bindings.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha for name,sha in before.items())
result.update(audit_status='PASS_PROVIDER_QUOTA_COLD_HANDOFF',checkpoint_files_unchanged=len(before),actual_new_http_attempts=0,constructors_blocked=6,external_network_blocked=True,verified_at_utc=datetime.now(timezone.utc).isoformat())
(p/'provider_quota_cold_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
