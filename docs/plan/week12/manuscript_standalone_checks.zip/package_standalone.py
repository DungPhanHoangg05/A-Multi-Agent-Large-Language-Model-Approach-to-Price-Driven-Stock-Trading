"""Đóng gói bản thảo độc lập và QA, giữ nguyên toàn bộ release cũ."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
import json
import re
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
BUILD=WORK/'build5'
OUT=ROOT/'outputs/revision/manuscript_standalone_v1'
OUT.mkdir(exist_ok=False)
digest=lambda raw:hashlib.sha256(raw).hexdigest()
encoded=lambda item:(json.dumps(item,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode('utf-8')
checks=json.loads((WORK/'checks.json').read_text(encoding='utf-8'))
checks['visual_review']={'result':'PASS','contact_pages':{'main':44,'main_submit':44},
                         'individual_main_pages':[13,17,26,38],
                         'scope':'Kiểm toàn bố cục; đọc riêng sơ đồ đổi nhãn, biểu đồ vector và bảng nhiều panel.'}
checks['bibtex_notice']='Bài ICLR điện tử Xie et al. không có số trang; giữ metadata hợp lệ, không tạo số trang giả.'
(WORK/'checks.json').write_bytes(encoded(checks))
for name in ('main','main_submit'):
    shutil.copyfile(BUILD/name/(name+'.pdf'),OUT/(name+'.pdf'))
(OUT/'pdf_anchors.json').write_bytes(encoded({x['entrypoint']:x['anchors'] for x in checks['pdfs']}))
sources=[]
with ZipFile(OUT/'overleaf.zip','x',ZIP_DEFLATED) as archive:
    for path in sorted((ROOT/'paper').rglob('*')):
        if path.is_file():
            raw=path.read_bytes()
            # Hai bản biên dịch phải đúng nguồn đang bàn giao.
            assert raw==(BUILD/'main'/path.relative_to(ROOT/'paper')).read_bytes(),path
            sources.append({'path':path.relative_to(ROOT).as_posix(),'bytes':len(raw),'sha256':digest(raw)})
            archive.writestr(path.relative_to(ROOT/'paper').as_posix(),raw)
with ZipFile(OUT/'overleaf.zip') as archive:
    assert archive.testzip() is None
    for item in sources:
        assert digest(archive.read(item['path'].removeprefix('paper/')))==item['sha256']

ledger=json.loads((ROOT/'outputs/revision/manuscript_layout_references_v1/reference_ledger.json').read_text(encoding='utf-8'))
ledger['cited_references_before']=43
ledger['cited_references_after']=43
ledger['new_bibtex_entries']=[]
for item in ledger['entries']:
    if item['key']=='vsd2022settlement':
        item['note']='Historical announcement on the settlement schedule'
ledger['verification_scope']='Giữ 43 nguồn đã kiểm trong bản trước; chỉ bỏ ghi chú mang ngôn ngữ audit của nguồn settlement.'
(OUT/'reference_ledger.json').write_bytes(encoded(ledger))

qa=ROOT/'docs/plan/week12/manuscript_standalone_checks.zip'
with ZipFile(qa,'x',ZIP_DEFLATED) as archive:
    for name in ('edit_manuscript.py','finish_editorial.py','polish_and_plot.py','build_paper.py','qa_standalone.py','package_standalone.py','checks.json','main_render.log','main_submit_render.log'):
        archive.write(WORK/name,name)
    archive.write(BUILD/'commands.json','build_commands.json')
    for name in ('main','main_submit'):
        for path in sorted((BUILD/name).iterdir()):
            if path.suffix in ('.log','.aux','.bbl','.blg','.fls','.out'):
                archive.write(path,name+'/'+path.name)
        for path in sorted((WORK/('render_release_'+name)).glob('page-*.png')):
            archive.write(path,'render/'+name+'/'+path.name)
        for path in sorted(WORK.glob(name+'_contact_*.png')):
            archive.write(path,'contact/'+name+'/'+path.name)
with ZipFile(qa) as archive:
    assert archive.testzip() is None

previous=ROOT/'outputs/revision/manuscript_layout_references_v1/manifest.json'
manifest={'schema':'standalone_manuscript_release_v1','created_date':'2026-11-13',
          'status':'PASS_LOCAL_STANDALONE_MANUSCRIPT',
          'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
          'baseline_manifest':previous.relative_to(ROOT).as_posix(),'baseline_manifest_sha256':digest(previous.read_bytes()),
          'sources':sources,
          'outputs':[{'path':path.name,'bytes':path.stat().st_size,'sha256':digest(path.read_bytes())} for path in sorted(OUT.iterdir())],
          'qa':{'path':qa.relative_to(ROOT).as_posix(),'bytes':qa.stat().st_size,'sha256':digest(qa.read_bytes())},
          'validation':checks,
          'display_aliases':{'bayesian_v1':'Bayesian prior / Bayesian','C2':'Conditional prior / Conditional',
                             'A_tp_pool':'Trend-pattern prior / Trend-pattern','B_semantic':'Explicit-count prior / Explicit counts',
                             'CORE4':'bank-covered stocks / Covered','OOD5':'other stocks / Other'},
          'plot_source':{'path':'paper/generated/u09/contrasts.tex','scope':'Vẽ mười contrast return từ đúng điểm và cận ba chữ số đang có trong bảng; không chạy lại phân tích.'},
          'boundaries':['Chỉ biên tập tài liệu, nhãn hiển thị và bố cục; không đổi danh tính runtime hoặc kết quả nghiên cứu.',
                        'Không chạy inference, scoring, thống kê, unit/E2E/leakage hoặc compileall.',
                        'Mã task bỏ khỏi PDF; khóa nguồn/nhãn nội bộ giữ trong provenance để truy nguyên bằng chứng.',
                        'Các receipt và gói lịch sử giữ nguyên phạm vi; không nâng chứng nhận khoa học hoặc quyền công bố.']}
manifest['sha256']=digest(encoded(manifest))
(OUT/'manifest.json').write_bytes(encoded(manifest))
print('Đã đóng gói',len(sources),'nguồn; QA',qa.stat().st_size,'byte')
