"""Kiểm caption, vị trí float, thuật ngữ độc lập, số liệu và PDF đã biên tập."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import re
import subprocess
import fitz
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
BUILD=WORK/'build5'
checks={}
canonical=lambda text: text.replace('Bayes v1','Bayesian').replace('C2','Conditional').replace('CORE4','Covered').replace('OOD5','Other')
with ZipFile(WORK/'before_sources.zip') as before, ZipFile(ROOT/'outputs/revision/manuscript_layout_references_v1/overleaf.zip') as baseline:
    assert all(before.read(name)==baseline.read(name.removeprefix('paper/')) for name in before.namelist())
    panels=equations=macros=0
    for name in before.namelist():
        if not name.endswith('.tex'):
            continue
        old=before.read(name)
        new=(ROOT/name).read_bytes()
        if '/generated/' in name:
            if 'summary_numbers' in name:
                assert old==new,name
                macros+=1
            old_tables=re.findall(rb'\\begin\{tabular\}.*?\\end\{tabular\}',old,re.S)
            new_tables=re.findall(rb'\\begin\{tabular\}.*?\\end\{tabular\}',new,re.S)
            assert len(old_tables)==len(new_tables),name
            for a,b in zip(old_tables,new_tables):
                numbers=lambda raw: re.findall(r'[-+]?\d+(?:\.\d+)?',canonical(raw.decode('utf-8')))
                assert numbers(a)==numbers(b),(name,numbers(a),numbers(b))
                panels+=1
        if '/sections/' in name:
            pattern=rb'\\begin\{(?:equation\*?|align\*?)\}.*?\\end\{(?:equation\*?|align\*?)\}'
            a=re.findall(pattern,old,re.S)
            assert a==re.findall(pattern,new,re.S),name
            equations+=len(a)
    checks.update(baseline_source_files=len(before.namelist()),numeric_table_panels_preserved=panels,
                  equation_blocks_preserved=equations,macro_files_byte_preserved=macros)

captions=[]
notes=[]
floats=[]
for path in (ROOT/'paper').rglob('*.tex'):
    text=path.read_text(encoding='utf-8')
    for kind,spec in re.findall(r'\\begin\{(table|figure|algorithm)\}\[([^\]]+)\]',text):
        assert spec=='htb',(path,kind,spec)
        floats.append(kind)
    for caption in re.findall(r'\\caption\{([^\n]*)\}',text):
        assert len(re.findall(r'[.!?](?:\s|$)',caption))==1,(path,caption)
        assert len(caption.split())<=25,(path,caption)
        captions.append(caption)
    for note in re.findall(r'\\begin\{minipage\}\{\\textwidth\}\\footnotesize (.*?)\\end\{minipage\}',text,re.S):
        assert len(re.findall(r'[.!?](?:\s|$)',note))==1,(path,note)
        assert len(note.split())<=40,(path,note)
        notes.append(note)
assert len(captions)==29 and len(notes)==21 and len(floats)==29
checks.update(single_sentence_captions=len(captions),single_sentence_table_notes=len(notes),htb_float_counts={k:floats.count(k) for k in set(floats)})

def inspect(name: str) -> dict:
    """Kiểm nội dung/hình học, rồi render mọi trang bằng Poppler."""
    folder=BUILD/name
    log=(folder/(name+'.log')).read_text(encoding='utf-8',errors='replace')
    defects=re.findall(r'(?m)^.*(?:Overfull|LaTeX Warning|Package .+ Warning|Missing character).*$' ,log)
    assert not defects,defects
    assert 'undefined' not in log.lower()
    bbl=(folder/(name+'.bbl')).read_text(encoding='utf-8')
    keys=re.findall(r'\\bibitem\{([^}]+)\}',bbl)
    assert len(keys)==43 and keys[5]=='tsantekidis2017lob'
    doc=fitz.open(folder/(name+'.pdf'))
    text='\n'.join(page.get_text() for page in doc)
    prohibited=r'\bU\d{2}\b|\bF0\d\b|\bC2\b|CORE4|OOD5|reviewer|editorial|receipt|acceptance|docs/plan|outputs/revision'
    assert not re.findall(prohibited,text,re.I),re.findall(prohibited,text,re.I)
    outside=[]
    type3=[]
    for index,page in enumerate(doc):
        outside.extend([index+1,word[4]] for word in page.get_text('words') if word[0]<0 or word[1]<0 or word[2]>page.rect.width+.5 or word[3]>page.rect.height+.5)
        type3.extend(font[3] for font in page.get_fonts() if font[2]=='Type3')
    assert not outside and not type3,(outside,type3)
    aux=(folder/(name+'.aux')).read_text(encoding='utf-8')
    labels=re.findall(r'\\newlabel\{((?:tab|fig|alg):[^}]+)\}\{\{([^}]+)\}\{([^}]+)\}',aux)
    assert len(labels)==29
    anchors={}
    for label,number,logical_page in labels:
        prefix='Table' if label.startswith('tab:') else 'Figure' if label.startswith('fig:') else 'Algorithm'
        pages=[i+1 for i,page in enumerate(doc) if prefix+' '+number+':' in page.get_text()]
        assert len(pages)==1,(label,pages)
        anchors[label]={'number':number,'latex_page':logical_page,'pdf_page':pages[0]}
    render=WORK/('render_release_'+name)
    render.mkdir(exist_ok=True)
    result=subprocess.run(['pdftoppm','-r','100','-png',str((folder/(name+'.pdf')).relative_to(WORK)),str((render/'page').relative_to(WORK))],cwd=WORK,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (WORK/(name+'_render.log')).write_bytes(result.stdout)
    assert result.returncode==0
    pages=sorted(render.glob('page-*.png'))
    assert len(pages)==len(doc)
    for start in range(0,len(pages),8):
        sheet=Image.new('RGB',(1200,900),'#dddddd')
        draw=ImageDraw.Draw(sheet)
        for offset,path in enumerate(pages[start:start+8]):
            image=Image.open(path)
            image.thumbnail((292,415))
            x=(offset%4)*300;y=(offset//4)*450
            sheet.paste(image,(x,y+22));draw.text((x+5,y+3),str(start+offset+1),fill='black')
        sheet.save(WORK/(name+'_contact_'+str(start//8+1)+'.png'))
    return {'entrypoint':name,'pages':len(doc),'references':len(keys),'reference_keys':keys,
            'anchors':anchors,'prohibited_visible_terms':[],'overfull_or_latex_warnings':defects,
            'underfull_notices':log.count('Underfull'),'words_outside_page':outside,'type3_fonts':type3,
            'poppler_pages':len(pages),'pdf_sha256':hashlib.sha256((folder/(name+'.pdf')).read_bytes()).hexdigest()}

with ThreadPoolExecutor(max_workers=2) as pool:
    checks['pdfs']=list(pool.map(inspect,('main','main_submit')))
(WORK/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in checks.items() if k!='pdfs'},ensure_ascii=False))
for item in checks['pdfs']:
    print(item['entrypoint'],item['pages'],item['references'])
