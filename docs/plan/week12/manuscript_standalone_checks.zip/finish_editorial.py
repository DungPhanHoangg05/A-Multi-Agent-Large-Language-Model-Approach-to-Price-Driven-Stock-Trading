"""Hoàn thiện phụ lục, ghi chú và cách diễn đạt khoa học của bản độc lập."""
from pathlib import Path
import re

PAPER = Path(__file__).resolve().parents[2] / 'paper'
p = PAPER / 'sections/appendices.tex'
s = p.read_text(encoding='utf-8')
a = s.index(r'\FloatBarrier' + '\n' + r'\section{LangGraph State Schema}')
s = r'''\FloatBarrier
\appendix
\section{Agent Prompt Specifications}
\label{app:prompts}
The agents use Vietnamese requests with the following role-level inputs and output requirements; complete messages and image inputs are retained in the research archive.

\subsection{Decision Agent}
\label{app:prompt_decision}
Decision receives condensed technical, pattern and trend reports with enabled factor/sentiment sections, then returns direction, horizon, confidence, risk/reward, supporting/opposing evidence and justification. Full enables factors and sentiment, Base omits both, and the factorial variants enable individual components or a past-donor replacement. Main/upstream requests use compact factor text, while factorial requests contain five explicit rows.

Historical priors use the Common reports and add qualified examples or conditional statistics. The Bayesian prior displays at most three matured same-stock examples. The conditional prior matches Trend/Pattern/Alpha/Indicator states; the trend--pattern prior relaxes the statistics match to Trend/Pattern; the explicit-count prior explains the conditional counts and intervals in more detail. For conditional methods, population support must be at least 20; a statistic additionally requires conditional support of five and credible-interval width at most 0.75. Example selection uses $K=3$, seed 42, signal weight 0.5, a 365-day recency half-life, maximum age 730 days, similarity threshold 0.625 and minimum five-session spacing. Statistics and examples have separate readiness checks, and an empty prior retains Common's action.

Fact anchor receives deterministic fact assertions and the completed Common reply. MT-BICL additionally receives prior/target task summaries, query features, student probability and teacher utility when context is eligible. Both requests identify the source facts and anchor. Each prior/context prefix is at most 600 characters, and the full request is below 6,500 characters. Fact checks enforce the declared assertions; the external utility policy controls whether a changed MT proposal is accepted.

\subsection{Pattern Agent}
\label{app:prompt_pattern}
Pattern receives a candlestick chart and reports pattern, confidence, directional bias, evidence, key candles and trading implication. Green bodies indicate Close greater than Open; red includes the remaining cases. A numerical consistency check compares directional claims with selected OHLCV properties.

\subsection{Trend Agent}
\label{app:prompt_trend}
Trend receives a chart with blue support and red resistance lines and reports direction, levels, slope, price position, analysis, forecast and confidence. The Vietnamese request retains inherited high-frequency terminology while the experiment supplies daily bars.

\subsection{Indicator Report}
\label{app:prompt_indicator}
Indicator deterministically renders five numerical votes, their counts and heuristic confidence using the rules in \ref{app:indicator_logic}, without a separate reporting-model call.

\subsection{Sentiment Report}
\label{app:prompt_sentiment}
The sentiment input contains saved classifier scores, aggregate counts and availability flags as defined in Section~\ref{sec:formulation}; the evaluated provider supplies empty article-detail and peer lists.

\subsection{Alpha Report}
\label{app:prompt_alpha}
Alpha formats numerical factor values and diagnostic skill fields for Decision; this backtest path does not make an additional Alpha reasoning-model call.

''' + s[a:]
b = s.index(r'\section{LangGraph State Schema}')
c = s.index(r'\FloatBarrier' + '\n' + r'\setcounter{table}{0}' + '\n' + r'\section{Custom Alpha')
s = s[:b] + r'''\section{Shared State and Forecast Records}
\label{app:state_schema}
The shared state contains the stock, timeframe, as-of cutoff, observed OHLCV prefix, chart images and five reports. Sentiment observations and availability flags are stored separately from their rendered report. The deterministic Indicator node returns its summary without populating every numerical array declared by the general application schema.

Each immutable snapshot identifies the stock/date/fold, upstream realization, reports, images and causal alpha projection. Forecast records add method, repeat, request identity, optional raw reply and context trace. Policy records retain the raw proposal, final action, fallback/rejection reason and anchor/utility evidence. All required forecasts for a point are persisted before canonical decision/entry/exit prices and net labels enter the outcome record. Missing dependencies, duplicate raw-response reuse and source/data mismatches raise errors rather than becoming CASH observations.

''' + s[c:]
e = s.index(r'\section{Software Dependencies and Reproducibility}')
f = s.index(r'\FloatBarrier' + '\n' + r'\setcounter{table}{0}' + '\n' + r'\section{Additional Account')
s = s[:e] + r'''\section{Software and Historical-Context Resources}
\label{app:software}
The experiments use Python 3.13.5 with pinned numerical, graph, model-client and chart dependencies. The local sentiment backend uses Transformers \cite{wolf2020transformers}; technical indicators use TA-Lib. Exact inputs, requests, responses, errors and checkpoints are archived with hashes. Replaying saved predictions reproduces metric calculations, while new hosted outputs may differ. Installation and application-interface instructions are provided in the repository.

\paragraph{Tasks and numerical features}
A task is a same-stock segment of 63 observed sessions, distinct from an individual prediction query. Context contains up to three prior tasks and at most eight matured observations per prior/target task, with disjoint IDs and holding intervals. Four coordinates represent five/twenty-session momentum, twenty-session volatility and distance from the twenty-session moving average. Training fixes the scaler and clipping. Factual buckets use the signs of MACD minus signal and Close minus SMA20; zero or missing axes produce UNKNOWN. Context is fixed before the first query of each fold and excludes all 102 evaluation IDs.

\paragraph{Teacher, student and utility}
The teacher uses conjugate Bayesian updating \cite{gelman2013bayesian} with sixteen Beta components on $\mu\in\{0.2,0.4,0.6,0.8\}$ and $\kappa\in\{2,8,32,128\}$, where $\alpha=\mu\kappa$ and $\beta=(1-\mu)\kappa$. Training-only MAP-EM estimates mixture weights \cite{dempster1977em}, and target successes/failures update the task posterior. The causal-mask student uses task/role markers and observed context labels with the query label masked; checkpoint seed 42/step 3000 is fixed before evaluation. Its probability is supplied as context separately from teacher utility.

Utility support requires at least two prior tasks and five gains/five losses among admitted magnitude observations. The 4,096 utility draws combine teacher-posterior probabilities with Bayesian-bootstrap gain/loss magnitudes \cite{rubin1981bootstrap}. Neither teacher nor student is refitted during inference.

\paragraph{Regime and selector resources}
The historical-context environment fixes 107 package versions, 51 stock--fold alpha selectors, HMM, scaler, teacher and student. VN-Index regime estimates use only observations available by the cutoff and forward filtering with recorded fit/training-end dates. Bank and query inputs have separate provenance, and all test labels remain outside historical context. These resource pins identify numerical inputs and local models; hosted aliases do not identify immutable served weights.

''' + s[f:]
s = s.replace('The custom formulas below specify native handlers and distinguish their preprocessing from prototype/fallback implementations. ``Custom\'\' describes their role in this implementation; it is not a validated novelty or profitability claim. The following formulas precede native global normalization and IC orientation. Handler identities are not the rank of a selected display row.',
'''The native custom factors in Table~\\ref{tab:custom_definitions} precede global normalization and IC orientation. Here $a_t$ is one-bar percentage change divided by rolling twenty-bar sample SD with a minimum of five observations, $H_t$ is MACD(12,26,9) histogram, and $CP_t$ is close position relative to the bar midpoint/range. ADV denotes mean share volume. Partial windows, denominator guards and fills follow the implementation. Factor handler IDs are distinct from their selected display ranks.''')
s = s.replace('Legacy equality and zero-D truthiness behaviour is retained and disclosed rather than replaced retrospectively with an idealized oscillator rule.', 'The implementation retains equality and Boolean fallback behaviour when %D is zero.'.replace('%D',r'\%D'))
s = s.replace('These tables use the same final supports and unchanged predictions as the main results. Supplement S1 gives every baseline by symbol and both classes; S2 contains all execution rows/contrasts; S3 the complete numeric/random family; S4 all temporal/regime/HAC diagnostics. They are scientific companion tables, distinct from raw execution logs and implementation files. No additional market observation is created by these alternative tabulations.', 'Tables in this appendix report stock-level component results, execution sensitivities and historical-context comparisons on the observation sets defined in Section~\\ref{sec:experimentalsetup}.')
start = s.index(r'\paragraph{Separate extension companions}')
end = s.index(r'\input{generated/u09/classification.tex}',start)
s = s[:start] + r'''\paragraph{Historical-context comparisons}
The remaining tables summarize 1,530 account executions across ten methods/controls, 51 stock--fold accounts and three repeats. The bank-covered group contains FPT, MWG, VCB and VNM; the other group contains BHN, CMG, HVN, MBB and VJC. The twelve execution sensitivities above apply to the component study only. Per-stock/fold/repeat metrics, raw/final actions and daily NAV are provided in supplementary results.
''' + s[end:]
p.write_text(s,encoding='utf-8')

replacements = {
'03_problem_formulation.tex': [
 (r"A legacy field called \texttt{actual\_prev\_close} has unresolved price semantics; canonical evaluation uses explicit decision/entry/exit fields.", 'Evaluation uses explicit decision, entry and exit prices.'),
 ("The extension's \\texttt{causal\\_common\\_v1} projection", 'The common causal projection'),
 ('the original formulas and native failure are retained as their own specification.', 'native and causal constructions are evaluated as distinct representations.'),
 ('The alpha-specific causal checks do not certify news availability, hosted-model training information or whole-system causality.', 'These causal restrictions apply to alpha construction; historical news availability and hosted-model training exposure remain uncertain.'),
 ('Legacy inventory contains 180 article records and 177 identities. All 180 legacy scorer identities are unknown, and no legacy cutoff meets the strict three-valid-article rule; old runtime counts are distinct from this eligibility audit.', 'An auxiliary historical cache contains 180 article records and 177 identities with unknown scorer identities; none of its cutoffs meets the strict three-valid-article eligibility rule.'),
 ('Without independent financial-news labels or authenticated historical content, neither financial-domain accuracy nor point-in-time-certified sentiment is established.', 'Independent financial-news labels and authenticated historical content are unavailable, limiting sentiment validity.'),
 ('These daily conventions do not certify exchange calendars, executable returns or reliable sparse-trade risk estimates.', 'Daily risk estimates remain sensitive to unverified calendars, execution assumptions and sparse trades.'),
],
'04_system_architecture.tex': [
 ('No historical prediction is repaired to agree with a corrected description.', 'The semantic effect of these mismatches is unmeasured.'),
 ('Alternative text-only paths in the general application are not assumed to have replaced any frozen vision input.', 'The reported vision requests use their stored chart inputs.'),
],
'05_experimental_setup.tex': [
 ('The original nine-unit upstream/factorial panels above remain evidence for their own interventions; new retrieval/content/MT ablations were not executed in U08/U09.', 'The nine-unit upstream/factorial panels evaluate component interventions separately from historical-context methods.'),
 ('For the common-eight/recent-nine', 'For the common-eight/recent-nine'),
 ('The original-study seed, estimands and finite-draw conventions remain unchanged.', 'The component study uses its own seed, estimands and finite-draw conventions.'),
 ('Venue/calendar review flags, including ten HVN unit flags, are retained rather than converted to certified fills or synthetic CASH.', 'Ten HVN stock--date observations have unresolved venue/calendar consistency flags.'),
],
'06_backtest_results.tex': [
 ('All comparators, including less favourable ones, remain in the table.', 'The table includes all predefined comparators.'),
 ('Full therefore does not even outperform Base on this main economic mean, despite its higher BA.', 'Full has higher BA but a slightly lower mean account return than Base.'),
 ('the negative result is retained.', 'indicating a lower mean return.'),
 ('and the source companions, not recomputed from rounded table cells.', 'and the supplementary results.'),
 ('the panels use the same frozen analysis', 'the panels use the same analysis'),
 ('The panels use the same frozen analysis and simultaneous family as the tabulated contrasts; changing the displayed baseline does not create another experiment.', 'The bands use the same joint return/BA contrast family as the tabulated analysis.'),
 ('near-equal outcomes of Conditional/B and Common', 'near-equal outcomes of the conditional/explicit-count priors and Common'),
 ('They are sensitivity views, not independent replications or grounds for choosing a more favourable headline.', 'These overlapping sensitivity cohorts are analysed separately.'),
 ('within-block BA without both classes is undefined rather than fabricated.', 'within-block BA is undefined when either class is absent.'),
 ('Numeric controls do not repair native row-wise noncausality, provide the missing fixed/random LLM experiment, or certify original-expression equivalence.', 'These numerical controls use a separate causal construction and do not isolate selector effects within the LLM pipeline.'),
 ('No favorable block length, subgroup, repeat or student checkpoint is selected after examining U09 outcomes. Bands remain descriptive on the exposed cohort.', 'All specified sensitivity settings are reported, with bands interpreted descriptively on this historical cohort.'),
],
}
for name,items in replacements.items():
 p=PAPER/'sections'/name;s=p.read_text(encoding='utf-8')
 for old,new in items:
  if old==new:continue
  if old in s:s=s.replace(old,new)
 p.write_text(s,encoding='utf-8')

# Tên phương pháp được giải thích một lần rồi dùng nhất quán ở bảng và hình.
p=PAPER/'sections/04_system_architecture.tex';s=p.read_text(encoding='utf-8')
start=s.index('Bayesian prior retrieves');end=s.index('\n\n',start)
s=s[:start]+r'''The \emph{Bayesian prior} (Bayesian in tables) retrieves up to three matured same-stock examples using regime and report-signal context. The \emph{conditional prior} (Conditional) adds Beta-based statistics matched on Trend/Pattern/Alpha/Indicator states, disjoint-background shrinkage and separate readiness checks for statistics and examples. The \emph{trend--pattern prior} (Trend--pattern) relaxes the statistics match to Trend/Pattern. The \emph{explicit-count prior} (Explicit counts) uses the conditional prior's support but explains counts, intervals and example identifiers more explicitly. Historical rates and plug-in intervals summarize the selected history; when no qualified prior is available, the method reuses Common's action for that repeat.''' +s[end:]
p.write_text(s,encoding='utf-8')

notes={
't01_scope.tex': r'B omits both components, A enables factors, S enables sentiment, AS enables both, and P replaces current factors with a past training donor.',
't02_classification.tex': r'UP/DOWN support is 25/77; P/R denote class precision/recall, and NA denotes an undefined metric.',
't03_accounts.tex': r'Accounts start separately at VND50 million; Held includes CASH gaps, and continuous hold spans the first entry through the last exit.',
't04_repeats.tex': r'U/F denote upstream/factorial panels; BA intervals condition on 6,986 finite draws, with 3,014 undefined draws among 10,000 resamples.',
't05_temporal.tex': r'Trend strata use past Close/SMA60 with strict $\pm2\%$ thresholds; overlapping cohorts and dependence diagnostics are descriptive.',
't06_numeric.tex': r'All selectors use 102 observations across 51 training scopes; Holm correction covers 23 contrasts, including all twenty random trials.',
'a01_rules.tex': r'Inputs are rounded to four decimals; missing/error votes are neutral, zeros are retained, and confidence is heuristic.',
'a02_custom.tex': r'Expressions use OHLCV proxies with implementation-specific windows and guards, as defined in this appendix.',
'a03_symbols.tex': r'BHN contributes six observations and other stocks twelve; NA indicates missing-class support or a degenerate metric.',
'a04_execution.tex': r'Stock/Pending count Full accounts with residual shares/receivables, and no-fill/delay scenarios are execution proxies.',
'u09/scope.tex': r'BHN contributes six points in three folds, other stocks twelve each; repeats share one upstream realization per point.',
'u09/comparison.tex': r'Return averages 51 accounts after averaging three repeats; BA averages per-repeat metrics, and Raw/Bypass counts cover 306 method slots.',
'u09/classification.tex': r'Metrics average three per-repeat evaluations on 102 observations; NA denotes an undefined quantity.',
'u09/economics.tex': r'Accounts start at VND50 million with 0.25\% fees and 0.10\% slippage per leg; Held includes observed sessions between queries.',
'u09/repeats.tex': r'Each repeat covers 102 observations and 51 accounts conditional on one shared upstream realization; $s_R$ is sample return SD.',
'u09/contrasts.tex': r'Bands are descriptive joint 95\% bootstrap bands over twenty contrasts, using block length two and 10,000 draws.',
'u09/bridge.tex': r'Native--Common changes alpha representation and instructions; the remaining comparisons add the fact anchor and MT revision policy.',
'u09/support.tex': r'Covered denotes FPT/MWG/VCB/VNM and Other denotes BHN/CMG/HVN/MBB/VJC; NA means effective $K$ is unrecorded or inapplicable.',
'u09/sensitivity_return.tex': r'L1/L2/L3 denote fold block lengths one/two/three, with L2 primary; all bands describe historical sensitivity.',
'u09/sensitivity_ba.tex': r'L1/L2/L3 denote fold block lengths one/two/three, with L2 primary; all bands describe historical sensitivity.',
'u09/sensitivity_core4.tex': r'The bank-covered subset contains FPT/MWG/VCB/VNM, with 48 observations and 24 accounts per repeat; bands use the primary L2 procedure.',
}
for name,note in notes.items():
 p=PAPER/'generated'/name;s=p.read_text(encoding='utf-8')
 pattern=r'(\\begin\{minipage\}\{\\textwidth\}\\footnotesize )[\s\S]*?(\\end\{minipage\})'
 s,n=re.subn(pattern,lambda m:m[1]+note+m[2],s)
 assert n==1,(name,n)
 p.write_text(s,encoding='utf-8')

for p in PAPER.rglob('*.tex'):
 s=p.read_text(encoding='utf-8')
 for old,new in [
  ('fixed Bank subset','bank-covered subset'),('predeclared Bank subset','bank-covered subset'),
  ('Bank/Other','bank-covered/other stocks'),('Bank: 144 slots/role','Covered: 144 slots/role'),
  (' & Bank & ',' & Covered & '),('U08/U09','historical-context study'),
 ]:s=s.replace(old,new)
 # Rút các câu trong sơ đồ theo đúng nội dung nghiên cứu.
 s=s.replace('Native row-wise causal gate remains FAIL','Within-history causality is limited')
 s=s.replace('Bayesian prior / Conditional / A / B','Historical priors')
 s=s.replace('Common; Bayesian prior / Conditional / A / B;','Common and historical priors;')
 s=s.replace('Retain original profile and source identity','Native factors and instructions')
 s=s.replace('Original Alpha report and instruction family','Native Alpha report and instructions')
 s=s.replace('Original-study Full/Base use their own masks','Component-study Full/Base use their own masks')
 p.write_text(s,encoding='utf-8')
print('Đã viết lại phụ lục và rút ghi chú bảng về một câu.')
