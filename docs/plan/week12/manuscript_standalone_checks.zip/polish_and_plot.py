"""Thống nhất thuật ngữ và vẽ lại biểu đồ từ nguyên các ô số đã công bố."""
from pathlib import Path
import re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PAPER=Path(__file__).resolve().parents[2]/'paper'
abstract=r'''We investigate how quantitative alpha signals, Vietnamese news sentiment and historical context affect multi-agent LLM decisions for Vietnamese equities. The system combines an 85-candidate OHLCV registry with shared technical-indicator and chart-agent reports. Two complementary historical studies use 102 eligible stock--date observations across nine equities, twelve dates and six blocks. In the component study, Full balanced accuracy is \FullBA\%, compared with \BaseBA\% for Base; mean separate-account net returns are \FullReturn\% and \BaseReturn\%. Numerical baselines and repeated component/placebo panels assess classification, variability and attribution. The historical-context study compares native and common-input baselines with Bayesian and task-conditioned methods using one upstream realization and three Decision repeats. The Bayesian prior returns \UnifiedVOneReturn\%, versus \UnifiedCommonReturn\% for Common and \UnifiedNativeReturn\% for Native, corresponding to differences of $+\UnifiedVOneCommonReturnEffect$ and $\UnifiedVOneNativeReturnEffect$ percentage points. All eight research methods have negative mean returns. The results show comparator-dependent effects of information integration, with coverage and fallback materially shaping outcomes. Limited temporal support, native within-history noncausality and uncertain historical news validity constrain generalisation and causal interpretation.'''
for name in ('main.tex','main_submit.tex'):
 p=PAPER/name;s=p.read_text(encoding='utf-8');s=re.sub(r'(\\begin\{abstract\}\n).*?(\n\\end\{abstract\})',lambda m:m[1]+abstract+m[2],s,flags=re.S);p.write_text(s,encoding='utf-8')

changes={
'generated/a01_rules.tex':[
 ('12/26/9; no Stochastic histogram.','MACD periods 12/26/9.'),
 ('Legacy equality/zero-D truthiness is disclosed.',r'Equality and zero-\%D fallback follow the implementation.'),
 ('Not a volatility vote.','Momentum vote.'),
],
'generated/a02_custom.tex':[
 ('Native uses adjusted one-bar return, not the MACD display template.','Adjusted one-bar return with relative volume.'),
 ('Native uses MACD histogram and return, not sentiment; prototype has a distinct sentiment branch.','MACD histogram and adjusted return.'),
 ('Negative VolZ reverses the sign; zero cancels. No squeeze or volume-expansion gate.','Signed volume z-score reverses the signal when negative.'),
],
'sections/03_problem_formulation.tex':[
 ('Six metadata slots have description/handler mismatches, without the literal wrong formula in the affected prompts; their separate semantic effect is unmeasured.','Six selected metadata slots differ from their handler descriptions, with unmeasured semantic effects.'),
],
'sections/appendices.tex':[
 ('A Stochastic oscillator has no MACD histogram; the two rules must not be conflated.','Histogram direction is evaluated only after the crossover rule.'),
 ('Its name/description and the earlier MACD-Flow display template do not substitute for the handler.','Its handler ID identifies the numerical expression independently of its selected display rank.'),
],
'sections/06_backtest_results.tex':[
 ('Companion S1 includes all 81 symbol--classifier rows, both-class metrics and all pooled/macro denominators, so comparator reporting is not restricted to selected symbols or the main table\'s aggregate.','Supplement S1 provides all 81 stock--classifier rows, both-class metrics and pooled/macro denominators.'),
 ('not evidence that the corresponding retrievers extracted equivalent useful information.','the limited number of context-conditioned decisions.'),
 ('Exact six-block two-sided sign-flip values','Exact tests enumerate all 64 six-block sign assignments; the two-sided sign-flip values'),
 ('No random seed is selected after observing results.','All twenty specified random trials are included.'),
 ('Conditional intervals are not zero-imputed or advertised as calibrated familywise coverage.','Intervals condition on defined BA draws and have descriptive coverage.'),
],
}
for name,items in changes.items():
 p=PAPER/name;s=p.read_text(encoding='utf-8')
 for old,new in items:
  assert old in s or new in s,(name,old)
  s=s.replace(old,new)
 p.write_text(s,encoding='utf-8')

conclusion=r'''\section{Conclusion}
\label{sec:conclusion}

This paper integrates OHLCV alpha factors, Vietnamese sentiment and historical context into a multi-agent decision-support system. Shared upstream reports support paired comparisons, while explicit eligibility, fallback and utility rules connect model proposals to long-only account actions.

On 102 component-study observations, Full BA is \FullBA\%, Base \BaseBA\% and the price-only logistic comparator \LogisticPriceBA\%. Full and Base identify the same seven UP outcomes, with Full reducing false LONG forecasts; mean account returns are \FullReturn\% and \BaseReturn\%. In the historical-context study, Bayesian-prior return differs from Common by $+\UnifiedVOneCommonReturnEffect$ percentage points and from Native by $\UnifiedVOneNativeReturnEffect$ points. Native, Common, Bayesian prior and MT-BICL return \UnifiedNativeReturn\%, \UnifiedCommonReturn\%, \UnifiedVOneReturn\% and \UnifiedMTReturn\%, respectively.

Information integration changes recorded decisions, but the evidence does not establish stable predictive superiority, causal component value or deployable profitability. Limited dates, native within-history noncausality, uncertain news validity and support-dependent action reuse constrain interpretation. Prospective experiments with causal inputs, broader temporal coverage, repeated upstream realizations and targeted component interventions are needed to assess generalisation.
'''
(PAPER/'sections/08_conclusion.tex').write_text(conclusion,encoding='utf-8')

# Chỉ đổi cách vẽ và nhãn: đọc trực tiếp điểm ước lượng/cận từ bảng đã khóa.
s=(PAPER/'generated/u09/contrasts.tex').read_text(encoding='utf-8')
panels=re.findall(r'\\begin\{tabular\}\{lrrr\}(.*?)\\end\{tabular\}',s,re.S)
assert len(panels)==4
rows=[]
for panel in panels[:2]:
 values=[]
 for line in panel.splitlines():
  cells=[c.strip() for c in line.split('&')]
  if len(cells)==4 and cells[0] in ('Bayesian','Conditional','Trend--pattern','Explicit counts','MT-BICL'):
   values.append([cells[0],*[float(v.strip().rstrip('\\').strip()) for v in cells[1:]]])
 assert len(values)==5
 rows.append(values)
plt.rcParams.update({'font.size':11,'svg.fonttype':'none','pdf.fonttype':42})
fig,axes=plt.subplots(2,1,figsize=(7.2,7.1),layout='constrained')
for ax,values,baseline in zip(axes,rows,('Native','Common')):
 for i,(label,effect,low,high) in enumerate(values):
  ax.errorbar(effect,i,xerr=[[effect-low],[high-effect]],fmt='o',color='#21618c',capsize=4,lw=1.6,markersize=4)
 ax.axvline(0,color='#777777',linestyle='--',lw=1)
 ax.set_yticks(range(5),[r[0].replace('--','-') for r in values]);ax.invert_yaxis()
 ax.set_xlabel('Difference in mean account return (pp)')
 ax.set_title('Compared with '+baseline,fontsize=12)
 ax.grid(axis='x',alpha=.18);ax.spines[['top','right']].set_visible(False)
out=PAPER/'figs/context_return_contrasts'
fig.savefig(out.with_suffix('.pdf'),metadata={'Creator':'Historical-context account comparison','CreationDate':None})
fig.savefig(out.with_suffix('.svg'),metadata={'Creator':'Historical-context account comparison','Date':None})
plt.close(fig)
p=PAPER/'sections/06_backtest_results.tex';s=p.read_text(encoding='utf-8')
start=s.index(r'\centering',s.index(r'\begin{figure}'));end=s.index(r'\caption',start)
s=s[:start]+r'\centering'+'\n'+r'\includegraphics[width=0.85\textwidth]{figs/context_return_contrasts.pdf}'+'\n'+s[end:]
p.write_text(s,encoding='utf-8')
print('Đã thống nhất abstract/kết luận và biểu đồ phương pháp có nhãn dễ hiểu.')
