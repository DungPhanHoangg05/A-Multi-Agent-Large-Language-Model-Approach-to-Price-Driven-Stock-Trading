"""Biên dịch hai bản thảo trong cây riêng; chỉ đọc nguồn và bằng chứng nghiên cứu."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
iteration = sys.argv[1]
stage = WORK / ('build' + iteration)
stage.mkdir(exist_ok=False)
commands = []
for name in ('main', 'main_submit'):
    folder = stage / name
    shutil.copytree(ROOT / 'paper', folder)
    latex = ['pdflatex', '--disable-installer', '-halt-on-error', '-interaction=nonstopmode',
             '-file-line-error', '-recorder', name + '.tex']
    for index, args in enumerate((latex, ['bibtex', '--disable-installer', name], latex, latex), 1):
        result = subprocess.run(args, cwd=folder, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (folder / f'command_{index}.log').write_bytes(result.stdout)
        commands.append({'entrypoint': name, 'args': args, 'returncode': result.returncode})
        (stage / 'commands.json').write_text(json.dumps(commands, indent=2), encoding='utf-8')
        if result.returncode:
            print(result.stdout.decode('utf-8', errors='replace')[-5000:])
            raise SystemExit(result.returncode)
    print('Đã biên dịch ' + name, flush=True)
