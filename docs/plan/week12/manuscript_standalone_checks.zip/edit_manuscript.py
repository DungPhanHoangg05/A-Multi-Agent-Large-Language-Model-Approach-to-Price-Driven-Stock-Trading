"""Biên tập bài báo độc lập; giữ nguyên công thức, macro và ô số thực nghiệm."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
PAPER = ROOT / 'paper'

def write_section(name: str, content: str) -> None:
    """Ghi nguồn tiếng Anh của bài, không tác động bằng chứng thực nghiệm."""
    (PAPER / 'sections' / name).write_text(content.strip() + '\n', encoding='utf-8')

write_section('01_introduction.tex', r'''
\section{Introduction}
\label{sec:introduction}

Large language models (LLMs) provide a flexible interface for combining numerical signals, news and chart descriptions in financial decision support. Multi-agent systems such as QuantAgent \cite{xiong2025quantagent} assign these inputs to specialised analytical roles, but their predictive and economic value depends on how the evidence is constructed, combined and evaluated. Vietnamese equities offer a useful setting because local-language news, single-stock data and cash-equity settlement require explicit adaptations.

We integrate an OHLCV alpha selector and Vietnamese sentiment with Indicator, Pattern, Trend and Decision roles adapted from QuantAgent. The selector ranks 85 candidate factors, while sentiment enters a separate textual report. Numerical indicators, chart descriptions and the enabled factor/news reports are condensed into the Decision prompt with heuristic evidence priorities. The resulting binary forecast is evaluated against a net three-session LONG cycle; a bearish forecast maps to CASH in the long-only account.

The empirical analysis comprises two studies on 102 eligible stock--date observations across nine equities, twelve dates and six historical blocks. The component study compares Full, which includes factors and sentiment, with Base, which omits both, alongside class-aware and non-LLM controls. Small repeated panels examine upstream variability, factor-only and sentiment-only variants, and a matched-structure historical placebo. The historical-context study evaluates Bayesian and conditional priors, a fact anchor and multi-task Bayesian in-context learning (MT-BICL), using three Decision repeats conditional on one shared upstream realization. Each study uses its own model responses and statistical protocol.

In the component study, Full balanced accuracy (BA) is \FullBA\%, compared with \BaseBA\% for Base and \LogisticPriceBA\% for a price-only logistic comparator. Full and Base both capture seven of the 25 UP outcomes, with Full producing fewer false LONG forecasts. Their mean separate-account net returns are \FullReturn\% and \BaseReturn\%. In the historical-context study, the Bayesian prior improves mean return over the Common baseline by $+\UnifiedVOneCommonReturnEffect$ percentage points, but differs from Native by $\UnifiedVOneNativeReturnEffect$ points. All research methods have negative mean account returns.

The contributions are:
\begin{itemize}
\item A Vietnamese-equity implementation that combines an 85-candidate OHLCV selector and local-language sentiment with shared chart-agent reports.
\item A specified distinction between native adaptive factor diagnostics and a training-fitted causal projection used by historical-context methods.
\item A paired evaluation of component variants, numerical baselines and historical-context policies, with explicit missing-input, support and fallback rules.
\item An analysis connecting class-aware forecasts, repeated hosted decisions and transaction-cost-aware account outcomes.
\end{itemize}

The analysis is historical and exploratory: the evaluation schedule was finalized after some inference, market outcomes precede the November 2026 data freeze, and only twelve dates are represented. Native within-history noncausality, uncertain historical news availability and limited repetitions constrain causal and deployment conclusions. These limitations motivate interpreting the system as a documented decision-support experiment.

The remainder of the paper reviews related work, formalises the forecasting task, describes the agents and experiments, reports results, and discusses limitations and future work.
''')

write_section('02_related_work.tex', r'''
\section{Related Work}
\label{sec:relatedworks}

\subsection{LLM Agents in Financial Analysis}
BloombergGPT and FinGPT explore financial language models and domain adaptation \cite{wu2023bloomberggpt,yang2023fingpt}. TradingAgents coordinates multiple financial analysis and decision roles \cite{tradingagents2024}. QuantAgent combines Indicator, Pattern, Trend and Decision agents with shared state, chart rendering and trendline utilities \cite{xiong2025quantagent}. Our implementation adapts these components and adds numerical alpha and Vietnamese sentiment reports.

\subsection{Technical Analysis and Pattern Recognition}
ChartLlama studies multimodal chart understanding \cite{han2023chartllama}, while Tsantekidis et al. apply convolutional networks to limit-order-book forecasting \cite{tsantekidis2017lob}. The inputs and forecasting targets differ from candlestick-image analysis. Algorithmic technical analysis and conventional indicators provide complementary foundations for constructing chart and momentum evidence \cite{lo2000technical,murphy1999technical}.

\subsection{Quantitative Alpha Factor Research}
The 101 Formulaic Alphas catalogue includes cross-sectional and market-dependent expressions \cite{kakushadze2016formulaic}. Our registry contains 80 single-asset adaptations and five custom factors. Candidate search and sign orientation on a common calibration sample introduce selection bias \cite{harvey2016}. Nested assessment \cite{varma2006bias}, the Deflated Sharpe Ratio \cite{bailey2014deflated} and White's Reality Check \cite{white2000reality} address related problems. We distinguish native in-sample diagnostics from training-fitted numerical controls and apply Holm correction to the latter's declared hypothesis family \cite{holm1979multiple}.

\subsection{Sentiment Analysis in Finance and Vietnamese NLP}
ViSoBERT is a backbone for Vietnamese social-media language understanding \cite{nguyen2023visobert}; the 5CD-AI sentiment classifier is a separate model derived from it \cite{hf5cdsentiment}. Research on financial-media sentiment \cite{tetlock2007news} and FinBERT \cite{araci2019finbert} motivates using news as context, while financial-domain accuracy requires validation on the relevant language and corpus. We therefore specify scorer identity, temporal aggregation and missingness separately from predictive validity.

\subsection{Regime Context and In-Context Learning}
Hidden Markov models distinguish filtering based on observations available at the current time from inference using later observations \cite{rabiner1989hmm}. Hamilton develops this distinction for regime-switching economic models \cite{hamilton2005regimes}. Our regime estimates use prefix-only filtering.

Xie et al. interpret in-context learning as implicit Bayesian inference under a mixture-of-HMMs model and evaluate the account on synthetic sequences \cite{xie2022implicitbayes}. Rubin et al. study learned prompt retrieval for semantic parsing \cite{rubin2022retrieve}. These ideas motivate historical-context selection, while our explicit Bayesian counts, numerical student and external utility policy remain distinct computational components.

\subsection{Evaluation in Emerging Markets}
Vietnamese-language news and local cash-equity assumptions motivate domain adaptation, while purposive stock selection limits market-wide inference. Shared-report comparisons control upstream realization within a pair; conditional Decision repeats quantify a different source of variability. Class balance, statistical dependence, exposure and transaction costs must therefore be reported together. Hosted-model aliases, including the text model described in its model card \cite{openai2025gptoss}, identify a model family without authenticating the immutable weights served for each request.
''')

write_section('07_limitations.tex', r'''
\section{Limitations and Future Work}
\label{sec:limitations}

\subsection{Limitations}
\paragraph{Component attribution}
Full--Base changes factor and sentiment content together with prompt length. Compact reports in the main/upstream panel also differ from the explicit factor rows in the factorial panel. The placebo uses one predetermined past donor, and only nine market units support each repeated component panel. These differences limit attribution of forecast changes to specific information sources. The historical-context study includes no retrieval-only, statistics-only, no-prior, no-target or no-utility intervention.

\paragraph{Factor construction and sentiment validity}
Native backward filling, whole-Series normalization and volume-availability branching can make an earlier historical row depend on later rows within the supplied prefix. Isolation from prices after the current decision cutoff therefore coexists with noncausal historical diagnostics. Native orientation and ranking also reuse their calibration observations. The causal projection and numerical controls use separate constructions, so their results apply to those constructions. Six selected metadata slots differ from their handler descriptions, and the semantic effect of these mismatches is unmeasured.

Historical news content and publication availability are not independently authenticated, and no financial-domain sentiment test set or annotation agreement is available. Unknown legacy scores and locally rescored excerpts have different provenance. Missing sentiment, including 79/102 historical-context points, reduces the information actually available to the methods. Bank and query return calculations also differ numerically in 828/852 bank records, with maximum absolute discrepancy about 0.042988489 percentage points; this comparison concerns returns rather than a count of label changes.

\paragraph{Sampling and model variability}
The nine equities form a purposive sample with unverified point-in-time listing, delisting and suspension membership. Twelve selected dates and six correlated temporal blocks provide limited independent market evidence. Model-training contamination is possible because outcomes precede the data freeze. The schedule was finalized after some inference, and hosted routing, call order and serving revisions introduce further uncertainty. Three Decision repeats conditional on one upstream realization do not measure full-system variability or add market dates.

\paragraph{Historical support and action policy}
The 852-example prior bank covers four stocks. Conditional and explicit-count priors each generate only three new Decisions per 306 slots, while the trend--pattern prior generates 24. MT-BICL agrees with its fact anchor on 302/306 final actions. Consequently, aggregate results include substantial fallback and anchor retention. Native--Common changes both alpha projection and instructions, and the fact anchor adds another intervention; overall differences cannot be assigned to retrieval or student inference alone.

\paragraph{Execution and visual interpretation}
Negative account means provide no evidence of a deployable profitable strategy. Fractional fills, fixed fees/slippage, settlement phases, lot/capacity limits and volume units are assumptions or proxies. Corporate actions, price-limit queues, spreads, depth and partial fills are unverified, and separate accounts omit portfolio capital competition. Chart geometry and consistency checks constrain inputs and obvious contradictions, while local visual grounding remains untested. Prompt priorities likewise provide heuristic rather than learned evidence weighting.

\subsection{Future Work}
A prospective study should correct native row causality, repeat selection and preprocessing within chronological training, and reserve an untouched evaluation interval. Candidate search can be assessed with White's Reality Check or Deflated Sharpe analysis \cite{white2000reality,bailey2014deflated}. Broader stock/date coverage, authenticated historical inputs and independently regenerated upstream realizations would improve inference. Prior/retrieval/MT ablations, financial-news annotations and matched counterfactual charts would test component mechanisms, while portfolio simulation requires venue-specific execution data.

\subsection{Broader Impact}
Financial decision support can make heterogeneous evidence accessible, but fluent reports may overstate the reliability of sparse or contradictory inputs. Forecast confidence should therefore remain distinct from action policy and realised account performance. Use and distribution of news, price data and model assets must also respect their respective licences and source terms.
''')

write_section('availability.tex', r'''
\section*{Data and Code Availability}
The implementation is available in the \href{https://github.com/DungPhanHoangg05/A-Multi-Agent-Large-Language-Model-Approach-to-Price-Driven-Stock-Trading-in-the-Vietnamese-Stock-Ma}{project repository}. The research archive contains price/news snapshots, prompts and chart inputs, model responses, execution records and pinned dependencies. Supplementary tables cover classification, repeated decisions, numeric selector controls, temporal sensitivity and historical-context comparisons.

The complete data archive is currently maintained privately; public distribution rights and a persistent identifier are pending. Historical inputs were reconstructed for research and have not been independently authenticated at their original availability times. Saved-prediction replay reproduces the reported calculations, while newly hosted inference may differ because served model revisions are not immutable.
''')

# Các đoạn thay thế giữ thông tin phương pháp, bỏ ngôn ngữ biên bản và phản hồi.
paragraphs = {
'03_problem_formulation.tex': {
 'Causal scope.': None,
 'The native row-wise causal gate fails.': r'Native backward filling, whole-Series normalization and full-frame volume-availability branching can change earlier historical values when later rows in the supplied prefix change. Synthetic perturbations after the decision cutoff leave outputs unchanged, establishing outer-cutoff isolation but not row-wise causality within the prefix. Native diagnostics are therefore evaluated as in-sample historical constructions.',
},
'04_system_architecture.tex': {
 'A versioned registry separates eight extension roles': r'The historical-context study compares eight research methods and two economic controls. Native uses the native alpha report and instructions; Common uses a training-fitted causal alpha projection with a common prompt and both alpha and sentiment enabled. Four historical priors depend on Common. Fact anchor also receives Common\'s completed decision, and MT-BICL receives both Common and Fact anchor for the same repeat. The component study separately compares Full and Base by switching factor and sentiment sections.',
 'The renderer audit matched': r'Input checks match 204 chart images across 102 units byte for byte and pixel for pixel, and 240 recorded vision requests match their image caches and Vietnamese templates. The charts use blue support and red resistance lines, while the Vietnamese word \emph{xanh} is less colour-specific than the English term ``blue''. Inherited high-frequency/K-line wording is used with daily bars, and the model\'s interpretation of these instructions is unverified.',
},
'05_experimental_setup.tex': {
 'The daily universe spans': r'The daily universe spans information technology (FPT, CMG), banking (VCB, MBB), retail (MWG), food/beverages (VNM, BHN) and aviation/tourism (HVN, VJC). The reconstructed vnstock/VCI snapshot \cite{vnstock_docs} covers observed vendor sessions from 2020 through September 2026. The sample is purposive, and original historical data availability is unverified. A valid-suffix policy excludes contradictory BHN OHLC data; insufficient warm-up then excludes BHN from three early blocks. This leaves 102 eligible cells of the twelve-date by nine-stock grid in Figure~\ref{fig:calendar}.',
 r'\paragraph{Two study identities}': r'\paragraph{Component and historical-context studies}',
 'We distinguish the original Full/Base revision study': r'The component study evaluates Full/Base and numerical controls; the historical-context study evaluates Native/Common and prior/task-conditioned methods. They share eligible market dates but use separate model responses and statistical protocols. Base omits factors and sentiment, whereas Common retains both under a different alpha/prompt profile. Sentiment is unavailable at \UnifiedMissingSentiment/\UnifiedPoints\ historical-context points.',
 'The reduced scope was amended': r'The evaluation schedule was finalized after some inference, making this an exploratory historical analysis. The 375 component-study Decisions comprise 193 reused successful executions and 182 additional successes. The upstream panel shares 18 calls with the main comparison, so 204+54+135-18=375 unique Decisions. Factorial units were selected by stock/date round-robin metadata. Table~\ref{tab:scope} reports the supports of the main, upstream and factorial panels.',
 'For U09,': r'In the historical-context study, each method has three independent-capital executions per stock--fold account. Returns are averaged across repeats within account and then equally over 51 accounts; BA is computed separately on 102 points per repeat and then averaged. Evaluated predictions follow final policy actions. Daily EOD NAV, cycle drawdown, costs, turnover and held-session fraction retain their own units. Cycle Sharpe uses sample SD (ddof=1); cycle Sortino uses the RMS of negative-part returns over all cycles with MAR zero. Annualized ratios are undefined for the irregular schedule, and missing/degenerate denominators are recorded as NA.',
 'The closure contains': r'The component-study execution records contain 649 attempts, 615 successes and 34 errors, including 120 shared Pattern calls. Observed usage totals 1,063,328 prompt and 340,736 completion tokens; error usage/latency and monetary billing are unknown. Recorded callback elapsed times exclude unobserved waiting and do not measure wall-clock runtime.',
 r'\paragraph{Frozen extension resources and attempts}': r'\paragraph{Historical context and execution resources}',
 'U08 locks its own observed SDK options': r'The historical-context study fixes prompts, aliases, decoding options and dependency order before its own execution. Retry handling allows three total attempts including schema repair, with durable checkpoints and reconciliation of uncertain requests. Records contain 1,702 HTTP attempts, including 15 superseded attempt records, and 1,290 active raw Decision responses. These counts refer to attempts and responses respectively and remain separate from the component-study totals.',
 'The prior bank contains': r'The prior bank contains 852 fixed historical examples for FPT, MWG, VCB and VNM; the other five stocks follow the specified support/fallback policy. Bank and query inputs have separate provenance. Numeric MT context, scaler, HMM and teacher are fixed with student checkpoint seed 42/step 3000, and all 51 causal alpha selectors are fitted before their queries. Inference uses these resources without refitting.',
},
'06_backtest_results.tex': {
 'Table~\\ref{tab:classification} uses': r'Table~\ref{tab:classification} reports the 102 component-study observations. Full accuracy is \FullAccuracy\%, Base \BaseAccuracy\%, and CASH/train-majority \CashAccuracy\%. The 77 DOWN outcomes make ordinary accuracy favour conservative predictions. Full BA is \FullBA\%, Base \BaseBA\%, and logistic-price \LogisticPriceBA\%, giving a Full--Base difference of \DeltaBA\ percentage points. Constant-rule MCC is undefined.',
 'Table~\\ref{tab:u09-comparison} reports': r'Table~\ref{tab:u09-comparison} reports the historical-context methods and economic controls. Native mean account return is \UnifiedNativeReturn\%, Common \UnifiedCommonReturn\%, Bayesian prior \UnifiedVOneReturn\% and MT-BICL \UnifiedMTReturn\%. Their BAs are \UnifiedNativeBA\%, \UnifiedCommonBA\%, \UnifiedVOneBA\% and \UnifiedMTBA\%, respectively. All research-method mean returns are negative; CASH returns zero and Always-LONG cycles return \UnifiedAlwaysLongReturn\%.',
 r'\subsubsection{Extension bridges do not replace missing ablations}': r'\subsubsection{Baseline and action-policy comparisons}',
 'Table~\\ref{tab:u09-bridge} distinguishes': r'Table~\ref{tab:u09-bridge} separates the Native--Common comparison, the fact-anchor step and MT revision. MT-BICL agrees with Fact anchor on 302/306 final actions. This high agreement limits attribution of the overall MT outcome to retrieved context or numerical student inference. Retrieval-only, statistics-only, no-prior, no-target and no-utility interventions were not evaluated.',
 'The upstream AS--B mean': r'The upstream AS--B mean BA difference is $+4.76$ pp, with conditional percentile interval $[0,10]$ pp. This panel uses different observations from the factorial panel. Across recorded groups, 40/147 have a successful-call order different from the planned order and nine span execution epochs, introducing time/order confounding.',
},
}
for filename, mapping in paragraphs.items():
    path = PAPER / 'sections' / filename
    lines = path.read_text(encoding='utf-8').splitlines()
    for prefix, replacement in mapping.items():
        if replacement is None:
            continue
        indices = [i for i, line in enumerate(lines) if line.startswith(prefix)]
        assert len(indices) == 1, (filename, prefix, indices)
        lines[indices[0]] = replacement.replace("\\'s", "'s")
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')

# Thay nhãn nghiên cứu/phương pháp trong văn bản hiển thị; giữ khóa source nội bộ.
for path in PAPER.rglob('*.tex'):
    text = path.read_text(encoding='utf-8')
    for old, new in [
        ('Bayesian-v1', 'Bayesian-prior'), ('Bayesian v1', 'Bayesian prior'), ('Bayes v1', 'Bayesian'),
        ('A\\_tp\\_pool', 'trend--pattern prior'), ('B\\_semantic', 'explicit-count prior'),
        ('A pool', 'Trend--pattern'), ('B semantic', 'Explicit counts'),
        ('Fact\\_Anchor', 'Fact anchor'), ('MT\\_BICL', 'MT-BICL'),
        ('original-study', 'component-study'), ('Original-study', 'Component-study'),
        ('original study', 'component study'), ('original Full/Base', 'component Full/Base'),
        ('original and extension studies', 'component and historical-context studies'),
        ('Original and extension studies', 'Component and historical-context studies'),
    ]:
        text = text.replace(old, new)
    text = re.sub(r'\bC2\b', 'Conditional', text)
    text = re.sub(r'\bCORE4\b', 'Bank', text)
    text = re.sub(r'\bOOD5\b', 'Other', text)
    text = re.sub(r'(\\begin\{(?:table|figure|algorithm)\})\[[^\]]*\]', r'\1[htb]', text)
    # Hai wrapper cũ có thể ghi đè vị trí của bảng được input.
    text = re.sub(r'\\begingroup\n\\let\\saved(?:scopepresentation|comparison)table\\table\n\\def\\table\[#1\]\{\\saved(?:scopepresentation|comparison)table\[[^\]]+\]\}\n(\\input\{[^}]+\})\n\\endgroup', r'\1', text)
    path.write_text(text, encoding='utf-8')

captions = {
 'tab:scope': 'Evaluation panels and enabled prompt components in the component study.',
 'tab:classification': 'Classification performance of nine methods on 102 stock--date observations.',
 'tab:accounts': 'Mean return, drawdown and exposure across 51 separate stock--block accounts.',
 'tab:repeats': 'Prediction variability and paired contrasts across three executions of two nine-observation panels.',
 'tab:temporal': 'Balanced accuracy across temporal cohorts and observed stock-level trend strata.',
 'tab:numeric': 'Performance of training-fitted fixed, dynamic and random numerical factor selectors.',
 'tab:custom_definitions': 'Native custom factor definitions before normalization and IC orientation.',
 'tab:indicator_rules': 'Deterministic classification rules for the five technical-indicator votes.',
 'tab:symbol_results': 'Full and Base classification performance by stock.',
 'tab:execution': 'Account-return sensitivity to twelve execution assumptions.',
 'tab:u09-scope': 'Market coverage and execution counts in the historical-context study.',
 'tab:u09-comparison': 'Mean returns, balanced accuracy and support across historical-context methods and controls.',
 'tab:u09-classification': 'Classification metrics averaged across three historical-context Decision repeats.',
 'tab:u09-economics': 'Mean risk, exposure and trading costs of historical-context accounts.',
 'tab:u09-repeats': 'Return and balanced accuracy across three conditional Decision repeats.',
 'tab:u09-contrasts': 'Paired return and balanced-accuracy differences against Native and Common baselines.',
 'tab:u09-bridge': 'Performance differences and final-action agreement between successive policy components.',
 'tab:u09-support': 'Historical support and fallback coverage for bank-covered and other stocks.',
 'tab:u09-sensitivity-return': 'Return-contrast sensitivity to bootstrap block length.',
 'tab:u09-sensitivity-ba': 'Balanced-accuracy contrast sensitivity to bootstrap block length.',
 'tab:u09-sensitivity-core4': 'Paired performance contrasts within the four bank-covered stocks.',
 'fig:flow': 'Shared-report architecture for component and historical-context comparisons.',
 'fig:alpha_agent': 'Native and causal alpha processing with separate Vietnamese sentiment context.',
 'fig:charts': 'Candlestick and support--resistance inputs for CMG at the 3 July 2023 decision cutoff.',
 'fig:decision_agent': 'Decision dependencies, fallback rules and final-action policy.',
 'fig:calendar': 'Eligible stock--date observations across the six historical blocks.',
 'fig:walkforward': 'Chronological data preparation, shared inference and three-session execution timing.',
 'fig:u09-return-contrasts': 'Mean account-return differences against Native and Common with descriptive simultaneous bands.',
 'alg:walkforward': 'Walk-forward evaluation with shared reports and separate account ledgers.',
}
used = set()
for path in PAPER.rglob('*.tex'):
    text = path.read_text(encoding='utf-8')
    def shorten(match: re.Match) -> str:
        label = match[1]
        assert label in captions, (path, label)
        used.add(label)
        return '\\caption{' + captions[label] + '}\n\\label{' + label + '}'
    text = re.sub(r'\\caption\{[^\n]*\}\n\\label\{([^}]+)\}', shorten, text)
    path.write_text(text, encoding='utf-8')
assert used == set(captions), set(captions) - used
print('Đã biên tập nội dung chính, tên phương pháp, vị trí float và caption.')
