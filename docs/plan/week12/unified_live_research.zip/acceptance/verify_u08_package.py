"""Kiểm toàn vẹn gói U08 bằng thư viện chuẩn, không giải nén hoặc mở kết nối."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile

def sha(raw: bytes) -> str:
    """Băm nguyên byte thành viên."""
    return hashlib.sha256(raw).hexdigest()

def main() -> None:
    """Kiểm inventory, receipt, raw ledger và nguồn local tùy chọn."""
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package',type=Path)
    parser.add_argument('--root',type=Path)
    args=parser.parse_args()
    with zipfile.ZipFile(args.package) as archive:
        manifest=json.loads(archive.read('manifest.json'))
        names=archive.namelist()
        assert len(names)==len(set(names)) and set(names)==set(manifest['members'])|{'manifest.json'}
        assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names)
        for name,binding in manifest['members'].items():
            raw=archive.read(name)
            assert len(raw)==binding['bytes'] and sha(raw)==binding['sha256'],name
        prefix=manifest['namespace']+'/'
        receipt=json.loads(archive.read(prefix+'receipt.json'))
        assert receipt==json.loads(archive.read(prefix+'quota_receipt.json'))
        payload=receipt['payload']
        assert payload['status']=='PASS_U08_RESEARCH' and payload['complete_points']==102 and payload['forecast_slots']==2448
        assert sha(archive.read(prefix+'wire.json'))==payload['wire_sha256']
        wire=json.loads(archive.read(prefix+'wire.json'))['payload']
        assert len(wire['rows'])==payload['http_attempts']==1702
        for item in wire['rows']:
            row=json.loads(archive.read(prefix+'http/'+item['id']+'.json'))
            assert row['sha256']==item['sha256']
        proof=json.loads(archive.read('acceptance/u08_acceptance.json'))
        assert proof['status']=='PASS_U08_ACCEPTANCE' and proof['receipt']==payload
        assert proof['new_inference_requests']==0 and proof['journal_files_unchanged']==manifest['journal_files']
        if args.root:
            sources=json.loads(archive.read('acceptance/u08_acceptance_sources.json'))
            assert len(sources)==718
            for name,binding in sources.items():
                raw=(args.root/name).read_bytes()
                assert len(raw)==binding['bytes'] and sha(raw)==binding['sha256'],name
        print(json.dumps({'status':'PASS_U08_EVIDENCE_PACKAGE','members':len(names),'journal_files':manifest['journal_files'],
            'complete_points':102,'forecast_slots':2448,'http_attempts':1702,'retired_http_attempts':15,
            'local_source_pins_verified':718 if args.root else 0,'network_requests':0},ensure_ascii=False))

if __name__=='__main__':main()
