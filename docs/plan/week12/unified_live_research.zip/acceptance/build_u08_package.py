"""Đóng gói bằng chứng U08 nguyên byte, loại bỏ lock/owner/launcher tạm."""
from pathlib import Path
import sys,json,hashlib,tempfile,zipfile
root=Path.cwd();temporary=Path(tempfile.gettempdir())
proof=json.loads((temporary/'u08_acceptance.json').read_text(encoding='utf-8'))
assert proof['status']=='PASS_U08_ACCEPTANCE'
inventory=json.loads((temporary/'u08_acceptance_inventory.json').read_text(encoding='utf-8'))
members={}
for name,binding in inventory.items():
 raw=(root/name).read_bytes()
 assert len(raw)==binding['bytes'] and hashlib.sha256(raw).hexdigest()==binding['sha256'],name
 members[name]=raw
metadata=[]
for stem in ('live','model_quota','provider_quota','point_restart','slot_restart'):
 for kind in ('runtime','checks'):
  metadata.append(f'docs/plan/week12/unified_{stem}_{kind}.json')
 if stem=='live':
  metadata.extend('docs/plan/week12/unified_live_'+suffix+'.json' for suffix in ('preflight','smoke_release','research_release'))
 else:metadata.append(f'docs/plan/week12/unified_{stem}_release.json')
metadata.extend('docs/plan/week12/unified_'+stem+'_backup.zip' for stem in ('point_restart','slot_restart'))
metadata.extend(('docs/plan/week12/unified_comparison_protocol.json','docs/plan/week12/unified_comparison_manifest_v2.json'))
for name in metadata:members[name]=(root/name).read_bytes()
for name in ('verify_u08_acceptance.py','u08_acceptance.json','u08_acceptance_inventory.json','u08_acceptance_sources.json','u08_acceptance.log','verify_u08_package.py','build_u08_package.py'):
 members['acceptance/'+name]=(temporary/name).read_bytes()
def binding(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
manifest={'version':'u08_research_evidence_v1','status':'PASS_U08_RESEARCH','namespace':'outputs/unified_integration/u08_research_r1',
 'source_commit':proof['source_commit'],'journal_files':len(inventory),'journal_bytes':sum(v['bytes'] for v in inventory.values()),
 'receipt_sha256':inventory['outputs/unified_integration/u08_research_r1/receipt.json']['sha256'],
 'members':{name:binding(raw) for name,raw in sorted(members.items())},
 'external_dependencies':'Frozen Git sources, U06 assets/runtime and prior QA archives stay in the repository; their hashes are verified by the acceptance consumer.',
 'excluded_operational_files':['run.lock','run.owner.json','run.recovery.json','manager/','launcher*','.gitignore']}
archive_path=root/'docs/plan/week12/unified_live_research.zip'
assert not archive_path.exists(),'Không ghi đè bằng chứng đã đóng gói'
with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for name,raw in sorted(members.items()):archive.writestr(name,raw)
 archive.writestr('manifest.json',(json.dumps(manifest,ensure_ascii=False,indent=2)+chr(10)).encode('utf-8'))
result={'path':archive_path.relative_to(root).as_posix(),'bytes':archive_path.stat().st_size,'sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest(),'members':len(members)+1,'journal_files':len(inventory),'journal_bytes':sum(v['bytes'] for v in inventory.values())}
(temporary/'u08_package_stats.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
