"""Đối soát U08 đã seal, chỉ đọc bằng chứng và chặn mọi client/mạng bên ngoài."""
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
from collections import Counter,defaultdict
from datetime import datetime,timezone
import sys,json,tempfile,hashlib,zipfile,subprocess
root=Path(sys.argv[1] if len(sys.argv)>1 else Path.cwd()).resolve()
sys.path.insert(0,str(root))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
from core.historical_evaluation_journal import load
from core.unified_contracts import digest
from core.unified_execution_transport import wire_state
from core.unified_slot_restart.runtime import audit,RUNTIME
from core.unified_live.release import NAMESPACES
run_dir=root/NAMESPACES['RESEARCH']
selected=[run_dir/name for name in ('identity.json','wire.json','receipt.json','quota_receipt.json','status.json','slot_restart_cold_verify.log')]
for folder in ('slots','http','diagnostics'):selected.extend(sorted((run_dir/folder).glob('*.json')))
inventory={p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected}
receipt=load(run_dir/'receipt.json')
assert receipt==load(run_dir/'quota_receipt.json')
status=load(run_dir/'status.json');assert {k:v for k,v in status.items() if k!='updated_at'}==receipt
collector=json.loads((run_dir/'slot_restart_cold_verify.log').read_text(encoding='utf-8'))
assert {k:v for k,v in collector.items() if k!='current_admission_probe'}==receipt
assert receipt['status']=='PASS_U08_RESEARCH' and receipt['complete_points']==102 and receipt['forecast_slots']==2448
with ExitStack() as stack:
 for name in ('httpx.Client','httpx.AsyncClient','httpx.HTTPTransport','langchain_groq.ChatGroq','dotenv.dotenv_values','core.unified_execution_providers.StudyProviders'):
  stack.enter_context(patch(name,side_effect=AssertionError('Nghiệm thu cấm key/client/provider: '+name)))
 result=audit(root)
assert {k:v for k,v in result.items() if k!='current_admission_probe'}=={k:v for k,v in receipt.items() if k not in ('active_slots_sha256','wire_sha256')}
slot_paths=sorted((run_dir/'slots').glob('*.json'))
assert digest({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in slot_paths})==receipt['active_slots_sha256']
assert hashlib.sha256((run_dir/'wire.json').read_bytes()).hexdigest()==receipt['wire_sha256']
with zipfile.ZipFile(root/'docs/plan/week12/unified_execution_checks.zip') as z:sources=json.loads(z.read('source_bindings.json'))
for name in ('unified_live_runtime.json','unified_model_quota_runtime.json','unified_provider_quota_runtime.json','unified_point_restart_runtime.json','unified_slot_restart_runtime.json'):
 sources.update(load(root/'docs/plan/week12'/name)['sources'])
assert len(sources)==718
for name,binding in sources.items():
 content=(root/name).read_bytes();assert len(content)==binding['bytes'] and hashlib.sha256(content).hexdigest()==binding['sha256'],name
checks={}
for stem in ('live','model_quota','provider_quota','point_restart','slot_restart'):
 value=load(root/f'docs/plan/week12/unified_{stem}_checks.json')
 assert value['status']=='PASS' and not value['failures'] and not value['errors'] and not value['skips']
 assert len(set(value['test_ids']))==value['tests']
 assert all(sources[name]==binding for name,binding in value['sources'].items())
 checks[stem]={'tests_previously_passed':value['tests'],'python_files_previously_compiled':len(value['compiled']),'rerun':False}
manifest=load(root/RUNTIME);retired=manifest['plan']['retired_http'];state=wire_state(run_dir)
assert len(state['rows'])==1702 and len(retired)==15
assert all(digest(row)==retired[row['id']] for row in state['rows'] if row['id'] in retired)
active=[r for r in state['rows'] if r['id'] not in retired]
assert not any(r['status']=='UNKNOWN' for r in active)
assert set(r['id'] for r in state['rows'] if r['status']=='UNKNOWN')<=set(retired)
assert len(active)==1687
attempts=Counter((r['slot'],r['attempt']) for r in state['rows']);assert max(attempts.values())<=3
assert len(state['rows'])<7956
prompt_lengths=[len(r['body']['messages'][0]['content']) for r in state['rows'] if r['slot'].startswith('forecast/')]
assert max(prompt_lengths)<6500
stages=Counter();coverage=Counter();repeats=Counter();variant_http=Counter();bypass=Counter();used=[]
for path in slot_paths:
 doc=load(path);assert len(doc['attempts'])==1 and doc['attempts'][0]['status']=='complete'
 stages[doc['slot'].split('/')[0]]+=1
 if doc['slot'].startswith('forecast/'):
  value=doc['attempts'][0]['output']['forecast'];coverage[value['variant']]+=1;repeats[value['repeat']]+=1
  if value['raw'] is None:bypass[value['variant']]+=1
  else:variant_http[value['variant']]+=1;used.append(value['raw']['source_request_id'])
assert stages=={'shared':102,'graph':408,'render':204,'prepare':2448,'forecast':2448,'outcome':102}
assert len(coverage)==8 and set(coverage.values())=={306}
assert repeats=={0:816,1:816,2:816}
assert len(used)==len(set(used))==1290 and sum(bypass.values())==1158
points=load(run_dir/'identity.json')['identity']['points']
assert len(points)==102 and len({p['symbol'] for p in points})==9 and len({(p['symbol'],p['fold']) for p in points})==51
assert not (run_dir/'stop.request').exists()
assert all((root/name).stat().st_size==binding['bytes'] and hashlib.sha256((root/name).read_bytes()).hexdigest()==binding['sha256'] for name,binding in inventory.items())
summary={'status':'PASS_U08_ACCEPTANCE','verified_at_utc':datetime.now(timezone.utc).isoformat(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sealed_at_utc':status['updated_at'],'receipt':receipt,'source_pins_verified':len(sources),'prior_checks':checks,'suite_rerun':False,'cold_consumer_rerun':True,'constructors_blocked':6,'external_network_blocked':True,'new_inference_requests':0,'journal_files_unchanged':len(inventory),'journal_bytes':sum(v['bytes'] for v in inventory.values()),'stage_counts':dict(stages),'symbol_count':9,'symbol_fold_count':51,'variant_coverage':dict(coverage),'repeat_coverage':dict(repeats),'decision_http_by_variant':dict(variant_http),'bypass_by_variant':dict(bypass),'http_status_all':dict(Counter(str(r['status']) for r in state['rows'])),'http_status_active':dict(Counter(str(r['status']) for r in active)),'max_http_attempts_per_execution':max(attempts.values()),'max_decision_prompt_characters_including_repair':max(prompt_lengths),'observed_total_tokens_all_http':sum(r.get('total_tokens') or 0 for r in state['rows']),'unknown_reserved_tokens_retained':sum(r['reserved_tokens'] for r in state['rows'] if r['status']=='UNKNOWN'),'phase_http_cap':7956,'paid_api_allowed':False,'spend_limit_usd':0,'limitations':['HISTORICAL_EXPOSED_COHORT','NATIVE_ROWWISE_CAUSAL_FAIL','WHOLE_SYSTEM_CAUSAL_NOT_CERTIFIED','USER_AUTHORIZED_REPLACEMENTS_RETAINED_IN_LEDGER','NO_SUPERIORITY_ANALYSIS_IN_U08']}
output=Path(tempfile.gettempdir())
for name,value in (('u08_acceptance.json',summary),('u08_acceptance_inventory.json',inventory),('u08_acceptance_sources.json',sources)):
 (output/name).write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+chr(10)).encode('utf-8'))
print(json.dumps(summary,ensure_ascii=False))
