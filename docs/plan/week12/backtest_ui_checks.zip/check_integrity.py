"""Đối soát bằng chứng và logic legacy trước F10; không chạy lại nghiên cứu đã seal."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f10'
DOC = ROOT/'docs/plan/week12'
BASE = '6666f48c'


def binding(raw: bytes) -> dict:
    """Giữ nguyên byte của evidence có checksum."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def old(name: str) -> bytes:
    """Blob trước task là oracle độc lập, không lấy source mới làm expected."""
    return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)


with zipfile.ZipFile(DOC/'unified_analysis_results.zip') as archive:
    pins = {name:{k:v[k] for k in ('bytes','sha256')} for name,v in json.loads(archive.read('manifest.json'))['sources'].items()}
with zipfile.ZipFile(DOC/'final_evidence_snapshot.zip') as archive:
    snapshot = json.loads(archive.read('snapshot_manifest.json'))
    for name,expected in pins.items(): assert binding(archive.read(name)) == expected,name
    for group in ('frozen_packages','legacy_archives'):
        for name,expected in snapshot[group].items(): assert binding((ROOT/name).read_bytes()) == expected,name
changed = sorted(name for name,expected in pins.items() if binding((ROOT/name).read_bytes()) != expected)
assert changed == ['scripts/.gitattributes','templates/backtest.html','templates/demo_new.html','templates/experiments.html',
    'templates/output.html','utils/experiment_web.py','web_interface.py'],changed
release = ROOT/'outputs/revision/manuscript_unified_final_v1'
assert binding((release/'manifest.json').read_bytes()) == {'bytes':55249,'sha256':'8e5ce2a4ca6f3a52945047cb8e1e1e99e8c00dfcd959a6fc6cdadcd701013de9'}
manifest = json.loads((release/'manifest.json').read_bytes())
for name,expected in manifest['outputs'].items(): assert binding((release/name).read_bytes()) == expected,name
for name,expected in manifest['sources'].items(): assert binding((ROOT/name).read_bytes()) == expected,name
for name in ('serving_runner_checks.zip','analysis_ui_checks.zip','serving_resources_v1.json'):
    assert old('docs/plan/week12/'+name) == (DOC/name).read_bytes(),name
for name in ('core/backtest_engine.py','core/free_pilot_statistics.py','core/unified_analysis/analysis.py',
    'core/variant_registry.py','core/unified_methods.py','core/serving_runtime/providers.py',
    'core/serving_runtime/transport.py','core/serving_runtime/quota.py','core/serving_runtime/resources.py',
    'templates/demo_new.html','templates/output.html','README.md'):
    assert subprocess.check_output(['git','diff','--exit-code',BASE,'--',name],cwd=ROOT) == b'',name
source = old('templates/backtest.html').decode().replace('\r\n','\n')
css = re.search(r'    <style>\n(.*?)    </style>',source,re.S)[1]
assert css == (ROOT/'static/css/backtest/legacy.css').read_text(encoding='utf-8')
js = re.search(r'    <script>\n(.*?)    </script>',source,re.S)[1]
js = js.replace('const T = {{ T | tojson }};', 'const T = JSON.parse(document.getElementById("legacy-config").textContent).messages;')
js = js.replace('const LANG = {{ LANG | tojson }};', 'const LANG = JSON.parse(document.getElementById("legacy-config").textContent).language;')
assert js == (ROOT/'static/js/backtest/legacy.js').read_text(encoding='utf-8')
nodes = lambda raw:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
before,after = nodes(old('web_interface.py').decode()),nodes((ROOT/'web_interface.py').read_text(encoding='utf-8'))
assert {name for name in before if before[name] != after[name]} == {'render_localized'}
result = {'status':'PASS_F10_INTEGRITY','base_commit':BASE,'u09_source_pins':729,'current_matches':722,
    'historical_snapshot_restores':729,'intentional_changed_pins':changed,
    'frozen_packages_unchanged':20,'legacy_archives_unchanged':30,'f05_outputs_unchanged':11,'f05_sources_unchanged':68,
    'f08_resource_and_qa_unchanged':True,'f09_qa_unchanged':True,
    'legacy_css_exact':True,'legacy_js_exact_except_json_bootstrap':True,
    'legacy_python_ast_unchanged_except':['render_localized'],
    'account_classification_and_net_oracles_unchanged':True,'new_hosted_llm_calls':0,'new_market_calls':0,
    'new_hmm_student_bank_training':0,'native_rowwise_causal_gate':'FAIL','whole_system_causal_gate':'NOT_CERTIFIED',
    'browser_visual_status':'NOT_RUN_BROWSER_HOST_UNAVAILABLE; F11_PENDING'}
(QA/'integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
