"""Kiểm lại đúng UI sau khi phân biệt lỗi filter/network với sai owner khi đọc."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f10'
command = ['node','--test','tests/js/backtest_ui.test.mjs']
result = subprocess.run(command,cwd=ROOT,capture_output=True)
raw = result.stdout+b'\n'+result.stderr; (QA/'backtest_ui.log').write_bytes(raw)
results = json.loads((QA/'test_results.json').read_bytes())
results['backtest_ui.log'].update(returncode=result.returncode,log_sha256=hashlib.sha256(raw).hexdigest())
(QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
assert result.returncode == 0
subprocess.run(['node','--check',str(ROOT/'static/js/backtest/result.js')],check=True,capture_output=True)
print('PASS_DOM_13')
