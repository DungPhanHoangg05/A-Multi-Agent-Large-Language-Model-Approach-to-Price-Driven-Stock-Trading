"""Đóng QA backtest mới từ log/source thật; không thay gate khoa học hoặc browser."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import unicodedata
import zipfile

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f10'
TARGET = ROOT/'docs/plan/week12/backtest_ui_checks.zip'


def binding(raw: bytes) -> dict:
    """Kiểm byte sau checkout/merge, không chỉ số test được ghi trong README."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def slug(text: str) -> str:
    """Anchor Markdown Unicode của tài liệu hiện hành."""
    text = re.sub('<[^>]+>','',text).lower().replace(' ','-')
    return ''.join(c for c in text if c in '-_' or unicodedata.category(c)[0] in 'LN')


results = json.loads((QA/'test_results.json').read_bytes())
assert len(results) == 19 and all(v['returncode'] == 0 for v in results.values())
assert sum(v['tests'] for k,v in results.items() if k.startswith('tests_')) == 156
assert sum(v['tests'] for k,v in results.items() if not k.startswith('tests_')) == 31
for name,record in results.items():
    raw = (QA/name).read_bytes(); assert binding(raw)['sha256'] == record['log_sha256'],name
    if name.startswith('tests_'): assert re.search(rb'\nOK\s*$',raw) and b'skipped=' not in raw,name
    else: assert re.search(rb'(?:#|\xe2\x84\xb9) fail 0',raw),name
compiled = json.loads((QA/'compiled.json').read_bytes()); syntax = json.loads((QA/'syntax.json').read_bytes())
assert compiled['count'] == 13 and syntax['count'] == 7
integrity = json.loads((QA/'integrity.json').read_bytes()); assert integrity['status'] == 'PASS_F10_INTEGRITY'
TARGET.touch(exist_ok=True)
docs = ['docs/plan/plan.md','docs/plan/week12/README.md','docs/plan/week12/final_paper_ui_plan.md',
        'docs/plan/week12/variant_serving_contract.md']
links = 0
for name in docs:
    path = ROOT/name
    for target in re.findall(r'(?<!!)\[[^]\n]*\]\(([^)\n]+)\)',path.read_text(encoding='utf-8')):
        if '://' in target or target.startswith('mailto:'): continue
        rel,_,anchor = target.partition('#'); dest = (path.parent/rel).resolve() if rel else path
        assert dest.exists(),(name,target)
        if anchor: assert anchor in [slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$',dest.read_text(encoding='utf-8'),re.M)],(name,target)
        links += 1
readme,plan = ((ROOT/docs[i]).read_text(encoding='utf-8') for i in (1,2))
assert '- [x] F10' in readme and '| F10 | ☑ Hoàn tất |' in plan
for task in ('F11','F12'): assert '- [ ] '+task in readme and '| '+task+' | ☐ Chưa bắt đầu |' in plan
files = sorted(set(subprocess.check_output(['git','diff','6666f48c','--name-only'],cwd=ROOT).decode().splitlines()
    + subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT).decode().splitlines()))
files = [name for name in files if name != TARGET.relative_to(ROOT).as_posix()]
checks = {'status':'PASS_F10_OFFLINE_SCOPE','base_commit':'6666f48c','python_tests_passed':156,'dom_tests_passed':31,
    'new_evaluator_tests':9,'new_api_page_tests':9,'new_dom_tests':13,'leakage_regressions':18,'native_parity_tests':11,
    'economic_scalar_tests':10,'unified_analysis_tests':20,'compiled':compiled,'javascript_syntax':syntax,'test_suites':results,
    'runtime':subprocess.check_output(['py','-3.13','--version']).decode().strip(),
    'node':subprocess.check_output(['node','--version']).decode().strip(),
    'source_bindings':{name:binding((ROOT/name).read_bytes()) for name in files},
    'new_query':'MWG 2026-07-02; ALL_SIX_BACKTEST_ONE_POINT_EIGHT_FORECAST_SLOTS_SIX_SELECTED_ACCOUNTS_24_DAILY_NAV_ROWS; FIXTURE_HTTP_ONLY',
    'financial_scope':'FILTERED_COMMON_SUPPORT; INDEPENDENT_SYMBOL_REPEAT_ACCOUNTS_NOT_PORTFOLIO',
    'partials':'NO_SUMMARY_NAV_CONTRAST_UNTIL_WHOLE_JOB_OUTCOMES_COMPLETE',
    'legacy_scope':'LEGACY_FULL_NO_ALPHA_NOT_ORIGINAL_COMMON; NOT_RECERTIFIED',
    'initial_findings':['Standalone DOM fixture lacked repository root in sys.path; fixture fixed, full tests rerun PASS'],
    'browser_visual':'NOT_RUN_BROWSER_HOST_UNAVAILABLE; F11_PENDING','local_links':links,
    'checklist_synchronized':True,'integrity':integrity}
members = {'checks.json':(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()}
for name in (*results,'test_results.json','compiled.json','syntax.json','integrity.json','run_checks.py','rerun_dom.py','check_integrity.py','seal_checks.py'):
    members[name] = (QA/name).read_bytes()
members['manifest.json'] = (json.dumps({name:binding(raw) for name,raw in members.items()},indent=2)+'\n').encode()
with zipfile.ZipFile(TARGET,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in members.items(): archive.writestr(name,raw)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    for name,raw in members.items(): assert archive.read(name) == raw
print(json.dumps({'status':checks['status'],'python':156,'dom':31,'links':links,'members':len(members),
    'bound_files':len(files),'package':binding(TARGET.read_bytes())}))
