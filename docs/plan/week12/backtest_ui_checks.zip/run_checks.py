"""Gate chọn theo UI/serving/economics/PIT; source giữ nguyên trong khi worker chạy."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f10'
files = sorted(set(subprocess.check_output(['git','diff','--name-only','--','*.py'],cwd=ROOT).decode().splitlines()
    + subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.py'],cwd=ROOT).decode().splitlines()))
for name in files: py_compile.compile(str(ROOT/name),doraise=True)
(QA/'compiled.json').write_text(json.dumps({'status':'PASS','files':files,'count':len(files)},indent=2)+'\n',encoding='utf-8')
plans = [('tests/backtest_ui','test_evaluation.py'),('tests/backtest_ui','test_api.py'),
         ('tests/serving_runtime','test_runtime.py'),('tests/serving_runtime','test_api.py'),('tests/serving_runtime','test_resources.py'),
         ('tests/analysis_ui','test_pages.py'),('tests','test_variant_serving.py'),('tests','test_unified_experiment.py'),
         ('tests','test_research_results_viewer.py'),('tests','test_web_json_serialization.py'),('tests','test_original_fix_parity.py'),
         ('tests','test_free_pilot_statistics.py'),('tests/unified_analysis','test_analysis.py'),
         ('tests','test_unified_execution_leakage.py'),('tests','test_unified_preflight_leakage.py'),('tests/unified_live','test_leakage.py')]


def run(plan: tuple[str,str]) -> tuple[str,dict]:
    """Mỗi suite là process riêng; log stdout/stderr nguyên byte, không qua lỗi PowerShell stderr."""
    folder,pattern = plan
    command = [sys.executable,'-X','utf8','-m','unittest','discover','-s',folder,'-p',pattern,'-v']
    result = subprocess.run(command,cwd=ROOT,capture_output=True)
    raw = result.stdout+b'\n'+result.stderr
    name = folder.replace('/','_')+'_'+pattern.replace('.py','.log'); (QA/name).write_bytes(raw)
    count = re.search(rb'Ran (\d+) tests?',result.stderr)
    return name,{'returncode':result.returncode,'tests':int(count[1]) if count else None,
                 'command':command[1:],'log_sha256':hashlib.sha256(raw).hexdigest()}


results = {}
with ThreadPoolExecutor(max_workers=2) as pool:
    for future in as_completed([pool.submit(run,plan) for plan in plans]):
        name,result = future.result(); results[name] = result
        (QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
        print(name,result['returncode'],result['tests'],flush=True)
for name in ('backtest_ui','analysis_ui','research_viewer'):
    command = ['node','--test','tests/js/'+name+'.test.mjs']
    result = subprocess.run(command,cwd=ROOT,capture_output=True)
    raw = result.stdout+b'\n'+result.stderr; filename = name+'.log'; (QA/filename).write_bytes(raw)
    count = re.search(rb'(?:#|\xe2\x84\xb9) tests (\d+)',raw)
    results[filename] = {'returncode':result.returncode,'tests':int(count[1]) if count else None,
                        'command':command,'log_sha256':hashlib.sha256(raw).hexdigest()}
    print(filename,result.returncode,results[filename]['tests'],flush=True)
(QA/'test_results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
js = [*sorted((ROOT/'static/js/backtest').glob('*.js')),ROOT/'static/js/experiments/main.js']
for path in js: subprocess.run(['node','--check',str(path)],cwd=ROOT,check=True,capture_output=True)
(QA/'syntax.json').write_text(json.dumps({'status':'PASS','files':[p.relative_to(ROOT).as_posix() for p in js],'count':len(js)},indent=2)+'\n',encoding='utf-8')
print('TOTAL',sum(v['tests'] or 0 for k,v in results.items() if k.startswith('tests_')),sum(v['tests'] or 0 for k,v in results.items() if not k.startswith('tests_')),flush=True)
sys.exit(int(any(v['returncode'] for v in results.values())))
