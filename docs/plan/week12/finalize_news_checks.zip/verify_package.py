"""Kiểm QA FIN05 bằng thư viện chuẩn; không chạy scorer hoặc gọi nguồn mới."""
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys
import zipfile


def sha(raw: bytes) -> str:
    """Băm nguyên byte nguồn hoặc artifact."""
    return hashlib.sha256(raw).hexdigest()


def payload(raw: bytes) -> dict:
    """Đối soát envelope đang dùng trong repo."""
    value = json.loads(raw)
    encoded = json.dumps(value['payload'], ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    assert sha(encoded) == value['sha256']
    return value['payload']


archive, root = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(archive) as z:
    p = payload(z.read('manifest.json'))
    for name, pin in p['members'].items():
        raw = z.read(name)
        assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256'], name
    for pin in p['bindings']:
        raw = (root / pin['path']).read_bytes()
        assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256'], pin['path']
    assert platform.python_version() == p['runtime']['python']
    assert all(version(k) == v for k, v in p['runtime']['packages'].items())
    c, coverage = payload(z.read('corpus.json')), payload(z.read('coverage.json'))
    assert c['evidence_registry'] == {} and c['candidate_records'] == 180 and c['unique_articles'] == 177
    assert coverage['FIN05_complete'] and coverage['planned_points'] == coverage['unavailable_points'] == 102
    assert coverage['available_points'] == coverage['content_pit_proven_articles'] == 0
    assert p['tests_passed'] == 14 and b'Ran 14 tests' in z.read('tests.log') and b'OK' in z.read('tests.log')
    assert not coverage['query_outcomes_computed'] and not coverage['hosted_api_calls']
    print('PASS: QA/nguồn/runtime FIN05; 102 NA có lý do, không chạy lại test/model/API')
