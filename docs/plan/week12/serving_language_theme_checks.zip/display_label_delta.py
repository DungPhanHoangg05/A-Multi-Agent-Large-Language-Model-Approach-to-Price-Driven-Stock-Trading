"""Đối soát delta nhãn hiển thị sau gate, chỉ kiểm lại caller HTML bị ảnh hưởng."""
from datetime import datetime,timezone
import json
from pathlib import Path
import py_compile
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from scripts.serving_acceptance import reports as gate
from scripts.serving_acceptance.evidence import binding,runtime

with zipfile.ZipFile(gate.PACKAGE) as archive:
    members={name:archive.read(name) for name in archive.namelist() if name!='manifest.json'}
    manifest=json.loads(archive.read('manifest.json'))
assert all(binding(raw)==manifest[name] for name,raw in members.items())
initial=json.loads(members['checks.json']); receipt=json.loads(gate.RECEIPT.read_bytes())
assert binding(gate.PACKAGE.read_bytes())=={key:receipt['checks_package'][key] for key in ('bytes','sha256')}
sealed=gate.sources(); environment=runtime(ROOT); historical=gate.historical()
allowed={'utils/site_preferences.py','templates/demo_new.html','templates/analysis/legacy_output.html','tests/analysis_ui/test_preferences.py'}
changed={name for name in set(sealed)|set(initial['sources']) if sealed.get(name)!=initial['sources'].get(name)}
assert changed==allowed,changed
assert environment==initial['runtime'] and historical==initial['historical']
for name in sorted(allowed):
    if name.endswith('.py'): py_compile.compile(str(ROOT/name),doraise=True)
name,row=gate.suite(('tests/analysis_ui','test_*.py'))
assert row['passed'] and row['tests']==24,row
assert gate.sources()==sealed and runtime(ROOT)==environment
members['initial_checks.json']=members['checks.json']
members['initial_'+name]=members[name]
members[name]=(gate.WORK/name).read_bytes()
checks={**initial,'sources':sealed,'recorded_at':datetime.now(timezone.utc).isoformat()}
checks['test_suites'][name]=row
checks['display_label_delta']={'changed_files':sorted(changed),'initial_python_tests':101,
    'rerun_analysis_ui_tests':24,'new_tests':1,'unique_python_tests_passed':102,
    'note':'Sau gate 101 PASS, sửa nhãn timeframe/tên hệ thống ở lớp hiển thị. Chỉ chạy lại caller analysis_ui 24 ca; các suite khác giữ kết quả và nguồn nguyên byte.'}
members['checks.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
members['display_label_delta.py']=Path(__file__).read_bytes()
members['manifest.json']=(json.dumps({name:binding(raw) for name,raw in members.items()},indent=2)+'\n').encode()
with zipfile.ZipFile(gate.PACKAGE,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in members.items(): archive.writestr(name,raw)
receipt['checks_package']={'path':gate.PACKAGE.relative_to(ROOT).as_posix(),**binding(gate.PACKAGE.read_bytes())}
receipt['python_tests']=102
receipt['display_label_delta']=checks['display_label_delta']
gate.RECEIPT.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(gate.verify()))
