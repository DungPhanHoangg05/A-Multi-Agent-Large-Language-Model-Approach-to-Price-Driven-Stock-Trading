"""Khóa LF của test đã đổi để checkout Windows không làm sai checksum; không đổi hành vi."""
from pathlib import Path
import json
import sys
import zipfile
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from scripts.serving_acceptance import reports as gate
from scripts.serving_acceptance.evidence import binding,runtime
with zipfile.ZipFile(gate.PACKAGE) as archive:
    members={name:archive.read(name) for name in archive.namelist() if name!='manifest.json'}
checks=json.loads(members['checks.json']); receipt=json.loads(gate.RECEIPT.read_bytes())
sealed=gate.sources()
assert {name for name in set(sealed)|set(checks['sources']) if sealed.get(name)!=checks['sources'].get(name)}=={'tests/.gitattributes'}
assert runtime(ROOT)==checks['runtime'] and gate.historical()==checks['historical']
members['pre_checkout_checks.json']=members['checks.json']
checks['sources']=sealed
checks['checkout_normalization']={'file':'tests/.gitattributes','policy':'test_variant_serving.py + js/site_preferences.test.mjs: text eol=lf',
    'application_and_test_bytes_unchanged':True,'tests_rerun':False}
members['checks.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
members['checkout_delta.py']=Path(__file__).read_bytes()
members['manifest.json']=(json.dumps({name:binding(raw) for name,raw in members.items()},indent=2)+'\n').encode()
with zipfile.ZipFile(gate.PACKAGE,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in members.items(): archive.writestr(name,raw)
receipt['checks_package']={'path':gate.PACKAGE.relative_to(ROOT).as_posix(),**binding(gate.PACKAGE.read_bytes())}
receipt['checkout_normalization']=checks['checkout_normalization']
gate.RECEIPT.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(gate.verify()))
