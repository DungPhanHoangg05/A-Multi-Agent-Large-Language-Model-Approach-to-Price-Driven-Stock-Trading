"""Đối chiếu gói checkpoint tạo lại tín hiệu lịch sử bằng thư viện chuẩn."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import zipfile


def sha(raw: bytes) -> str:
    """Băm đúng byte nguồn và artifact."""
    return hashlib.sha256(raw).hexdigest()


def envelope(raw: bytes) -> dict:
    """Xác minh hash payload trước khi kiểm nội dung."""
    doc = json.loads(raw)
    payload = doc["payload"]
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    if sha(canonical.encode()) != doc["sha256"]:
        raise ValueError("Envelope khác checksum")
    return doc


repo, path = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(path) as z:
    manifest = envelope(z.read("manifest.json"))["payload"]
    assert set(z.namelist()) == set(manifest["members"]) | {"manifest.json"}
    for name, expected in manifest["members"].items():
        assert sha(z.read(name)) == expected, name
    recipe = envelope(z.read("recipe.json"))
    report = envelope(z.read("report.json"))["payload"]
    assert report["recipe_sha256"] == recipe["sha256"]
    for pin in recipe["payload"]["inputs"]:
        raw = (repo / pin["path"]).read_bytes()
        assert len(raw) == pin["bytes"] and sha(raw) == pin["sha256"], pin["path"]
    numeric = json.loads((repo / "outputs/finalize/bank_resources_v1/bank.json").read_bytes())
    expected = {p["episode_id"].replace(":", "-"): p for p in numeric["records"]}
    assert len(expected) == len(report["points"]) == 852
    assert set(expected) == {p["id"] for p in report["points"]}
    assert not report["hosted_calls"] and not report["query_outcomes_computed"] and not report["FIN06_complete"]
    alpha = Counter()
    regimes = set()
    selectors = {symbol: envelope(z.read(f"selectors/{symbol}.json")) for symbol in report["selector_sha256"]}
    for pointer in report["points"]:
        point = envelope(z.read(f"points/{pointer['id']}.json"))
        assert point["sha256"] == pointer["sha256"]
        row, original = point["payload"], expected[pointer["id"]]
        cutoff = row["cutoff"]
        assert row["episode_id"] == original["episode_id"] and cutoff == original["as_of_date"]
        assert {"r_net", "y", "outcome", "entry_open", "exit_close"}.isdisjoint(row)
        assert row["parent"]["recipe_sha256"] == recipe["sha256"]
        assert row["parent"]["news_sha256"] == original["news_snapshot_sha256"]
        assert row["sentiment"]["value"] is None and not row["sentiment"]["available"]
        assert row["indicator"]["value"] in ("BULLISH", "BEARISH", "NEUTRAL")
        assert all(v["value"] is None for v in row["vision"].values())
        proof = row["regime"]
        assert proof["metadata"]["train_end_date"] == cutoff
        assert proof["state"]["feature_end_date"] <= cutoff
        assert sha(z.read(f"regimes/VNINDEX-{cutoff}.json")) == proof["artifact_sha256"]
        regimes.add(cutoff)
        signal = row["alpha"]
        alpha[signal.get("reason", "AVAILABLE")] += 1
        selector = selectors[row["symbol"]]
        if signal["value"] is not None:
            assert report["selector_sha256"][row["symbol"]] == selector["sha256"] == signal["selector_sha256"]
            assert signal["fit_end"] == selector["payload"]["fit_end"] < cutoff
            assert len(signal["factors"]) == 5
        elif signal["reason"] == "BEFORE_HISTORICAL_SELECTOR_SUPPORT":
            assert cutoff < selector["payload"]["schedule"]["test_start"]
    assert alpha.pop("AVAILABLE") == report["alpha_count"]
    assert dict(alpha) == report["alpha_pending"]
    assert len(regimes) == report["regime_distinct_cutoffs"]
    print("PASS: 852 checkpoint, provenance HMM/Alpha/tin và trạng thái chờ thị giác")
