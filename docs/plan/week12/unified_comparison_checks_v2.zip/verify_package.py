"""Kiểm QA/source/runtime; có thể chạy lại numeric bằng --numeric không inference."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path(sys.argv[1]).resolve();package=Path(sys.argv[2]).resolve()
with zipfile.ZipFile(package) as archive:
    manifest=json.loads(archive.read('manifest.json'))
    assert len(archive.namelist())==len(set(archive.namelist()))
    assert set(archive.namelist())==set(manifest['members'])|{'manifest.json'}
    for name,expected in manifest['members'].items():
        raw=archive.read(name)
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],name
    assert Path(__file__).read_bytes()==archive.read('verify_package.py')
    for name,expected in manifest['artifact_bindings'].items():
        p=(root/name).resolve();assert p.is_relative_to(root)
        raw=p.read_bytes();assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],name
    accepted=json.loads(archive.read('cold_verify.log'))
    full=json.loads(archive.read('numeric_cold.log').decode('utf8').splitlines()[-1])
result=subprocess.run([sys.executable,'-I','-X','utf8','scripts/prepare_unified_comparison_v2.py','verify'],cwd=root,capture_output=True)
if result.returncode:
    sys.stderr.buffer.write(result.stderr);raise SystemExit(result.returncode)
assert json.loads(result.stdout)==accepted
assert full['status']=='PASS_U06_NUMERIC_COLD_REPLAY' and full['points']==102 and full['manifest_sha256']==accepted['manifest_sha256']
status='REUSED_LOCKED_NUMERIC_RESULT_SOURCE_ASSETS_RUNTIME_MATCH'
if '--numeric' in sys.argv[3:]:
    rerun=subprocess.run([sys.executable,'-I','-X','utf8','scripts/prepare_unified_comparison_v2.py','replay-numeric'],cwd=root,capture_output=True)
    if rerun.returncode:
        sys.stderr.buffer.write(rerun.stderr);raise SystemExit(rerun.returncode)
    assert json.loads(rerun.stdout.decode('utf8').splitlines()[-1])==full
    status='RERUN_NUMERIC_MATCHED'
print(json.dumps({'status':'PASS_U06_QA','tests':146,'points':102,'source_bindings':660,'numeric':status,'api':False},sort_keys=True))
