"""Chạy đúng các test chịu ảnh hưởng U03, lưu log UTF-8 và IDs đã thực thi."""
from contextlib import redirect_stdout, redirect_stderr
import json
from pathlib import Path
import sys
import unittest

root = Path.cwd().resolve()
sys.path[:0] = [str(root), str(root / 'tests')]
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
groups = {
    'parity': ['test_original_fix_parity', 'test_prepare_chart_r4'],
    'graphs': ['test_backtest_token_budget', 'test_paired_protocol', 'test_prior_graph_integration',
               'test_prior_prompt_contract', 'test_decision_prior_integration', 'test_mt_bicl_decision',
               'test_alpha_leakage', 'test_sentiment_leakage'],
    'entrypoints': ['test_ablation_matrix', 'test_robustness_sweep', 'test_web_json_serialization',
                    'test_target_contract', 'test_account_risk'],
    'recovery': ['test_prior_backtest_integration', 'test_prior_backtest_leakage', 'test_prior_checkpoint',
                 'test_prior_checkpoint_leakage', 'test_prior_stage_recovery'],
    'locks': ['test_research_input_lock', 'test_research_input_lock_leakage'],
}


def test_ids(suite):
    """Giữ IDs trước khi unittest dọn test object sau thực thi."""
    for value in suite:
        if isinstance(value, unittest.TestSuite):
            yield from test_ids(value)
        else:
            yield value.id()


group, output = sys.argv[1], Path(sys.argv[2])
with output.open('w', encoding='utf-8', newline='\n') as handle, redirect_stdout(handle), redirect_stderr(handle):
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in groups[group])
    ids = list(test_ids(suite))
    result = unittest.TextTestRunner(stream=handle, verbosity=2).run(suite)
summary = {'group': group, 'modules': groups[group], 'test_ids': ids, 'tests': result.testsRun,
           'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped)}
output.with_suffix('.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(group, result.testsRun, len(result.failures), len(result.errors), len(result.skipped), flush=True)
sys.exit(not result.wasSuccessful() or bool(result.skipped))
