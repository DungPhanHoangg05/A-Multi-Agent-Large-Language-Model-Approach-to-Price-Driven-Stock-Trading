from pathlib import Path
import sys,tempfile,unittest,json,py_compile,hashlib
root=Path.cwd()
sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
loader=unittest.TestLoader()
suite=loader.discover(str(root/'tests/unified_model_quota'),pattern='test_*.py')
for name in ('unified_live.test_leakage','test_unified_execution_recovery','test_unified_execution_leakage'):
    suite.addTests(loader.loadTestsFromName(name))
def ids(value):
    for item in value:
        if isinstance(item,unittest.TestSuite):
            yield from ids(item)
        else:
            yield item.id()
test_ids=list(ids(suite))
p=Path(tempfile.gettempdir())
with (p/'model_quota_tests.log').open('w',encoding='utf-8') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
from core.unified_model_quota.runtime import sources
pins=sources(root)
compiled=[]
if result.wasSuccessful():
    for name in pins:
        if name.endswith('.py'):
            py_compile.compile(str(root/name),doraise=True)
            compiled.append(name)
record={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'test_ids':test_ids,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'compiled':compiled,'sources':pins,'log_sha256':hashlib.sha256((p/'model_quota_tests.log').read_bytes()).hexdigest(),'scope':'MODEL_SCOPED_QUOTA_RESUME_RAW_PREFIX_RELEASE_PAIRED_LABEL_BARRIER_RETRY_CHECKPOINT','inference_requests':0}
(p/'model_quota_tests.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:record[k] for k in ('status','tests','failures','errors','skips')},ensure_ascii=False))
if not result.wasSuccessful():
    print((p/'model_quota_tests.log').read_text(encoding='utf-8')[-8500:])
raise SystemExit(not result.wasSuccessful())
