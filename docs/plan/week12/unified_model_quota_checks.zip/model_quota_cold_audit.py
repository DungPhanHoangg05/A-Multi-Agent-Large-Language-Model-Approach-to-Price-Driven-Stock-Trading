from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
import sys,json,tempfile,hashlib
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
from core.unified_model_quota.runtime import audit
with ExitStack() as stack:
    for name in ('httpx.Client','httpx.AsyncClient','httpx.HTTPTransport','langchain_groq.ChatGroq','dotenv.dotenv_values','core.unified_execution_providers.StudyProviders'):
        stack.enter_context(patch(name,side_effect=AssertionError('Cold audit cấm key/client/provider: '+name)))
    result=audit(root)
assert result['status']=='PARTIAL_U08' and result['complete_points']==32
assert result['forecast_slots']==768 and result['http_attempts']==487
assert result['first_model_scoped_http_sequence']==487
assert len(result['current_admission_probe'])==10
assert all(item['reserve']==8000 and item['admission']=='READY' for item in result['current_admission_probe'])
p=Path(tempfile.gettempdir())
before=json.loads((p/'model_quota_original_bindings.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha for name,sha in before.items())
result.update(audit_status='PASS_MODEL_QUOTA_COLD_HANDOFF',checkpoint_files_unchanged=len(before),actual_new_http_attempts=0,constructors_blocked=6,external_network_blocked=True)
(p/'model_quota_cold_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
