"""Kiểm byte/runtime gói FIN03; không chạy suite, fit, client hoặc API."""
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys
import zipfile

archive,root=Path(sys.argv[1]),Path(sys.argv[2])
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
with zipfile.ZipFile(archive) as z:
    envelope=json.loads(z.read("manifest.json"));p=envelope["payload"]
    canonical=json.dumps(p,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode()
    assert sha(canonical)==envelope["sha256"]
    for name,pin in p["members"].items():
        raw=z.read(name);assert len(raw)==pin["bytes"] and sha(raw)==pin["sha256"],name
    for pin in [*p["source_bindings"].values(),*p["parents"]]:
        raw=(root/pin["path"]).read_bytes()
        assert len(raw)==pin["bytes"] and sha(raw)==pin["sha256"],pin["path"]
    inventory=json.loads((root/"docs/plan/week12/finalize_inventory.json").read_bytes())["payload"]
    pins={**inventory["source_bindings"],**p["source_bindings"]}
    for pin in [*pins.values(),*inventory["evidence_bindings"]]:
        raw=(root/pin["path"]).read_bytes()
        assert len(raw)==pin["bytes"] and sha(raw)==pin["sha256"],pin["path"]
    assets=json.loads((root/"docs/plan/week12/unified_comparison_manifest_v2.json").read_bytes())["payload"]["asset_bindings"]
    for name,pin in assets.items():
        raw=(root/name).read_bytes()
        assert len(raw)==pin["bytes"] and sha(raw)==pin["sha256"],name
    assert platform.python_version()==p["runtime"]["python"]
    assert all(version(name)==expected for name,expected in p["runtime"]["packages"].items())
    assert sum(row["tests"] for row in p["suites"].values())==41
    print("PASS: byte nguồn/runtime/gói FIN03; không chạy lại suite, API hoặc fit")
