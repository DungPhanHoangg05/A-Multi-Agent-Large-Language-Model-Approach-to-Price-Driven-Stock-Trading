"""Đối soát nguồn, nhãn, dữ liệu bảng và hình học của hai PDF đã biên dịch."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import re
import subprocess
import fitz

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
BUILD = WORK / 'build2'
hash_bytes = lambda value: hashlib.sha256(value).hexdigest()
checks = {}
with ZipFile(WORK / 'before_sources.zip') as before, ZipFile(ROOT / 'outputs/revision/manuscript_unified_final_v1/sources.zip') as frozen:
    names = before.namelist()
    assert all(before.read(name) == frozen.read(name) for name in names)
    checks['baseline_paper_files_match_frozen_archive'] = len(names)
    tables = equations = images = 0
    for name in names:
        old = before.read(name)
        new = (ROOT / name).read_bytes()
        if '/generated/' in name and name.endswith('.tex'):
            pattern = rb'\\begin\{tabular\}.*?\\end\{tabular\}'
            old_tables = re.findall(pattern, old, re.S)
            assert old_tables == re.findall(pattern, new, re.S), name
            tables += len(old_tables)
            if 'summary_numbers' in name:
                assert old == new, name
        if '/sections/' in name and name.endswith('.tex'):
            pattern = rb'\\begin\{(?:equation\*?|align\*?)\}.*?\\end\{(?:equation\*?|align\*?)\}'
            old_equations = re.findall(pattern, old, re.S)
            assert old_equations == re.findall(pattern, new, re.S), name
            equations += len(old_equations)
        if '/figs/' in name or name.endswith(('.png', '.svg')):
            assert old == new, name
            images += 1
    checks.update(table_panels_unchanged=tables, equation_blocks_unchanged=equations,
                  figure_assets_unchanged=images)

def render(name: str) -> dict:
    """Render bằng Poppler và kiểm log, nhãn, vùng chữ cùng phông nhúng."""
    folder = BUILD / name
    log = (folder / (name + '.log')).read_text(encoding='utf-8', errors='replace')
    defects = re.findall(r'(?m)^.*(?:Overfull|LaTeX Warning|Package .+ Warning|Missing character).*$' , log)
    assert not defects, defects
    assert 'undefined' not in log.lower()
    bbl = (folder / (name + '.bbl')).read_text(encoding='utf-8')
    keys = re.findall(r'\\bibitem\{([^}]+)\}', bbl)
    assert len(keys) == len(set(keys)) == 43
    assert keys[5] == 'tsantekidis2017lob'
    assert '/metrics' not in bbl
    assert 'https://pure.au.dk/portal/en/publications/' in bbl
    aux = (folder / (name + '.aux')).read_text(encoding='utf-8')
    labels = re.findall(r'\\newlabel\{((?:tab|fig|alg):[^}]+)\}\{\{([^}]+)\}\{([^}]+)\}', aux)
    assert len(labels) == 29
    doc = fitz.open(folder / (name + '.pdf'))
    outside, fonts, anchors = [], set(), {}
    for index, page in enumerate(doc):
        for word in page.get_text('words'):
            if word[0] < 0 or word[1] < 0 or word[2] > page.rect.width + .5 or word[3] > page.rect.height + .5:
                outside.append([index + 1, word[4]])
        for font in page.get_fonts():
            if font[2] == 'Type3':
                fonts.add(font[3])
        for label, number, logical_page in labels:
            if label.startswith('tab:'):
                needle = 'Table ' + number + ':'
            elif label.startswith('fig:'):
                needle = 'Figure ' + number + ':'
            else:
                needle = 'Algorithm ' + number + ':'
            if needle in page.get_text():
                anchors[label] = {'number': number, 'latex_page': logical_page, 'pdf_page': index + 1}
    assert not outside, outside
    assert not fonts, fonts
    assert len(anchors) == 29, set(x[0] for x in labels) - anchors.keys()
    pngs = WORK / ('render_' + name)
    pngs.mkdir(exist_ok=True)
    result = subprocess.run(['pdftoppm', '-r', '100', '-png', str((folder / (name + '.pdf')).relative_to(WORK)),
                             str((pngs / 'page').relative_to(WORK))], cwd=WORK,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (WORK / (name + '_render.log')).write_bytes(result.stdout)
    assert result.returncode == 0
    assert len(list(pngs.glob('page-*.png'))) == len(doc)
    return {'entrypoint': name, 'pages': len(doc), 'references': len(keys), 'reference_keys': keys,
            'table_figure_algorithm_locators': anchors, 'overfull_or_warnings': defects,
            'underfull_notices': log.count('Underfull'), 'words_outside_page': outside,
            'type3_fonts': sorted(fonts), 'poppler_rendered_pages': len(doc),
            'pdf_sha256': hash_bytes((folder / (name + '.pdf')).read_bytes())}

with ThreadPoolExecutor(max_workers=2) as pool:
    checks['pdfs'] = list(pool.map(render, ('main', 'main_submit')))
(WORK / 'checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({key: value for key, value in checks.items() if key != 'pdfs'}, ensure_ascii=False))
for item in checks['pdfs']:
    print(item['entrypoint'], item['pages'], item['references'], item['poppler_rendered_pages'])
