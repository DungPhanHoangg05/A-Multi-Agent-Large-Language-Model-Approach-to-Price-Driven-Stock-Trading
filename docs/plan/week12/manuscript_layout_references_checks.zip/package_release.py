"""Đóng gói nguồn Overleaf và QA riêng, không ghi đè các release lịch sử."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
RELEASE = ROOT / 'outputs/revision/manuscript_layout_references_v1'
RELEASE.mkdir(exist_ok=False)
digest = lambda value: hashlib.sha256(value).hexdigest()
encode = lambda value: (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode('utf-8')
checks = json.loads((WORK / 'checks.json').read_text(encoding='utf-8'))
checks['visual_review'] = {
    'contact_sheet_pages_reviewed': {'main': 50, 'main_submit': 50},
    'individual_poppler_pages_reviewed': {'main': [44, 46, 47], 'main_submit': [41]},
    'result': 'PASS',
    'scope': 'Bố cục toàn bộ hai bản; đọc riêng bảng lưới và URL reference 6; không có mất/cắt chữ quan sát được.'}
checks['bibliography_notice'] = 'Mỗi bản có một BibTeX notice: empty pages in xie2022implicitbayes; ICLR điện tử không có số trang, giữ nguyên metadata.'
checks['reference_6_link'] = {'url': 'https://pure.au.dk/portal/en/publications/forecasting-stock-prices-from-the-limit-order-book-using-convolut/',
                               'status': 200, 'verified_date': '2026-11-13',
                               'title_authors_article_number_match': True, 'doi': '10.1109/CBI.2017.23'}
(WORK / 'checks.json').write_bytes(encode(checks))

for name in ('main', 'main_submit'):
    shutil.copyfile(WORK / 'build2' / name / (name + '.pdf'), RELEASE / (name + '.pdf'))
anchors = {item['entrypoint']: item['table_figure_algorithm_locators'] for item in checks['pdfs']}
(RELEASE / 'pdf_anchors.json').write_bytes(encode(anchors))
sources = []
with ZipFile(RELEASE / 'overleaf.zip', 'x', ZIP_DEFLATED) as archive:
    for path in sorted((ROOT / 'paper').rglob('*')):
        if path.is_file():
            raw = path.read_bytes()
            sources.append({'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': digest(raw)})
            archive.writestr(path.relative_to(ROOT / 'paper').as_posix(), raw)
with ZipFile(RELEASE / 'overleaf.zip') as archive:
    assert archive.testzip() is None
    for source in sources:
        assert digest(archive.read(source['path'].removeprefix('paper/'))) == source['sha256']

blocks = re.split(r'(?m)(?=^@)', (ROOT / 'paper/references.bib').read_text(encoding='utf-8'))
entries = {}
for block in blocks:
    match = re.match(r'@\w+\{([^,]+),', block)
    if match:
        entry = {}
        for line in block.splitlines():
            field = re.match(r'\s*(title|author|year|doi|url)\s*=\s*\{(.*)\},?$', line)
            if field:
                entry[field[1]] = field[2]
        entries[match[1]] = entry
new_keys = set(entries) - set(re.findall(r'(?m)^@\w+\{([^,]+),',
    ZipFile(WORK / 'before_sources.zip').read('paper/references.bib').decode('utf-8')))
reference_keys = checks['pdfs'][0]['reference_keys']
assert len(new_keys) == 14 and new_keys <= set(reference_keys)
ledger = {'date': '2026-11-13', 'cited_references_before': 21, 'cited_references_after': 43,
          'new_bibtex_entries': sorted(new_keys), 'reference_6_link': checks['reference_6_link'],
          'entries': [{'number': index, 'key': key, **entries[key]} for index, key in enumerate(reference_keys, 1)],
          'verification_scope': 'Các nguồn bổ sung dùng bài gốc, trang tác giả/đại học, nhà xuất bản hoặc tài liệu chính thức; không thêm nguồn chỉ bằng nocite.'}
(RELEASE / 'reference_ledger.json').write_bytes(encode(ledger))

qa_path = ROOT / 'docs/plan/week12/manuscript_layout_references_checks.zip'
with ZipFile(qa_path, 'x', ZIP_DEFLATED) as archive:
    for filename in ('build_paper.py', 'qa_paper.py', 'package_release.py', 'checks.json', 'main_render.log', 'main_submit_render.log'):
        archive.write(WORK / filename, filename)
    archive.write(WORK / 'build2/commands.json', 'build_commands.json')
    for name in ('main', 'main_submit'):
        folder = WORK / 'build2' / name
        for path in sorted(folder.iterdir()):
            if path.suffix in ('.log', '.aux', '.bbl', '.blg', '.fls', '.out'):
                archive.write(path, name + '/' + path.name)
        for path in sorted((WORK / ('render_' + name)).glob('*.png')):
            archive.write(path, 'render/' + name + '/' + path.name)
    for path in sorted(WORK.glob('contact2_*.png')):
        archive.write(path, 'contact/main/' + path.name)
    for path in sorted(WORK.glob('submit_contact_*.png')):
        archive.write(path, 'contact/main_submit/' + path.name)
with ZipFile(qa_path) as archive:
    assert archive.testzip() is None

manifest = {
    'schema': 'manuscript_layout_reference_release_v1', 'created_date': '2026-11-13',
    'status': 'PASS_LOCAL_LAYOUT_AND_REFERENCE_REVISION',
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
    'baseline_manifest': 'outputs/revision/manuscript_unified_final_v1/manifest.json',
    'baseline_manifest_sha256': digest((ROOT / 'outputs/revision/manuscript_unified_final_v1/manifest.json').read_bytes()),
    'sources': sources,
    'outputs': [{'path': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())}
                for path in sorted(RELEASE.iterdir())],
    'qa': {'path': qa_path.relative_to(ROOT).as_posix(), 'bytes': qa_path.stat().st_size, 'sha256': digest(qa_path.read_bytes())},
    'validation': checks,
    'boundaries': ['Chỉ tài liệu và bố cục; số liệu và runtime nghiên cứu không đổi.',
                   'Không chạy lại inference, scoring, thống kê, unit/E2E/leakage hoặc compileall.',
                   'Các release và crosswalk reviewer cũ giữ phạm vi lịch sử; không cấp quyền công bố hoặc đóng phản biện khoa học.']}
manifest['sha256'] = digest(encode(manifest))
(RELEASE / 'manifest.json').write_bytes(encode(manifest))
print('Đã đóng gói ' + str(RELEASE))
print('QA:', qa_path.stat().st_size, 'byte; nguồn Overleaf:', len(sources), 'tệp')
