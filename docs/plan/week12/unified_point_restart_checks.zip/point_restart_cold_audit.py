from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
from datetime import datetime,timezone
import sys,json,tempfile,hashlib,zipfile
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
from core.historical_evaluation_journal import load
from core.unified_point_restart.runtime import audit,RUNTIME,BACKUP
from core.unified_live.release import NAMESPACES
with ExitStack() as stack:
 for name in ('httpx.Client','httpx.AsyncClient','httpx.HTTPTransport','langchain_groq.ChatGroq','dotenv.dotenv_values','core.unified_execution_providers.StudyProviders'):
  stack.enter_context(patch(name,side_effect=AssertionError('Cold audit cấm key/client/provider: '+name)))
 result=audit(root)
assert result['status']=='PARTIAL_U08' and result['complete_points']==67
assert result['forecast_slots']==1608 and result['http_attempts']==1087
assert len(result['current_admission_probe'])==10
assert all(item['reserve']==8000 and item['admission']=='READY' for item in result['current_admission_probe'])
p=Path(tempfile.gettempdir());before=json.loads((p/'recovery_original_bindings.json').read_text(encoding='utf-8'))
manifest=load(root/RUNTIME);plan=manifest['plan'];directory=root/NAMESPACES['RESEARCH']
deleted={NAMESPACES['RESEARCH']+'/'+name for name in plan['deleted_slots']}
assert len(deleted)==44
assert all(not (root/name).exists() for name in deleted)
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha for name,sha in before.items() if name not in deleted)
with zipfile.ZipFile(root/BACKUP) as archive:
 assert len(archive.namelist())==len(plan['backup_files'])
 assert all(hashlib.sha256(archive.read(name)).hexdigest()==sha for name,sha in plan['backup_files'].items())
status=load(directory/'status.json')
assert status['complete_points']==67 and status['forecast_complete']==1632 and status['labels_complete']==67
assert status['blocked']=={} and status['waiting']=={}
assert (directory/'stop.request').exists()
result.update(audit_status='PASS_EXPLICIT_POINT_RESTART_COLD_HANDOFF',checkpoint_files_unchanged=len(before)-len(deleted),checkpoint_files_archived_and_deleted=len(deleted),backup_members=len(plan['backup_files']),actual_new_http_attempts=0,constructors_blocked=6,external_network_blocked=True,active_status=status,verified_at_utc=datetime.now(timezone.utc).isoformat())
(p/'point_restart_cold_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
