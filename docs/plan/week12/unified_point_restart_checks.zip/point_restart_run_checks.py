from pathlib import Path
import sys,tempfile,unittest,json,py_compile,hashlib
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
from scripts.verify_original_fix_parity import deny_external_network
deny_external_network()
loader=unittest.TestLoader()
suite=loader.discover(str(root/'tests/unified_point_restart'),pattern='test_*.py')
for name in ('unified_live.test_leakage','unified_model_quota.test_policy.PrefixTests'):
    suite.addTests(loader.loadTestsFromName(name))
def ids(value):
    for item in value:
        if isinstance(item,unittest.TestSuite):yield from ids(item)
        else:yield item.id()
test_ids=list(ids(suite));p=Path(tempfile.gettempdir())
with (p/'point_restart_tests.log').open('w',encoding='utf-8') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
from core.unified_point_restart.runtime import sources
pins=sources(root);compiled=[]
if result.wasSuccessful():
    for name in pins:
        if name.endswith('.py'):
            py_compile.compile(str(root/name),doraise=True);compiled.append(name)
record={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'test_ids':test_ids,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'compiled':compiled,'sources':pins,'log_sha256':hashlib.sha256((p/'point_restart_tests.log').read_bytes()).hexdigest(),'scope':'POINT_RESET_ARCHIVE_RAW_GENERATIONS_RETRY_CAP_PAIRED_BARRIER_AND_LEAKAGE','inference_requests':0}
(p/'point_restart_tests.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:record[k] for k in ('status','tests','failures','errors','skips')},ensure_ascii=False))
if not result.wasSuccessful():print((p/'point_restart_tests.log').read_text(encoding='utf-8')[-9500:])
raise SystemExit(not result.wasSuccessful())
