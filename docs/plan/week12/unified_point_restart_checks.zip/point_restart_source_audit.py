from pathlib import Path
import json,zipfile,hashlib,subprocess,tempfile
root=Path.cwd()
with zipfile.ZipFile(root/'docs/plan/week12/unified_execution_checks.zip') as z: pins=json.loads(z.read('source_bindings.json'))
for name in ('unified_live_runtime.json','unified_model_quota_runtime.json','unified_provider_quota_runtime.json'):
 pins.update(json.loads((root/'docs/plan/week12'/name).read_text(encoding='utf-8'))['payload']['sources'])
old_names=set(pins)
new=json.loads((root/'docs/plan/week12/unified_point_restart_runtime.json').read_text(encoding='utf-8'))['payload']['sources'];pins.update(new)
assert len(old_names)==702 and len(pins)==711
for name,expected in pins.items():
 content=(root/name).read_bytes()
 assert hashlib.sha256(content).hexdigest()==expected['sha256'],name
 assert len(content)==expected['bytes'],name
changes=set(subprocess.check_output(['git','diff','--name-only','05cef94b','HEAD'],text=True).splitlines())
assert not changes & old_names, sorted(changes & old_names)
for name in new:
 assert subprocess.check_output(['git','show','HEAD:'+name])==(root/name).read_bytes(),name
report={'status':'PASS','source_pins':len(pins),'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'original_source_pins':len(old_names),'git_delta_intersecting_original_sources':0,'all_working_sources_match_frozen_byte_hashes':True,'new_9_sources_match_git':True,'old_working_eol_preserved':True}
(Path(tempfile.gettempdir())/'point_restart_source_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
