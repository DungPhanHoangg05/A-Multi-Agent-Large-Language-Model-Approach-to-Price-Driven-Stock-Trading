"""Kiểm offline gói nguồn FIN04 và byte đầu vào cũ; không tải lại hoặc fit model."""
import csv
from datetime import date, timedelta
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile


def encoded(value: object) -> bytes:
    """Mã hóa chuẩn envelope bằng thư viện chuẩn."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(raw: bytes) -> str:
    """Băm byte bằng SHA256."""
    return hashlib.sha256(raw).hexdigest()


def envelope(raw: bytes) -> dict:
    """Xác minh envelope trước khi dùng payload."""
    value = json.loads(raw)
    assert set(value) == {"payload", "sha256"} and sha(encoded(value["payload"])) == value["sha256"]
    return value["payload"]


def verify(root: Path, package: Path) -> None:
    """Đối soát nguồn gói mới và toàn bộ binding input audit đã đóng băng."""
    with zipfile.ZipFile(package) as archive:
        names = archive.namelist()
        manifest = json.loads(archive.read("manifest.json"))
        assert len(names) == len(set(names)) and set(names) == set(manifest) | {"manifest.json"}
        for name, expected in manifest.items():
            raw = archive.read(name)
            assert len(raw) == expected["bytes"] and sha(raw) == expected["sha256"], name
        report = envelope(archive.read("report.json"))
        assert report["FIN04_complete"] is False and report["admitted_points"] == 0
        assert report["price_source_gate"] == "BLOCKED_PIT_PROVENANCE"
        for parent in report["parents"]:
            raw = (root / parent["path"]).read_bytes()
            assert len(raw) == parent["bytes"] and sha(raw) == parent["sha256"], parent["path"]
        audit = envelope((root / "docs/plan/week12/finalize_price_audit.json").read_bytes())
        for parent in audit["source_bindings"].values():
            raw = (root / parent["path"]).read_bytes()
            assert len(raw) == parent["bytes"] and sha(raw) == parent["sha256"], parent["path"]
        sources = {item["id"]: item for item in report["sources"]}
        for item in sources.values():
            raw = archive.read(item["path"])
            assert sha(raw) == item["sha256"] and len(raw) == item["bytes"]
            assert item["as_published_snapshot_authenticated"] is False
        points = {item["id"]: item for item in audit["points"]}
        assert len(report["event_corroborations"]) == 5
        for event in report["event_corroborations"]:
            point = points[event["point_id"]]
            assert event["vendor_exright_date"] in point["known_event_dates_inside_holding"]
            assert sources[event["source_id"]]["publisher_updated_at_displayed"][:10] < point["cutoff"]
            assert event["exright_date_explicit_in_this_primary_notice"] is False
        calendar = root / "outputs/historical_reevaluation/h02_data_r1/VNINDEX_2018_2026_verified_overlap.csv"
        with calendar.open(encoding="utf8", newline="") as handle:
            observed = [row["Datetime"] for row in csv.DictReader(handle)]
        for item in report["calendar_comparisons"]:
            actual = [d for d in observed if item["start"] <= d <= item["end"]]
            assert len(actual) == item["observed_sessions"] == item["expected_sessions"]
            assert not item["missing"] and not item["extra"]
        assert report["calendar_comparisons"][-1]["observed_sessions"] == 58
    print(json.dumps({"status": "PASS_EVIDENCE_INTEGRITY_SOURCE_GATE_BLOCKED", "source_members": len(sources),
                      "frozen_input_bindings": len(audit["source_bindings"]), "FIN04_complete": False,
                      "tests_rerun": False, "network_calls": 0, "query_outcomes_computed": False}))


if __name__ == "__main__":
    verify(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
