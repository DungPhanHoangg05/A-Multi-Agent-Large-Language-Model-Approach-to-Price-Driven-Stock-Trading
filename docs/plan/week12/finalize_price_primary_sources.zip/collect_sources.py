"""Thu bằng chứng công khai FIN04; không thay dữ liệu thực nghiệm đã khóa."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

from bs4 import BeautifulSoup
import requests

ROOT = Path(__file__).resolve().parent / "fin04_primary"
ROOT.mkdir(exist_ok=True)
SOURCES = [
    ("fpt_2023", "https://vsdc.vn/vi/ad/159649", "html"),
    ("vnm_2024", "https://vsdc.vn/vi/ad/174349", "html"),
    ("mbb_2025", "https://vsdc.vn/vi/ad/178088", "html"),
    ("vcb_2025", "https://vsdc.vn/vi/ad/187574", "html"),
    ("vnm_2026", "https://vsdc.vn/vi/ad/197038", "html"),
    ("hose_2025", "https://staticfile.hsx.vn/Uploads/UploadDocuments/1737138/20241226_20242612_Thong%20bao%20ve%20lich%20nghi%202025.pdf", "pdf"),
    ("hose_2026_newyear", "https://staticfile.hsx.vn/Uploads/UploadDocuments/2426350/20251225_Thong%20bao%20%20ve%20%20viec%20cap%20nhat%20lich%20nghi%20giao%20dich%20Tet%20Duong%20lich%202026%20toan%20thi%20truong.pdf", "pdf"),
    ("hose_2026_news", "https://api.hsx.vn/n/api/v1/1/news/2437411", "json"),
    ("vnstock_price_semantics", "https://vnstocks.com/blog/du-lieu-lich-su-va-thong-ke-giao-dich-co-phieu-vnindex", "html"),
]


def collect(source: tuple[str, str, str]) -> dict:
    """Lưu byte HTTP và thời điểm thu riêng với thời gian hiển thị của nhà xuất bản."""
    name, url, extension = source
    started = datetime.now(timezone.utc).isoformat()
    response = requests.get(url, timeout=45)
    response.raise_for_status()
    data = response.content
    if extension == "pdf" and not data.startswith(b"%PDF-"):
        raise ValueError("Nguồn không phải PDF")
    relative = f"{name}.{extension}"
    (ROOT / relative).write_bytes(data)
    result = {
        "id": name, "requested_url": url, "response_url": response.url,
        "retrieval_started_at_utc": started,
        "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
        "http_status": response.status_code,
        "headers": {key: response.headers.get(key) for key in
                    ("Content-Type", "Date", "Last-Modified", "ETag")},
        "path": relative, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
        "as_published_snapshot_authenticated": False,
    }
    if url.startswith("https://vsdc.vn/"):
        soup = BeautifulSoup(data, "html.parser")
        title = soup.select_one("h3.title-category")
        body = soup.select_one("div.content-category")
        stamp = soup.select_one("div.time-newstcph")
        if not all((title, body, stamp)):
            raise ValueError("Thiếu vùng bài gốc VSDC")
        match = re.search(r"(\d{2}/\d{2}/\d{4}).*?(\d{2}:\d{2}:\d{2})", stamp.get_text(" ", strip=True))
        if not match:
            raise ValueError("Thiếu timestamp hiển thị VSDC")
        parsed = datetime.strptime(" ".join(match.groups()), "%d/%m/%Y %H:%M:%S")
        result["publisher_updated_at_displayed"] = parsed.isoformat() + "+07:00"
        result["title"] = title.get_text(" ", strip=True)
        result["article_text"] = body.get_text("\n", strip=True)
    return result


if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=4) as pool:
        records = list(pool.map(collect, SOURCES))
    (ROOT / "acquisition.json").write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    for item in records:
        print(item["id"], item["bytes"], item.get("publisher_updated_at_displayed", ""))
