"""Đóng gói chứng cứ nguồn bổ sung; không cấp lại gate hoặc sửa input nghiên cứu."""
from datetime import date, datetime, timedelta, timezone
import csv
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "tmp/fin04_primary"
OUTPUT = ROOT / "docs/plan/week12/finalize_price_primary_sources.zip"


def encoded(value: object) -> bytes:
    """Mã hóa JSON theo envelope hiện có của kho bằng chứng."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(raw: bytes) -> str:
    """Băm nguyên byte."""
    return hashlib.sha256(raw).hexdigest()


def bind(name: str) -> dict:
    """Khóa file hiện có trong repo, không chuẩn hóa newline."""
    raw = (ROOT / name).read_bytes()
    return {"path": name, "bytes": len(raw), "sha256": sha(raw)}


def weekdays(start: str, end: str, holidays: list[str]) -> list[str]:
    """Dựng lịch đối chiếu theo ngày làm việc và danh sách nghỉ đã đọc từ HOSE."""
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    days = (first + timedelta(days=i) for i in range((last-first).days + 1))
    return [d.isoformat() for d in days if d.weekday() < 5 and d.isoformat() not in holidays]


if __name__ == "__main__":
    records = json.loads((SOURCE / "acquisition.json").read_text("utf8"))
    sources = {item["id"]: item for item in records}
    events = [
        ("fpt_2023", "FPT-2023-07-03", "06/07/2023", "2023-07-05", 1000, 0.15),
        ("vnm_2024", "VNM-2024-09-20", "25/09/2024", "2024-09-24", 2450, 0.0),
        ("mbb_2025", "MBB-2025-01-02", "08/01/2025", "2025-01-07", 0, 0.15),
        ("vcb_2025", "VCB-2025-10-01", "06/10/2025", "2025-10-03", 450, 0.0),
        ("vnm_2026", "VNM-2026-06-24", "29/06/2026", "2026-06-26", 1850, 0.0),
    ]
    audit_path = "docs/plan/week12/finalize_price_audit.json"
    audit = json.loads((ROOT / audit_path).read_bytes())["payload"]
    points = {p["id"]: p for p in audit["points"]}
    corroborated = []
    for source_id, point_id, record_date, ex_date, cash, stock in events:
        source, point = sources[source_id], points[point_id]
        assert record_date in source["article_text"]
        assert point["symbol"] in source["title"]
        stamp = datetime.fromisoformat(source["publisher_updated_at_displayed"])
        cutoff = datetime.fromisoformat(point["cutoff"] + "T15:30:00+07:00")
        assert stamp < cutoff
        assert ex_date in point["known_event_dates_inside_holding"]
        corroborated.append({
            "point_id": point_id, "source_id": source_id,
            "record_date": datetime.strptime(record_date, "%d/%m/%Y").date().isoformat(),
            "vendor_exright_date": ex_date,
            "cash_dividend_vnd_per_share": cash, "stock_dividend_fraction": stock,
            "publisher_displayed_update_precedes_cutoff": True,
            "event_identity_and_record_date_corroborated": True,
            "exright_date_explicit_in_this_primary_notice": False,
            "current_page_proves_immutable_historical_contents": False,
        })
    calendar_path = "outputs/historical_reevaluation/h02_data_r1/VNINDEX_2018_2026_verified_overlap.csv"
    with (ROOT / calendar_path).open(encoding="utf8", newline="") as handle:
        observed = [row["Datetime"] for row in csv.DictReader(handle)]
    holidays_2025 = ["2025-01-01", "2025-01-27", "2025-01-28", "2025-01-29", "2025-01-30", "2025-01-31",
                     "2025-04-07", "2025-04-30", "2025-05-01", "2025-05-02", "2025-09-01", "2025-09-02"]
    holidays_2026 = ["2026-01-01", "2026-01-02", "2026-02-16", "2026-02-17", "2026-02-18", "2026-02-19",
                     "2026-02-20", "2026-04-27", "2026-04-30", "2026-05-01", "2026-08-31", "2026-09-01", "2026-09-02"]
    ranges = []
    for start, end, holidays, source_id in [
        ("2025-01-01", "2025-12-31", holidays_2025, "hose_2025"),
        ("2026-01-01", "2026-09-30", holidays_2026, "hose_2026_news"),
        ("2026-07-01", "2026-09-23", holidays_2026, "hose_2026_news"),
    ]:
        expected = weekdays(start, end, holidays)
        actual = [d for d in observed if start <= d <= end]
        missing, extra = sorted(set(expected)-set(actual)), sorted(set(actual)-set(expected))
        assert not missing and not extra
        ranges.append({"start": start, "end": end, "source_id": source_id,
                       "expected_sessions": len(expected), "observed_sessions": len(actual),
                       "missing": missing, "extra": extra,
                       "status": "MATCHES_PUBLISHED_HOLIDAY_SCHEDULE",
                       "all_unscheduled_closures_independently_checked": False})
    news = json.loads((SOURCE / "hose_2026_news.json").read_bytes())
    assert news["success"] is True and news["data"]["id"] == 2437411
    posted = datetime.fromtimestamp(news["data"]["postedDate"], timezone.utc).isoformat()
    assert posted < "2026-07-01"
    parents = [bind(p) for p in (
        audit_path, calendar_path, "docs/plan/week12/finalize_price_checks.zip",
        "docs/plan/week12/finalize_inventory.json", "docs/plan/week12/finalize_comparison_contract.json",
        "docs/plan/week12/finalize_alpha_checks.zip",
    )]
    payload = {
        "version": "finalize_price_primary_corroboration_v1",
        "status": "PARTIAL_PRIMARY_CORROBORATION_SOURCE_GATE_BLOCKED",
        "FIN04_complete": False, "price_source_gate": "BLOCKED_PIT_PROVENANCE",
        "planned_points": 102, "admitted_points": 0,
        "sources": records, "parents": parents, "event_corroborations": corroborated,
        "calendar_comparisons": ranges,
        "calendar_publication": {
            "hose_2025_document_number": "2079/TB-SGDHCM", "hose_2025_signed_date": "2024-12-26",
            "hose_2026_newyear_document_number": "2410/TB-SGDHCM", "hose_2026_newyear_signed_date": "2025-12-25",
            "hose_2026_news_posted_at_utc": posted,
            "hose_2026_page_url": "https://www.hsx.vn/vi/tin-tuc/hose-thong-bao-lich-nghi-giao-dich-nam-2026/2437411",
            "newyear_dates_absent_from_frozen_calendar": all(d not in observed for d in ("2026-01-01", "2026-01-02", "2026-01-10")),
            "pdf_page_1_visually_reviewed": ["hose_2025", "hose_2026_newyear"],
            "full_2018_2026_independent_calendar_certified": False,
            "chronology_limit": "Bài HOSE 2026 công bố 29/04/2026 chỉ được dùng như thông báo có trước các cutoff sau ngày này; không gán lịch bài hiện tại cho cutoff tháng 1–4.",
        },
        "provider_document_scope": "Bài Vnstock hiện tại phân biệt adjusted OHLCV và raw trade history; ví dụ API hiện tại không phải hợp đồng của nguồn/vnstock 4.0.9 đã đóng băng. Không tìm được cam kết bất biến hồi tố hoặc lịch sử phiên bản giá từ tài liệu này.",
        "remaining_blockers": [
            "PRICE_VERSION_AS_PUBLISHED_AND_AVAILABILITY_NOT_AUTHENTICATED",
            "FULL_STUDY_CALENDAR_AND_UNSCHEDULED_CLOSURES_NOT_AUTHENTICATED",
            "EVENT_LEDGER_COMPLETENESS_AND_HISTORICAL_CONTENT_NOT_AUTHENTICATED",
            "RIGHTS_CROSSING_PROTOCOL_REQUIRES_PRE_OUTPUT_AMENDMENT",
            "RAW_SOURCE_REPLACEMENT_REQUIRES_VERSION_AND_RESOURCE_REBUILD",
        ],
        "method": "Nguồn chính thức được tải qua HTTPS; hash và HTTP Date chỉ xác minh bản thu hôm nay. Timestamp hiển thị nhà xuất bản và ngày ký được ghi riêng, không là chứng cứ snapshot bất biến tại cutoff. Danh sách nghỉ được chép từ trang/bảng HOSE rồi so lịch ngày trong CSV; không đọc quote tương lai hoặc tính lợi nhuận query.",
        "dataset_replaced": False, "contract_amended": False, "runtime_changed": False,
        "query_outcomes_computed": False, "training": False, "llm_calls": 0, "market_quote_api_calls": 0,
        "public_document_gets_included": len(records),
    }
    members = {item["path"]: (SOURCE / item["path"]).read_bytes() for item in records}
    members["report.json"] = encoded({"payload": payload, "sha256": sha(encoded(payload))})
    members["collect_sources.py"] = (ROOT / "tmp/collect_fin04_primary.py").read_bytes()
    members["build_evidence.py"] = Path(__file__).read_bytes()
    members["verify_package.py"] = (ROOT / "tmp/verify_fin04_primary.py").read_bytes()
    manifest = {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in members.items()}
    members["manifest.json"] = encoded(manifest)
    if OUTPUT.exists():
        raise ValueError("Không ghi đè gói bằng chứng; cần version mới")
    with zipfile.ZipFile(OUTPUT, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(members.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, raw)
    print(json.dumps({"archive": str(OUTPUT.relative_to(ROOT)), "bytes": OUTPUT.stat().st_size,
                      "sha256": sha(OUTPUT.read_bytes()), "members": len(members),
                      "events": len(corroborated), "calendars": ranges}, ensure_ascii=False))
