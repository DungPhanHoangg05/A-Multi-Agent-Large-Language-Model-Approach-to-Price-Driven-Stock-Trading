"""Chuẩn hóa newline ngoài JSON fixture; kiểm dữ liệu giữ nguyên, không chạy lại runtime."""
import json
from pathlib import Path
import sys
import zipfile
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from scripts.serving_acceptance import reports as gate
from scripts.serving_acceptance.evidence import binding,runtime
with zipfile.ZipFile(gate.PACKAGE) as archive:
    members={name:archive.read(name) for name in archive.namelist() if name!='manifest.json'}
checks=json.loads(members['checks.json']); receipt=json.loads(gate.RECEIPT.read_bytes())
name='tests/analysis_ui/locale_regression.json'; path=ROOT/name; before=path.read_bytes()
assert binding(before)==checks['sources'][name]
after=before.replace(b'\r\n',b'\n')
assert json.loads(before)==json.loads(after)
path.write_bytes(after)
sealed=gate.sources()
assert {name for name in set(sealed)|set(checks['sources']) if sealed.get(name)!=checks['sources'].get(name)}=={'tests/analysis_ui/locale_regression.json'}
assert runtime(ROOT)==checks['runtime'] and gate.historical()==checks['historical']
members['pre_newline_checks.json']=members['checks.json']; members['fixture_before_newline.json']=before
checks['sources']=sealed
checks['fixture_newline_delta']={'file':name,'only_outer_json_crlf_to_lf':True,'json_values_unchanged':True,'tests_rerun':False}
members['checks.json']=(json.dumps(checks,ensure_ascii=False,indent=2)+'\n').encode()
members['normalize_fixture.py']=Path(__file__).read_bytes()
members['manifest.json']=(json.dumps({name:binding(raw) for name,raw in members.items()},indent=2)+'\n').encode()
with zipfile.ZipFile(gate.PACKAGE,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in members.items(): archive.writestr(name,raw)
receipt['checks_package']={'path':gate.PACKAGE.relative_to(ROOT).as_posix(),**binding(gate.PACKAGE.read_bytes())}
receipt['fixture_newline_delta']=checks['fixture_newline_delta']
gate.RECEIPT.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(gate.verify()))
