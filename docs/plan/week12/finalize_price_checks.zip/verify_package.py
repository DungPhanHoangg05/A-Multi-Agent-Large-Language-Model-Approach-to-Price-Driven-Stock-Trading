"""Đối soát gói QA FIN04, giữ source gate chặn; không chạy API hoặc test."""
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys
import zipfile

archive,root=Path(sys.argv[1]),Path(sys.argv[2])
def sha(raw):return hashlib.sha256(raw).hexdigest()
with zipfile.ZipFile(archive) as z:
    d=json.loads(z.read("manifest.json"));p=d["payload"]
    raw=json.dumps(p,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode()
    assert sha(raw)==d["sha256"]
    for name,pin in p["members"].items():
        raw=z.read(name);assert len(raw)==pin["bytes"] and sha(raw)==pin["sha256"],name
    audit=json.loads(z.read("audit.json"))["payload"]
    for pin in [*p["source_bindings"].values(),*p["parents"],*audit["source_bindings"].values()]:
        raw=(root/pin["path"]).read_bytes()
        assert len(raw)==pin["bytes"] and sha(raw)==pin["sha256"],pin["path"]
    assert platform.python_version()==p["runtime"]["python"]
    assert all(version(n)==v for n,v in p["runtime"]["packages"].items())
    assert sum(r["tests"] for r in p["suites"].values())==35
    assert audit["planned_points"]==102 and audit["admitted_points"]==0
    assert audit["price_source_gate"]=="BLOCKED_PIT_PROVENANCE" and not p["FIN04_complete"]
    print("PASS: gói/source/runtime FIN04; source gate vẫn chặn, không chạy lại test/API")
