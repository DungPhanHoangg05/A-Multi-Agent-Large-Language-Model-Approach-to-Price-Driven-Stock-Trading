﻿from pathlib import Path
import json,zipfile,shutil,tempfile,subprocess,os,sys
root=Path.cwd()
package=root/'docs/plan/week12/unified_live_smoke.zip'
with zipfile.ZipFile(root/'docs/plan/week12/unified_execution_checks.zip') as z:
 sources=json.loads(z.read('source_bindings.json'))
runtime=json.loads((root/'docs/plan/week12/unified_live_runtime.json').read_bytes())['payload']
sources.update(runtime['sources'])
cold=Path(tempfile.mkdtemp(prefix='u08-smoke-cold-'))
for name in sources:
 target=(cold/name).resolve();assert target.is_relative_to(cold.resolve())
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
with zipfile.ZipFile(package) as z:
 manifest=json.loads(z.read('manifest.json'))
 import hashlib
 for name,entry in manifest['members'].items():
  raw=z.read(name);assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
  target=(cold/name).resolve();assert target.is_relative_to(cold.resolve())
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
shutil.copyfile(root/'docs/plan/week12/unified_live_checks.zip',cold/'docs/plan/week12/unified_live_checks.zip')
shutil.copyfile(root/'docs/plan/week12/unified_execution_checks.zip',cold/'docs/plan/week12/unified_execution_checks.zip')
env=os.environ.copy();env['GIT_DIR']=subprocess.check_output(['git','rev-parse','--absolute-git-dir'],text=True).strip();env['GIT_WORK_TREE']=str(cold)
restored=subprocess.run(['py','-3.13','-I','-X','utf8','scripts/prepare_unified_comparison_v2.py','restore'],cwd=cold,env=env,capture_output=True,text=True,encoding='utf8')
assert restored.returncode==0,restored.stderr
code='''import sys,runpy
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path.cwd()))
sys.argv=['scripts/unified_live/run.py','verify','--phase','SMOKE']
with patch('httpx.Client',side_effect=AssertionError('Cấm client')), patch('httpx.AsyncClient',side_effect=AssertionError('Cấm client')), patch('httpx.HTTPTransport',side_effect=AssertionError('Cấm transport')), patch('langchain_groq.ChatGroq',side_effect=AssertionError('Cấm SDK')), patch('dotenv.dotenv_values',side_effect=AssertionError('Cấm key')), patch('core.unified_execution_providers.StudyProviders',side_effect=AssertionError('Cấm provider')):
 runpy.run_path('scripts/unified_live/run.py',run_name='__main__')
'''
result=subprocess.run(['py','-3.13','-I','-X','utf8','-c',code],cwd=cold,env=env,capture_output=True,text=True,encoding='utf8')
p=Path(tempfile.gettempdir());(p/'u08_smoke_cold_verify.log').write_text(result.stdout+result.stderr,encoding='utf8');(p/'u08_smoke_cold_root.txt').write_text(str(cold),encoding='utf8')
print(json.dumps({'cold':str(cold),'sources':len(sources),'exit':result.returncode}))
print((result.stdout+result.stderr)[-3000:])
assert result.returncode==0
