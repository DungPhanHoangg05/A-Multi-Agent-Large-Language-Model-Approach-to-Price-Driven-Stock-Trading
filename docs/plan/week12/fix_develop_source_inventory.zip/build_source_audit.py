"""Lập inventory chỉ đọc từ hai commit đã khóa; không import mã nghiên cứu."""
from __future__ import annotations

import ast
from collections import Counter
import hashlib
from importlib.metadata import distributions
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import zipfile

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
FIX = '9efd23f4157e0d3ab8069fccab7dccf03439a714'
DEV = '3eb3c765946e7fd393abf54d91b3f204d86ee981'
OLD = '21f7ee6700ec478ba3e226d54cce2ef261901c62'
REMOTE = 'aaf855d3cf908e5735ddf097b150e9767a3e4cb1'


def git(*args: str) -> bytes:
    """Đọc Git bằng argv, không qua shell."""
    return subprocess.check_output(['git', *args], cwd=ROOT)


def encoded(value: object) -> bytes:
    """Giữ JSON UTF-8/LF ổn định để đối soát."""
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def sha(raw: bytes) -> str:
    """Băm đúng byte đầu vào."""
    return hashlib.sha256(raw).hexdigest()


def tree(commit: str) -> dict:
    """Liệt kê cả mode, loại object và kích thước từng đường dẫn."""
    result = {}
    for row in git('ls-tree', '-r', '-l', '-z', commit).split(b'\0'):
        if row:
            meta, path = row.split(b'\t', 1)
            mode, kind, oid, size = meta.decode().split()
            result[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid,
                                    'bytes': int(size) if size != '-' else None}
    return result


def category(path: str) -> str:
    """Phân loại vai trò lưu trữ, không suy rằng file đã được thực thi."""
    if path.startswith('outputs/'):
        return 'frozen_evidence'
    if path.startswith('paper/'):
        return 'manuscript_source' if Path(path).suffix in ('.tex', '.bib', '.cls', '.sty') else 'manuscript_asset_or_generated'
    if path.startswith('revision/'):
        return 'revision_documentation_or_evidence'
    if path.startswith('tests/'):
        return 'test_or_fixture'
    if path.startswith('docs/'):
        return 'protocol_schema_receipt' if Path(path).suffix in ('.json', '.zip') else 'documentation'
    if path.startswith('scripts/'):
        return 'cli_or_offline_consumer'
    if path.startswith(('data/', 'data_manager/')) and not path.endswith('.py'):
        return 'data_or_model_asset'
    if path.endswith('.py'):
        return 'runtime_source'
    if path.startswith('templates/'):
        return 'ui_template'
    return 'configuration_license_or_other'


trees = {'fix_frozen': tree(FIX), 'develop': tree(DEV)}
oids = {r['oid'] for rows in trees.values() for r in rows.values() if r['kind'] == 'blob'}
text_suffixes = {'.py', '.json', '.html', '.js', '.yaml', '.yml', '.md', '.txt', '.tex', '.bib'}
retain = {r['oid'] for rows in trees.values() for p, r in rows.items()
          if p.endswith('.py') or (not p.startswith('outputs/') and
             (Path(p).suffix in text_suffixes or Path(p).name in ('.gitignore', '.gitattributes', 'Dockerfile')))}
blobs, bodies = {}, {}
proc = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
for oid in sorted(oids):
    proc.stdin.write((oid + '\n').encode())
    proc.stdin.flush()
    header = proc.stdout.readline().decode().split()
    assert header[:2] == [oid, 'blob']
    raw = proc.stdout.read(int(header[2]))
    assert proc.stdout.read(1) == b'\n'
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid
    blobs[oid] = {'sha256': sha(raw), 'bytes': len(raw)}
    if oid in retain:
        bodies[oid] = raw
proc.stdin.close()
assert proc.wait() == 0

inventory = []
for path in sorted(set().union(*trees.values())):
    versions = {name: {**rows[path], **blobs.get(rows[path]['oid'], {})}
                for name, rows in trees.items() if path in rows}
    relation = ('identical' if versions['fix_frozen'] == versions['develop'] else 'different') if len(versions) == 2 else next(iter(versions)) + '_only'
    inventory.append({'path': path, 'category': category(path), 'relation': relation,
                      'ownership': ('preserve_fix_evidence' if category(path) in ('frozen_evidence', 'manuscript_source', 'manuscript_asset_or_generated', 'revision_documentation_or_evidence') and path in trees['fix_frozen']
                                    else 'review_both_callers' if relation == 'different'
                                    else 'retain_develop_extension' if relation == 'develop_only'
                                    else 'port_fix_contract_or_consumer' if relation == 'fix_frozen_only'
                                    else 'shared'), 'versions': versions})

imports, calls, definitions, hardcodes, parse_errors = [], [], [], [], []
path_pattern = re.compile(r'(?:outputs|docs/plan|data_manager|data|paper|revision|tests|agents|core|utils|scripts|models)[/\\][^\s\"\'<>|;]+')
pin_pattern = re.compile(r'(?<![0-9a-f])[0-9a-f]{40}(?![0-9a-f])')


def dotted(node: ast.AST) -> str:
    """Giữ biểu thức gọi tĩnh; không đoán loại của self hoặc factory."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return dotted(node.value) + '.' + node.attr
    return '<dynamic>'


for snapshot, rows in trees.items():
    modules = {p[:-3].replace('/', '.'): p for p in rows if p.endswith('.py')}
    modules.update({p[:-12].replace('/', '.'): p for p in rows if p.endswith('/__init__.py')})
    for path, record in sorted(rows.items()):
        if not path.endswith('.py'):
            if record['oid'] in bodies:
                try:
                    text = bodies[record['oid']].decode('utf-8-sig')
                except UnicodeError:
                    continue
                for number, line in enumerate(text.splitlines(), 1):
                    paths, pins = path_pattern.findall(line), pin_pattern.findall(line)
                    if paths or pins:
                        hardcodes.append({'snapshot': snapshot, 'path': path, 'line': number,
                                          'path_candidates': paths, 'commit_candidates': pins,
                                          'dynamic_or_environment': False})
            continue
        raw = bodies[record['oid']]
        try:
            text = raw.decode('utf-8-sig')
            node = ast.parse(text, filename=path)
        except (UnicodeError, SyntaxError) as exc:
            parse_errors.append({'snapshot': snapshot, 'path': path, 'error': str(exc)})
            continue
        aliases = {}
        for item in ast.walk(node):
            if isinstance(item, (ast.Import, ast.ImportFrom)):
                for alias in item.names:
                    base = item.module or '' if isinstance(item, ast.ImportFrom) else alias.name
                    if isinstance(item, ast.ImportFrom) and item.level:
                        parents = path[:-3].replace('/', '.').split('.')[:-item.level]
                        base = '.'.join([*parents, *([base] if base else [])])
                    full = base + '.' + alias.name if isinstance(item, ast.ImportFrom) else base
                    target = modules.get(full) or modules.get(base)
                    local = alias.asname or (alias.name if isinstance(item, ast.ImportFrom) else alias.name.split('.')[0])
                    aliases[local] = full if isinstance(item, ast.ImportFrom) or alias.asname else local
                    imports.append({'snapshot': snapshot, 'path': path, 'line': item.lineno,
                                    'module': base, 'symbol': alias.name, 'local_name': local,
                                    'target_path': target, 'kind': 'local' if target else 'external_or_unresolved'})
        class Visitor(ast.NodeVisitor):
            """Gắn caller với scope, kể cả hàm lồng nhau."""
            scope: list[str]

            def __init__(self) -> None:
                self.scope = []

            def visit_FunctionDef(self, item: ast.FunctionDef) -> None:
                self.scope.append(item.name)
                definitions.append({'snapshot': snapshot, 'path': path, 'line': item.lineno,
                                    'symbol': '.'.join(self.scope), 'kind': type(item).__name__})
                self.generic_visit(item)
                self.scope.pop()

            visit_AsyncFunctionDef = visit_FunctionDef
            visit_ClassDef = visit_FunctionDef

            def visit_Call(self, item: ast.Call) -> None:
                name = dotted(item.func)
                head, dot, tail = name.partition('.')
                qualified = aliases.get(head, head) + (dot + tail if dot else '')
                calls.append({'snapshot': snapshot, 'path': path, 'line': item.lineno,
                              'caller': '.'.join(self.scope) or '<module>', 'callee': name,
                              'qualified_candidate': qualified,
                              'resolution': 'import_alias_candidate' if head in aliases else 'lexical_only'})
                self.generic_visit(item)
        Visitor().visit(node)
        for number, line in enumerate(text.splitlines(), 1):
            paths, pins = path_pattern.findall(line), pin_pattern.findall(line)
            dynamic = any(token in line for token in ('git", "show', "git', 'show", '__import__(', 'import_module(', 'exec(', 'compile(', 'load_dotenv(', '.env', 'getenv('))
            if paths or pins or dynamic:
                hardcodes.append({'snapshot': snapshot, 'path': path, 'line': number,
                                  'path_candidates': paths, 'commit_candidates': pins,
                                  'dynamic_or_environment': dynamic})

local_cache = {}


def local_binding(path: str) -> dict:
    """Đối soát file local an toàn; không đọc credential hoặc ra ngoài repo."""
    if path in local_cache:
        return local_cache[path]
    candidate = ROOT / path
    if candidate.is_symlink() or not candidate.resolve().is_relative_to(ROOT) or any(part.startswith('.env') for part in candidate.parts):
        result = {'status': 'excluded_unsafe_or_credential'}
    elif not candidate.is_file():
        result = {'status': 'not_materialized'}
    else:
        digest = hashlib.sha256()
        with candidate.open('rb') as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk)
        result = {'status': 'materialized', 'bytes': candidate.stat().st_size, 'sha256': digest.hexdigest()}
    local_cache[path] = result
    return result


def bindings(value: object, source: str, pointer: str = '') -> list:
    """Chỉ coi bộ ba path/bytes/sha256 là binding; không đổi receipt cũ."""
    found = []
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str) and type(value.get('bytes')) is int:
            actual = local_binding(value['path'])
            found.append({'receipt': source, 'pointer': pointer, 'expected': {k: value[k] for k in ('path', 'bytes', 'sha256')},
                          'actual': actual, 'match': all(actual.get(k) == value[k] for k in ('bytes', 'sha256'))})
        for key, item in value.items():
            found.extend(bindings(item, source, pointer + '/' + str(key)))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            found.extend(bindings(item, source, pointer + '/' + str(index)))
    return found


receipt_checks = []
for path, row in sorted(trees['develop'].items()):
    if path.startswith('docs/plan/') and path.endswith('.json'):
        receipt_checks.extend(bindings(json.loads(bodies[row['oid']]), path))

mismatch_provenance = []
for path in sorted({r['expected']['path'] for r in receipt_checks if not r['match']}):
    expected_hashes = {r['expected']['sha256'] for r in receipt_checks if not r['match'] and r['expected']['path'] == path}
    historical = []
    for commit in git('log', '-20', '--format=%H', DEV, '--', path).decode().splitlines():
        raw = git('show', commit + ':' + path)
        if sha(raw) in expected_hashes:
            historical.append({'commit': commit, 'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
    mismatch_provenance.append({'path': path, 'expected_git_snapshots': historical,
                               'current_change_commit': git('log', '-1', '--format=%H', DEV, '--', path).decode().strip()})

archive_path = 'outputs/historical_reevaluation/free_pilot_r1/handoff/pilot48_evidence.zip'
archive_check = {'path': archive_path, 'actual': local_binding(archive_path)}
with zipfile.ZipFile(ROOT / archive_path) as archive:
    manifest_raw = archive.read('handoff_manifest.json')
    manifest = json.loads(manifest_raw)
    archive_check.update(manifest_sha256=sha(manifest_raw), members=[])
    for name, expected in sorted(manifest['files'].items()):
        raw = archive.read(name)
        assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], name
        archive_check['members'].append({'path': name, **expected})

asset_path = 'outputs/historical_reevaluation/manifests/asset_readiness.json'
donor_checks = []
for row in json.loads((ROOT / asset_path).read_bytes())['source_archive']:
    actual = local_binding(row['archive_path'])
    source = trees['fix_frozen'][row['source_path']]
    donor_checks.append({'source_path': row['source_path'], 'archive_path': row['archive_path'],
                         'git_blob': source, 'actual': actual,
                         'match': actual.get('sha256') == row['sha256'] == blobs[source['oid']]['sha256']})

summary = {
    'version': 'fix_develop_source_audit_v1', 'date': '2026-11-09',
    'scope': 'U01_STATIC_SOURCE_AND_EVIDENCE_AUDIT_NO_RUNTIME_ACCEPTANCE',
    'sources': {'fix_frozen': FIX, 'develop': DEV, 'previous_develop': OLD, 'origin_develop': REMOTE,
                'merge_base': git('merge-base', FIX, DEV).decode().strip()},
    'trees': {name: git('rev-parse', commit + '^{tree}').decode().strip() for name, commit in [('fix_frozen', FIX), ('develop', DEV)]},
    'delta_from_plan': git('diff', '--name-status', OLD, DEV).decode().splitlines(),
    'divergence_fix_develop': git('rev-list', '--left-right', '--count', FIX + '...' + DEV).decode().strip(),
    'divergence_remote_develop': git('rev-list', '--left-right', '--count', REMOTE + '...' + DEV).decode().strip(),
    'file_counts': {name: len(rows) for name, rows in trees.items()},
    'relations': dict(Counter(row['relation'] for row in inventory)),
    'categories': dict(Counter(row['category'] for row in inventory)),
    'unique_blobs': len(blobs), 'union_paths': len(inventory),
    'ast': {'python_files': {name: sum(p.endswith('.py') for p in rows) for name, rows in trees.items()},
            'parse_errors': parse_errors, 'imports': len(imports), 'calls': len(calls), 'definitions': len(definitions),
            'hardcode_rows': len(hardcodes)},
    'receipt_binding_checks': dict(Counter('match' if r['match'] else 'hash_or_size_mismatch' if r['actual']['status'] == 'materialized' else r['actual']['status'] for r in receipt_checks)),
    'mismatch_provenance': mismatch_provenance,
    'h08_h09': {name: {'bindings': len(selected), 'matches': sum(r['match'] for r in selected)}
                for name in ('free_pilot_h08_analysis.json', 'free_pilot_h09_handoff.json')
                for selected in [[r for r in receipt_checks if r['receipt'].endswith('/' + name)]]},
    'donor_source_checks': {'files': len(donor_checks), 'matches': sum(r['match'] for r in donor_checks)},
    'handoff_archive': {k: v for k, v in archive_check.items() if k != 'members'},
    'handoff_members_verified': len(archive_check['members']),
    'runtime_observed': {'python': platform.python_version(), 'packages': dict(sorted((d.metadata['Name'], d.version) for d in distributions() if d.metadata['Name']))},
    'limitations': ['STATIC_CANDIDATES_NOT_EXECUTION_TRACE', 'NO_HOSTED_CALL_OR_TRAINING', 'NO_NEW_RUNTIME_GATE',
                    'GIT_BLOB_HASHES_DISTINCT_FROM_CHECKOUT_BYTES', 'NO_CAUSAL_OR_ZERO_LEAKAGE_CERTIFICATION',
                    'LOCAL_BINDINGS_MAY_REFER_TO_OLD_SNAPSHOTS_OR_CANCELLED_OUTPUTS',
                    'PATH_SCAN_STATIC_TEXT_CANDIDATES; JSON_BINDINGS_EXPLICIT_PATH_BYTES_SHA256_ONLY',
                    'DYNAMIC_DISPATCH_AND_FACTORY_RETURNS_REQUIRE_U02_U03_REVIEW']}

members = {'inventory.json': encoded(inventory), 'imports.json': encoded(imports), 'calls.json': encoded(calls),
           'definitions.json': encoded(definitions), 'hardcodes.json': encoded(hardcodes),
           'receipt_bindings.json': encoded(receipt_checks), 'donor_sources.json': encoded(donor_checks),
           'handoff_members.json': encoded(archive_check), 'summary.json': encoded(summary),
           'build_source_audit.py': Path(__file__).read_bytes()}
members['manifest.json'] = encoded({'version': 'audit_bundle_v1', 'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in members.items()}})
with zipfile.ZipFile(OUT, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, raw, compresslevel=9)
print(json.dumps({k: v for k, v in summary.items() if k != 'runtime_observed'}, ensure_ascii=False, indent=2))
print(json.dumps({'archive_bytes': OUT.stat().st_size, 'archive_sha256': sha(OUT.read_bytes())}))
