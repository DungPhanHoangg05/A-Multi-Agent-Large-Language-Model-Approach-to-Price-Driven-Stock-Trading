"""Đối soát F07 với nguồn/gói đã khóa, không sửa receipt hoặc replay study."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT/'docs/plan/week12'


def binding(raw):
    """Hash trên byte thực."""
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


with zipfile.ZipFile(DOC/'unified_analysis_results.zip') as archive:
    pins = {name: {key: row[key] for key in ('bytes', 'sha256')}
            for name, row in json.loads(archive.read('manifest.json'))['sources'].items()}
with zipfile.ZipFile(DOC/'final_evidence_snapshot.zip') as archive:
    snapshot = json.loads(archive.read('snapshot_manifest.json'))
    assert len(pins) == 729
    for name, expected in pins.items():
        assert binding(archive.read(name)) == expected, name
    changed = sorted(name for name, expected in pins.items() if binding((ROOT/name).read_bytes()) != expected)
    assert changed == ['templates/experiments.html', 'utils/experiment_web.py', 'web_interface.py'], changed
    for group in ('frozen_packages', 'legacy_archives'):
        for name, expected in snapshot[group].items():
            assert binding((ROOT/name).read_bytes()) == expected, name
release = ROOT/'outputs/revision/manuscript_unified_final_v1'
manifest = json.loads((release/'manifest.json').read_bytes())
assert binding((release/'manifest.json').read_bytes()) == {'bytes': 55249, 'sha256': '8e5ce2a4ca6f3a52945047cb8e1e1e99e8c00dfcd959a6fc6cdadcd701013de9'}
for name, expected in manifest['outputs'].items():
    assert binding((release/name).read_bytes()) == expected, name
for name, expected in manifest['sources'].items():
    assert binding((ROOT/name).read_bytes()) == expected, name
for name in ('core/variant_registry.py', 'core/unified_contracts.py', 'core/unified_methods.py', 'core/unified_experiment.py',
             'core/backtest_engine.py', 'utils/experiment_io.py', 'templates/demo_new.html', 'templates/output.html', 'templates/backtest.html'):
    assert subprocess.check_output(['git', 'diff', '--exit-code', 'a5e30ab0', '--', name], cwd=ROOT) == b'', name
result = {'status': 'PASS_F07_INTEGRITY', 'base_commit': 'a5e30ab0', 'source_pins': 729,
          'current_source_matches': 726, 'historical_snapshot_restores': 729, 'intentional_changed_pins': changed,
          'frozen_packages_unchanged': len(snapshot['frozen_packages']), 'legacy_archives_unchanged': len(snapshot['legacy_archives']),
          'f05_outputs_unchanged': len(manifest['outputs'])+1, 'f05_sources_unchanged': len(manifest['sources']),
          'new_api_calls': 0, 'training': 0}
(ROOT/'tmp/f07/integrity.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
