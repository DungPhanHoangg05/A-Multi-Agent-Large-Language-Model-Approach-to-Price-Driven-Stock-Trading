"""Chạy suite đúng phạm vi, lưu log UTF-8 và kết quả machine-readable."""
from pathlib import Path
import json
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
results = {}
for pattern in ('test_research_results_viewer.py', 'test_variant_serving.py', 'test_unified_experiment.py', 'test_web_json_serialization.py'):
    suite = unittest.defaultTestLoader.discover(str(ROOT/'tests'), pattern=pattern)
    with (ROOT/'tmp/f07'/pattern.replace('.py', '.log')).open('w', encoding='utf-8') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    results[pattern] = {'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped)}
    print(pattern, results[pattern], flush=True)
    if not result.wasSuccessful():
        sys.exit(1)
(ROOT/'tmp/f07/test_results.json').write_text(json.dumps(results, indent=2)+'\n', encoding='utf-8')
