"""Lưu stderr của subprocess lỗi để chẩn đoán hồi quy CLI, không sửa thuật toán."""
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT/'tests')]
original = subprocess.run


def diagnostic(*args, **kwargs):
    """Chỉ bổ sung log khi lệnh check=True thất bại."""
    try:
        return original(*args, **kwargs)
    except subprocess.CalledProcessError as error:
        print('CLI STDERR:', (error.stderr or b'').decode('utf-8', errors='replace'), file=sys.stderr)
        raise


subprocess.run = diagnostic
suite = unittest.defaultTestLoader.loadTestsFromName('test_unified_experiment.UnifiedExperimentTests.test_cli_replay_verify_and_csv_use_identical_records_and_refuse_wrong_hash')
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
