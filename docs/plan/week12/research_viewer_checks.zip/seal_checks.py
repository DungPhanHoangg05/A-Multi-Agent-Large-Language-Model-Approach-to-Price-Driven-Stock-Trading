"""Đóng gói bằng chứng QA đúng phạm vi, ghi rõ chưa kiểm browser trực quan."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import unicodedata
import zipfile

ROOT = Path(__file__).resolve().parents[2]
QA = ROOT/'tmp/f07'
TARGET = ROOT/'docs/plan/week12/research_viewer_checks.zip'


def binding(raw):
    """Đối soát byte không chuẩn hóa."""
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def slug(text):
    """Anchor Unicode dùng trong docs hiện hành."""
    text = re.sub('<[^>]+>', '', text).lower().replace(' ', '-')
    return ''.join(c for c in text if c in '-_' or unicodedata.category(c)[0] in 'LN')


results = json.loads((QA/'test_results.json').read_bytes())
assert sum(r['tests'] for r in results.values()) == 46
assert not any(r[key] for r in results.values() for key in ('errors', 'failures', 'skips'))
TARGET.touch(exist_ok=True)
documents = ('docs/plan/plan.md', 'docs/plan/week12/README.md', 'docs/plan/week12/final_paper_ui_plan.md',
             'docs/plan/week12/variant_serving_contract.md')
links = 0
for name in documents:
    path = ROOT/name
    for target in re.findall(r'(?<!!)\[[^]\n]*\]\(([^)\n]+)\)', path.read_text(encoding='utf-8')):
        if '://' in target or target.startswith('mailto:'):
            continue
        rel, _, anchor = target.partition('#')
        destination = (path.parent/rel).resolve() if rel else path
        assert destination.exists(), (name, target)
        if anchor:
            assert anchor in [slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$', destination.read_text(encoding='utf-8'), re.M)], (name, target)
        links += 1
readme = (ROOT/documents[1]).read_text(encoding='utf-8')
plan = (ROOT/documents[2]).read_text(encoding='utf-8')
assert '- [x] F07' in readme and '| F07 | ☑ Hoàn tất |' in plan
for task in range(8, 13):
    name = f'F{task:02}'
    assert '- [ ] '+name in readme and '| '+name+' | ☐ Chưa bắt đầu |' in plan
sources = ['core/research_results.py', 'core/serving_registry.py', 'utils/research_view.py', 'utils/research_web.py',
           'utils/research_i18n.py', 'utils/experiment_web.py', 'web_interface.py', 'tests/test_research_results_viewer.py',
           'tests/test_variant_serving.py', 'tests/js/research_viewer.test.mjs', 'templates/experiments.html',
           'static/css/experiments.css']
sources += [p.relative_to(ROOT).as_posix() for folder in ('templates/experiments', 'static/js/experiments') for p in sorted((ROOT/folder).glob('*'))]
checks = {'status': 'PASS_F07_FUNCTIONAL_OFFLINE', 'base_commit': 'a5e30ab0', 'python_suites': results,
          'python_tests_passed': 46, 'node_tests_passed': 6, 'node_command': 'node --test tests/js/research_viewer.test.mjs',
          'node_result_tool_chunk': '1bc2d4', 'compiled_python_files': sources[:9], 'javascript_syntax_files': sources[-4:],
          'source_bindings': {name: binding((ROOT/name).read_bytes()) for name in sources},
          'runtime': subprocess.check_output(['py', '-3.13', '--version']).decode().strip(),
          'node_runtime': subprocess.check_output(['node', '--version']).decode().strip(),
          'local_links': links, 'checklist_synchronized': True,
          'browser_visual': 'NOT_RUN', 'browser_access_host': 'UNAVAILABLE',
          'browser_ui_review': 'REJECTED: Computer Use was not approved to use Microsoft Edge',
          'browser_gate_remains': 'F11 desktop/mobile/interaction visual QA',
          'http_smoke': 'LOCAL 200: U09, EN HTML, JS text/javascript; NO VISUAL CLAIM',
          'initial_cli_guard': 'Initial export exit2 while runtime sources were edited; first stderr not captured. Stable-source diagnostic and final suite PASS. No guard/pin change.',
          'new_api_calls': 0, 'training': 0}
members = {'checks.json': (json.dumps(checks, ensure_ascii=False, indent=2)+'\n').encode()}
for name in ('test_results.json', 'integrity.json', 'test_research_results_viewer.log', 'test_variant_serving.log',
             'test_unified_experiment.log', 'test_web_json_serialization.log', 'initial_source_guard_failure.log',
             'check_integrity.py', 'run_checks.py', 'seal_checks.py', 'diagnose_cli.py'):
    members[name] = (QA/name).read_bytes()
members['manifest.json'] = (json.dumps({name: binding(raw) for name, raw in members.items()}, indent=2)+'\n').encode()
with zipfile.ZipFile(TARGET, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in members.items():
        archive.writestr(name, raw)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    for name, raw in members.items():
        assert archive.read(name) == raw
print(json.dumps({'status': checks['status'], 'python': 46, 'node': 6, 'links': links,
                  'members': len(members), 'package': binding(TARGET.read_bytes())}))
