"""Chuẩn bị companions nguyên byte, visual proof và ranh giới bàn giao nội bộ F05."""
from pathlib import Path
import csv
import hashlib
import io
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/'tmp/f05'


def bind(raw: bytes) -> dict:
    """Khóa byte artifact đã tồn tại, không tính lại số liệu."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def encoded(value: object) -> bytes:
    """Ghi metadata UTF-8 xác định."""
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')


f04=ROOT/'docs/plan/week12/manuscript_figures_checks.zip'
with zipfile.ZipFile(f04) as archive:
    prior=json.loads(archive.read('visual_review.json'))
    pages={}
    direct=[]
    for path in sorted((WORK/'rendered').rglob('page-*.png')):
        name=path.relative_to(WORK/'rendered').as_posix()
        checksum=bind(path.read_bytes())['sha256']
        same=checksum==prior['pages'][name]['sha256']
        if not same:direct.append(name)
        pages[name]={'sha256':checksum,'review':'byte_identical_to_F04_visually_reviewed_page' if same else 'direct_final_page_visual_inspection'}
    assert direct==['main/page-35.png','main_submit/page-35.png'],direct
    assert len(pages)==101
visual={'status':'PASS_ALL_101_FINAL_PAGES_VISUALLY_REVIEWED','pages':pages,
    'prior_qa':{'path':f04.relative_to(ROOT).as_posix(),**bind(f04.read_bytes())},
    'new_rendered_pages':101,'byte_identical_to_prior_visual_review':99,'directly_inspected_changed_pages':direct,
    'checks':['Both changed availability pages inspected directly; no clipping, overlap or missing glyphs',
        'All 99 other pages match exact previously reviewed PNG bytes',
        'Seven figures, 21 tables, one algorithm per PDF; 38 TikZ nodes per PDF pass geometry checks',
        'Eight benign Underfull spacing notices per PDF; no Overfull/undefined reference/citation warnings',
        'Current page counts 51 main / 50 submit; highlights included; author block not rendered in submit']}
(WORK/'visual_review.json').write_bytes(encoded(visual))
members={}
bindings={}
t32=ROOT/'outputs/revision/manuscript_rewrite_v1'
original=json.loads((t32/'manifest.json').read_bytes())
for row in original['outputs']:
    if row['path'].startswith('supplement/S'):
        raw=(t32/row['path']).read_bytes()
        assert bind(raw)['sha256']==row['sha256'],row['path']
        name='original/'+Path(row['path']).name
        members[name]=raw
        bindings[name]={'source':(t32/row['path']).relative_to(ROOT).as_posix(),**bind(raw),'study':'original_Full_Base'}
assert len(members)==14
f02=ROOT/'outputs/revision/u09_manuscript_assets_v1'
unified=json.loads((f02/'manifest.json').read_bytes())
for name,row in unified['outputs'].items():
    source=f02/'artifacts'/name
    raw=source.read_bytes()
    assert bind(raw)==row,name
    members['u09/'+name]=raw
    bindings['u09/'+name]={'source':source.relative_to(ROOT).as_posix(),**row,'study':'unified_u08_u09_r1'}
assert len(members)==40
row_counts={}
for name,raw in members.items():
    if name.endswith('.csv'):
        row_counts[name]=len(list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))))
for name,count in {'original/S1_classification.csv':144,'original/S2_executions.csv':21,
    'original/S2_contrasts.csv':48,'original/S4_HAC.csv':6,'u09/supplement/accounts.csv':1530,
    'u09/supplement/contrasts.csv':20,'u09/supplement/bridge.csv':3}.items():
    assert row_counts[name]==count,(name,row_counts.get(name))
symbol_rows=[row for row in csv.DictReader(io.StringIO(members['original/S1_classification.csv'].decode('utf-8-sig')))
    if row['dimension']=='symbol']
assert len(symbol_rows)==81
companion_manifest={'schema':'unified_manuscript_companions_v1','members':bindings,
    'row_counts':row_counts,'notes':['Original S1-S4 and U09 are separate studies; no response pooling',
        'Every companion is copied byte-for-byte from its named frozen release',
        'Forty artifacts plus this manifest; no fitting, analysis or bootstrap rerun']}
members['companion_manifest.json']=encoded(companion_manifest)
target=WORK/'scientific_companions.zip'
if not target.exists():
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,raw in sorted(members.items()):
            info=zipfile.ZipInfo(name,(2026,11,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,raw,compresslevel=9)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist())==41
    for name,raw in members.items():assert archive.read(name)==raw
(WORK/'companion_checks.json').write_bytes(encoded({'status':'PASS_40_EXACT_BYTE_COMPANIONS','zip':bind(target.read_bytes()),
    'members':40,'zip_members':41,'original_artifacts':14,'U09_artifacts':26,'bindings':bindings,'row_counts':row_counts,
    'original_S1_symbol_rows':81}))
rights={'schema':'manuscript_local_handoff_rights_v1','public_release_authorized':False,'pid':None,
    'editorial_acceptance_certified':False,'comments_certified_closed':0,'comments':18,
    'submission_upload_or_external_contact_performed':False,'native_rowwise_causal_gate':'FAIL',
    'whole_system_causal_status':'NOT_CERTIFIED','scope':'LOCAL_EVIDENCE_ALIGNED_MANUSCRIPT_HANDOFF_U10',
    'pending':['Public redistribution permissions for author additions, market/news data, models and hosted outputs',
        'Real persistent archive identifier after an authorized public release',
        'Corresponding email, manuscript ID, editor decision letter and submission/anonymity route',
        'Missing scientific/editorial evidence itemized individually in the 87-request crosswalk'],
    'author_metadata_policy':'Preserve confirmed order/ORCID and existing title, affiliations, CRediT, funding and declarations'}
(WORK/'rights.json').write_bytes(encoded(rights))
ledger=json.loads((WORK/'reference_ledger.json').read_bytes())
with zipfile.ZipFile(ROOT/'docs/plan/week12/manuscript_content_checks.zip') as archive:
    ledger['F03_primary_source_audit']=json.loads(archive.read('references_audit.json'))
ledger['earlier_metadata_audit']={'path':'outputs/revision/reference_audit_v1/reference_audit.json',
    **bind((ROOT/'outputs/revision/reference_audit_v1/reference_audit.json').read_bytes())}
(WORK/'reference_ledger.json').write_bytes(encoded(ledger))
print(json.dumps({'status':'PASS_F05_COMPANIONS_VISUAL_AND_RIGHTS','visual_pages':101,
    'prior_identical_pages':99,'direct_changed_pages':2,'companion_members':40,'companion_zip_members':41,
    'original_scope_preserved':True,'public_release_authorized':False}))
