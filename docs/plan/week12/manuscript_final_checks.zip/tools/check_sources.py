"""Đối soát nguồn, số liệu đã khóa và hợp đồng phản hồi cho release tài liệu F05."""
from collections import Counter
from pathlib import Path
import csv
import hashlib
import json
import re
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/'tmp/f05'
BASE='22ceec41'


def bind(raw: bytes) -> dict:
    """Hash nguyên byte theo receipt, không sửa expected hoặc chuẩn hóa bằng chứng."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def before(name: str) -> str:
    """Chỉ chuẩn hóa LF khi so sánh cú pháp TeX."""
    return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT).decode().replace('\r\n','\n')


f04=json.loads((ROOT/'outputs/revision/manuscript_figures_v1/manifest.json').read_bytes())
changed=[n for n,row in f04['sources'].items() if bind((ROOT/n).read_bytes())!=row]
assert changed==['paper/sections/availability.tex'],changed
for group in ('inputs','outputs'):
    for name,row in f04[group].items():
        target=ROOT/name if group=='inputs' else ROOT/'outputs/revision/manuscript_figures_v1'/name
        assert bind(target.read_bytes())==row,name
math_count=0
for path in (ROOT/'paper/sections').glob('*.tex'):
    name=path.relative_to(ROOT).as_posix()
    old,new=before(name),path.read_text(encoding='utf-8')
    titles=r'\\(?:section|subsection|subsubsection)\*?\{[^\n]+\}'
    assert re.findall(titles,old)==re.findall(titles,new),name
    pattern=r'\\begin\{(equation|align)\}(.*?)\\end\{\1\}'
    old_math,new_math=re.findall(pattern,old,re.S),re.findall(pattern,new,re.S)
    assert old_math==new_math,name
    math_count+=len(old_math)
f02=json.loads((ROOT/'outputs/revision/u09_manuscript_assets_v1/manifest.json').read_bytes())
for group in ('sources','inputs'):
    for name,row in f02[group].items():
        assert bind((ROOT/name).read_bytes())==row,name
for name,row in f02['outputs'].items():
    assert bind((ROOT/'outputs/revision/u09_manuscript_assets_v1/artifacts'/name).read_bytes())==row,name
for name in f02['installation']['members']:
    assert bind((ROOT/'paper/generated/u09'/name).read_bytes())==f02['outputs'][name]
with zipfile.ZipFile(ROOT/'docs/plan/week12/final_evidence_snapshot.zip') as archive:
    snapshot=json.loads(archive.read('snapshot_manifest.json'))
    frozen={**snapshot['frozen_packages'],**snapshot['legacy_archives']}
    for name,row in frozen.items():
        assert bind((ROOT/name).read_bytes())==row,name
    stable={n:row for n,row in snapshot['source_members'].items() if not n.startswith(('paper/','revision/'))}
    for name,row in stable.items():
        assert bind((ROOT/name).read_bytes())=={k:row[k] for k in ('bytes','sha256')},name
for name in ('response_to_reviewers.md','reviewer_matrix.csv','README.md','archive_runbook.md'):
    assert (WORK/'previous'/name).read_bytes()==subprocess.check_output(['git','show',BASE+':revision/'+name],cwd=ROOT)
rows=json.loads((WORK/'response_map.json').read_bytes())
matrix=list(csv.DictReader((ROOT/'revision/reviewer_matrix.csv').open(encoding='utf-8',newline='')))
text=(ROOT/'revision/response_to_reviewers.md').read_text(encoding='utf-8')
assert len(rows)==len(matrix)==87
assert len({r['reviewer'] for r in rows})==18
assert [r['id'] for r in rows]==[r['request_id'] for r in matrix]==re.findall(r'^### (R\d+\.\d+)$',text,re.M)
assert all(not r['comment_closed'] for r in rows)
assert all(r['comment_closed']=='false' for r in matrix)
for row,m in zip(rows,matrix):
    assert row['status']==m['status'] and row['remaining_dependency']==m['remaining_dependency']
    for source in row['source_locations']:
        raw=(ROOT/source['path']).read_bytes()
        assert bind(raw)=={k:source[k] for k in ('bytes','sha256')}
        source_text=raw.decode('utf-8')
        assert source['anchor'] in source_text
        assert source_text[:source_text.index(source['anchor'])].count('\n')+1==source['line']
    for evidence in row['evidence']:
        raw=(WORK/evidence['member']).read_bytes() if 'member'in evidence else (ROOT/evidence['path']).read_bytes()
        assert bind(raw)=={k:evidence[k] for k in ('bytes','sha256')},evidence['path']
    for name,data in row['final_pdf_locator'].items():
        assert bind((WORK/(name+'.pdf')).read_bytes())=={k:data[k] for k in ('bytes','sha256')}
        assert data['locations'] or (row['reviewer']=='R18' and name=='main_submit')
    assert row['response'] in text
for fragment in ('forty entries','eighteen cited keys','main has 34','submit 35','closed_historical_exploratory'):
    assert fragment.lower() not in text.lower(),fragment
assert not any('closed' in r['status'] or r['status']=='addressed' for r in rows)
tex='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'paper').rglob('*.tex'))
labels=re.findall(r'\\label\{([^}]+)\}',tex)
assert len(labels)==len(set(labels))
assert set(re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',tex))<=set(labels)
definitions=dict(re.findall(r'\\newcommand\{\\(Unified[A-Za-z]+)\}\{([^\n]+)\}',tex))
for key,literal in {'UnifiedNativeReturn':'-0.653','UnifiedCommonReturn':'-1.025','UnifiedVOneReturn':'-0.698',
    'UnifiedMTReturn':'-1.253','UnifiedVOneCommonReturnEffect':'0.327','UnifiedVOneNativeReturnEffect':'-0.045',
    'UnifiedVOneCommonReturnLow':'0.067','UnifiedVOneCommonReturnHigh':'0.586',
    'UnifiedVOneNativeReturnLow':'-0.362','UnifiedVOneNativeReturnHigh':'0.271'}.items():
    assert definitions[key]==literal,(key,definitions[key])
proof={'status':'PASS_F05_SOURCES_NUMBERS_AND_87_REQUESTS','baseline_commit':BASE,
    'paper_files':64,'changed_paper_files':changed,'unchanged_paper_files':63,
    'all_equation_align_blocks_preserved':math_count,'metadata_abstract_highlights_figures_tables_unchanged':True,
    'f02_artifacts_unchanged':26,'f02_numeric_cells_frozen':798,'historical_packages_unchanged':len(frozen),
    'non_paper_revision_source_bindings_unchanged':len(stable),'previous_reviewer_documents_preserved':4,
    'requests':87,'comments':18,'comments_certified_closed':0,'request_status_counts':dict(Counter(r['status'] for r in rows)),
    'source_line_anchor_and_evidence_hashes_verified':True,'pdf_bindings_current':True,
    'runtime_code_schema_config_data_changed':False,'unit_compile_e2e_leakage_rerun':False,
    'existing_runtime_gates':'Historical source/runtime/receipts byte-checked; scoped PASS remains confined to its original release; native rowwise causal FAIL and whole-system NOT_CERTIFIED',
    'new_llm_market_api_calls':0,'inference_fit_scoring_bootstrap_rerun':False,
    'public_release_authorized':False,'pid':None,'editorial_acceptance_certified':False}
(WORK/'source_content_checks.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False))
