"""Build hai entrypoint biệt lập bằng MiKTeX hiện có; không sửa generator hoặc evidence cũ."""
from pathlib import Path
import json
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'tmp/f05'
STAGE = Path(tempfile.mkdtemp(prefix='f05-manuscript-'))
(WORK/'build_root.txt').write_text(str(STAGE), encoding='utf-8')
commands = []
for name in ('main', 'main_submit'):
    folder = STAGE/name
    shutil.copytree(ROOT/'paper', folder)
    pdflatex = ['pdflatex', '--disable-installer', '-halt-on-error', '-interaction=nonstopmode',
        '-file-line-error', '-recorder', name+'.tex']
    sequence = [pdflatex, ['bibtex', '--disable-installer', name], pdflatex, pdflatex]
    logdir = WORK/'build_logs'/name
    logdir.mkdir(parents=True, exist_ok=True)
    for index, args in enumerate(sequence, 1):
        process = subprocess.run(args, cwd=folder, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (logdir/f'command_{index}.log').write_bytes(process.stdout)
        commands.append({'entrypoint': name, 'args': args, 'returncode': process.returncode,
            'log': f'build_logs/{name}/command_{index}.log'})
        (WORK/'build_commands.json').write_text(json.dumps(commands, indent=2), encoding='utf-8')
        if process.returncode:
            print(process.stdout.decode('utf-8', errors='replace')[-6500:])
            raise SystemExit(process.returncode)
    shutil.copyfile(folder/(name+'.pdf'), WORK/(name+'.pdf'))
    shutil.copyfile(folder/(name+'.log'), WORK/(name+'.log'))
    shutil.copyfile(folder/(name+'.aux'), WORK/(name+'.aux'))
    print('Đã build '+name, flush=True)
print('Thư mục build biệt lập: '+str(STAGE), flush=True)
