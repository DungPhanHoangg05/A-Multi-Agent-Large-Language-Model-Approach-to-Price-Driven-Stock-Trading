"""Đồng bộ 87 phản hồi/matrix với PDF cuối; giữ byte bằng chứng và trạng thái chưa nghiệm thu."""
from collections import Counter
from pathlib import Path
import csv
import hashlib
import io
import json
import re
import shutil

import fitz

from curation import ADDITIONS, EXTRA_LABELS, LIMITS

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT/'tmp/f05'
RELEASE = 'outputs/revision/manuscript_unified_final_v1'
seed = json.loads((ROOT/'outputs/revision/author_preserved_v1/response_map.json').read_bytes())
assert len(seed)==87 and {r['id'] for r in seed}==set(LIMITS)
old_text = (WORK/'previous/response_to_reviewers.md').read_text(encoding='utf-8')
headings = dict(re.findall(r'^## (R\d+) — (.+)$',old_text,re.M))
assert len(headings)==18
pdf_checks = json.loads((WORK/'pdf_locators_geometry.json').read_bytes())


def bind(raw: bytes) -> dict:
    """Khóa byte nguồn/bằng chứng và PDF."""
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def encoded(value: object) -> bytes:
    """JSON UTF-8 xác định."""
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')


documents = {name:fitz.open(WORK/(name+'.pdf')) for name in ('main','main_submit')}
labels = {}
references = {}
stage = Path((WORK/'build_root.txt').read_text(encoding='utf-8'))
for name,document in documents.items():
    aux = (WORK/(name+'.aux')).read_text(encoding='utf-8')
    labels[name] = {}
    for label,number,logical in re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}\{([^}]+)\}',aux):
        if not logical.isdigit():
            continue
        physical = int(logical)+1
        assert 1<=physical<=len(document)
        row = {'label':label,'number':number.replace('~',' '),'latex_page':int(logical),
            'physical_page':physical,'locator_type':'current_pdf_latex_aux'}
        if label in pdf_checks[name]['locators']:
            assert physical==pdf_checks[name]['locators'][label]['physical_page']
            row['locator_type']='caption_text_and_aux_verified'
        labels[name][label]=row
    numbers = dict(re.findall(r'\\bibcite\{([^}]+)\}\{\{(\d+)\}',aux))
    assert len(numbers)==21
    ref_start = next(i for i,p in enumerate(document) if p.get_text().startswith('References\n'))
    references[name]={}
    for key,number in numbers.items():
        hits = [(i+1,list(rect)) for i in range(ref_start,len(document)) for rect in document[i].search_for('['+number+']')]
        assert len(hits)==1,(name,key,hits)
        references[name][key]={'number':int(number),'physical_page':hits[0][0],'bbox':hits[0][1]}
    for suffix in ('bbl','blg'):
        shutil.copyfile(stage/name/(name+'.'+suffix),WORK/(name+'.'+suffix))
assert {k:r['number'] for k,r in references['main'].items()}=={k:r['number'] for k,r in references['main_submit'].items()}
keys = re.findall(r'@\w+\{([^,]+),',(ROOT/'paper/references.bib').read_text(encoding='utf-8'))
assert len(keys)==43 and 'deng2017deep' not in references['main']
reference_ledger = {'status':'CURRENT_NUMBERING_VERIFIED_HISTORICAL_IDENTITIES_UNRESOLVED',
    'bibtex_entries':43,'rendered_cited_keys':21,'uncited_keys':sorted(set(keys)-set(references['main'])),
    'current_pdf_references':references,'historical_reviewer_numbers_unresolved':[14,21,22,23],
    'new_primary_sources':['xie2022implicitbayes','rubin2022retrieve','hamilton2005regimes'],
    'verification':'Số reference/bbox lấy từ PDF và aux mới; metadata nghiên cứu từ audit chính đã khóa, không nhận tra cứu mạng mới.'}
(WORK/'reference_ledger.json').write_bytes(encoded(reference_ledger))


def expand(text: str) -> str:
    """Thay placeholder bằng số bảng/hình thực tế của build."""
    return re.sub(r'\{((?:tab|fig):[^}]+)\}',lambda m:labels['main'][m[1]]['number'],text)


updates = {
'R1.7':"The original title is retained at the author's instruction. Abstract, highlights, contributions and conclusion now limit the claims to a specified integration and historical comparison. Full loses more than Base on the main account mean, underperforms CASH economically and logistic-price on BA; favorable small panels do not override these outcomes. No causal alpha, stable predictive superiority or profitable deployment is asserted.",
'R16.6':"Deng metadata distinguishes the 2017 issue from 2016 online-first timing in the retained source entry. That entry remains uncited and therefore has no rendered reference number. The current bibliography contains 43 entries and 21 rendered cited keys, including three primary sources added in F03 for regime context, Bayesian ICL and prompt retrieval. Current numbering is read from both newly built PDFs; it does not authenticate historical reviewer reference identities.",
'R17.2':"The article retains the author-required title, eight main sections, original subsection topics and six appendices A-F. The current build has seven figures, eight main tables and thirteen appendix tables, plus the ruled line-numbered Algorithm 1. Its 27 equation/align environments are unchanged from F04; the 24 pre-extension formulation blocks retain their F03-preserved content, with the extension/metric additions distinguished. Main has 51 physical pages and submit 50, including highlights. We preserve scientific detail rather than asserting that the requested appendix reduction or every brevity preference is satisfied. No journal page-limit or anonymity compliance is certified.",
'R18.3':"The author explicitly confirmed Phuong-Thai Nguyen's ORCID as 0009-0006-2033-7788; its earlier single commented-submit correction and the separate metadata snapshot are preserved. F03-F05 retain names/order, affiliations, CRediT, funding and declarations. Manuscript ID, editor letter, submission route, independent ORCID ownership and any required individual signed approvals are not supplied; no submission permission is asserted."}
reference_requests={'R16.1':'kakushadze2016formulaic','R16.2':'nguyen2023visobert',
    'R16.3':'white2000reality','R16.4':'tradingagents2024','R16.5':'tsantekidis2017lob','R16.6':'deng2017deep'}
specific_sources={
    'R5.2':('paper/sections/06_backtest_results.tex','Calendar-aligned HAC accuracy effects'),
    'R5.4':('paper/sections/05_experimental_setup.tex','Annualised cycle ratios are NA'),
    'R8.3':('paper/sections/availability.tex','Distribution remains subject to source terms'),
    'R9.1':('paper/sections/availability.tex','OHLCV/news snapshots are reconstructed'),
    'R9.2':('paper/sections/appendices.tex','The research runtime is Python 3.13.5'),
    'R9.5':('paper/sections/availability.tex','Public distribution rights'),
    'R10.1':('paper/sections/06_backtest_results.tex','Native diagnostics separately account'),
    'R10.3':('paper/sections/06_backtest_results.tex','Table~\\ref{tab:numeric} is a separate numeric study'),
    'R10.4':('paper/sections/06_backtest_results.tex','all twenty random eligible-five trials'),
    'R10.5':('paper/sections/03_problem_formulation.tex','three price/volume omissions lack'),
    'R14.2':('paper/sections/04_system_architecture.tex','The renderer audit matched 204 images'),
    'R17.6':('paper/main.tex','\\title{'),
    'R18.1':('paper/main.tex','Thanh-Tam Do Thi'),
    'R18.2':('paper/main.tex','Van-Tang Nguyen'),
    'R18.3':('paper/main.tex','0009-0006-2033-7788')}
new_rows=[]
for prior in seed:
    identifier,reviewer = prior['id'],prior['reviewer']
    response = updates.get(identifier,prior['response'])
    if identifier in ('R1.1','R1.2'):
        response=response.replace('Table 2','Table '+labels['main']['tab:classification']['number'])
    if identifier=='R1.4':
        response=response.replace('Table 3','Table '+labels['main']['tab:accounts']['number'])
    if identifier=='R3.3':
        response=response.replace('Table 4','Table '+labels['main']['tab:repeats']['number'])
    response=expand(response+(' '+ADDITIONS[identifier] if identifier in ADDITIONS else ''))
    source_locations=[]
    chosen_sources=prior['source_locations']
    if identifier in reference_requests:
        chosen_sources=[{'path':'paper/references.bib','anchor':reference_requests[identifier]},
            {'path':'paper/sections/02_related_work.tex','anchor':'\\section{Related works}'}]
    if identifier in specific_sources:
        path,anchor=specific_sources[identifier]
        chosen_sources=[{'path':path,'anchor':anchor}]
    for source in chosen_sources:
        path=ROOT/source['path']
        text=path.read_text(encoding='utf-8')
        assert source['anchor'] in text,(identifier,source['path'],source['anchor'])
        source_locations.append({'path':source['path'],'anchor':source['anchor'],
            'line':text[:text.index(source['anchor'])].count('\n')+1,**bind(path.read_bytes())})
    evidence=[]
    for item in prior['evidence']:
        if item['path'] in ('revision/response_to_reviewers.md','revision/reviewer_matrix.csv'):
            member='previous/'+Path(item['path']).name
            raw=(WORK/member).read_bytes()
            assert bind(raw)['sha256']==item['sha256'],item['path']
            evidence.append({'path':'docs/plan/week12/manuscript_final_checks.zip','member':member,
                **bind(raw),'original_path':item['path'],'source_commit':'22ceec41',
                'scope':'historical_pre_F05_document_not_current_claim'})
            continue
        raw=(ROOT/item['path']).read_bytes()
        assert bind(raw)['sha256']==item['sha256'],item['path']
        evidence.append({'path':item['path'],**bind(raw),'scope':'original_study_or_documentary_audit'})
    if identifier in ADDITIONS:
        for path,scope in [('docs/plan/week12/unified_analysis_results.zip','U09_frozen_analysis'),
            ('docs/plan/week12/unified_live_research.zip','U08_separate_response_collection'),
            ('outputs/revision/u09_manuscript_assets_v1/manifest.json','F02_literal_presentation_bindings')]:
            evidence.append({'path':path,**bind((ROOT/path).read_bytes()),'scope':scope})
    if reviewer=='R16':
        evidence.append({'path':'docs/plan/week12/manuscript_content_checks.zip',
            **bind((ROOT/'docs/plan/week12/manuscript_content_checks.zip').read_bytes()),'scope':'F03_primary_reference_audit'})
    location_names=list(dict.fromkeys([row['label'] for row in prior['final_pdf_locator']['main'].get('locations',[]) if 'label' in row]
        + EXTRA_LABELS[reviewer]))
    # Các yêu cầu chưa có định danh lịch sử không được gắn số citation hiện tại làm bằng chứng đã giải quyết.
    note='Current section/table context; locators do not certify acceptance or unperformed evidence.'
    if reviewer=='R16':
        location_names=['sec:relatedworks','sec:limitations']
        note='Current bibliography context only; historical [14]/[21]/[22]/[23] identities remain unresolved. Deng is uncited.'
    final_pdf={}
    for name,document in documents.items():
        locs=[labels[name][label] for label in location_names]
        if identifier in reference_requests:
            key=reference_requests[identifier]
            if key in references[name]:
                locs.append({'label':'reference:'+key,'locator_type':'rendered_reference_number_and_bbox',**references[name][key]})
        if reviewer=='R18':
            locs=[]
            author={'R18.1':'Thanh-Tam Do Thi','R18.2':'Van-Tang Nguyen','R18.3':'Phuong-Thai Nguyen'}[identifier]
            for i,page in enumerate(document):
                for rect in page.search_for(author):
                    locs.append({'physical_page':i+1,'text':author,'bbox':list(rect),'locator_type':'rendered_author_text'})
            if name=='main_submit':
                assert not locs
        final_pdf[name]={'pdf':RELEASE+'/'+name+'.pdf',**bind((WORK/(name+'.pdf')).read_bytes()),
            'locations':locs,'note':'Author/CRediT blocks are commented in submit; no rendered author locator is invented.' if reviewer=='R18' and name=='main_submit' else note}
    status,remaining=LIMITS[identifier]
    new_rows.append({'id':identifier,'reviewer':reviewer,'request_vi':prior['request_vi'],
        'status':status,'comment_closed':False,'response':response,'remaining_dependency':remaining,
        'response_anchor':identifier.lower().replace('.',''),'source_locations':source_locations,
        'evidence':evidence,'final_pdf_locator':final_pdf})

intro='''# Response to reviewer comments

Current response for the unified manuscript release dated 13 November 2026. We thank the reviewers and distinguish two historical studies: the original Full/Base corrected-chart evaluation and the separately collected U08/U09 extension on the same eligible calendar. They retain separate responses, method interfaces, statistics and provenance; neither repeats nor matching dates enlarge the independent market sample. The article preserves the author's title, metadata, eight-section framework and A-F topics while reporting negative economics, baseline-dependent effects and unfulfilled evidence requirements.

All 18 comments and 87 indexed requests are mapped below and in the synchronized matrix. `documented_with_limits` means the specified explanation/evidence is present within its stated scope; it does not mean reviewer acceptance. Other states explicitly retain missing scientific evidence, unresolved historical identities, editorial requests or rights/author-route dependencies. **Zero of eighteen comments is certified closed.** Native row-wise causal status remains FAIL and whole-system NOT_CERTIFIED.

Locations below refer only to the newly built release: main has 51 physical pages and submit 50, including the unnumbered highlights sheet. Physical page 2 is the title/abstract page, with subsequent printed numbers one lower than physical pages. PDFs have no printed line numbering; source lines, LaTeX labels and physical pages are supplied, with text bounding boxes where applicable. Author/CRediT blocks are commented in submit; funding remains rendered, so anonymity/journal-route compliance is not certified.

The [final release manifest](../outputs/revision/manuscript_unified_final_v1/manifest.json), [request crosswalk](../outputs/revision/manuscript_unified_final_v1/response_map.json), [current matrix](reviewer_matrix.csv) and [archive runbook](archive_runbook.md) identify evidence, source bytes and exact PDF versions. The pre-F05 response and 43-row matrix are preserved byte-for-byte in the F05 QA archive; all older releases remain unchanged. The current 87-row matrix supersedes their current-status claims and stale locators. No inference, scoring, bootstrap, refitting, upload or submission is performed in F05. Local handoff is complete; public rights/PID and scientific/editorial acceptance are separate.

'''
parts=[intro]
for reviewer,title in headings.items():
    parts.append('## '+reviewer+' — '+title+'\n\n')
    for row in new_rows:
        if row['reviewer']!=reviewer:
            continue
        parts.append('### '+row['id']+'\n\n'+row['response']+'\n\n')
        parts.append('**Disposition:** `'+row['status']+'`; comment closure not certified. **Remaining:** '+row['remaining_dependency']+'\n\n')
        paths=list(dict.fromkeys(item['path'] for item in row['evidence']))
        parts.append('Evidence: '+ '; '.join('['+path+'](../'+path+')' for path in paths)+'.\n\n')
        parts.append('Source anchors: '+'; '.join('['+s['path']+':'+str(s['line'])+'](../'+s['path']+') (`'+s['anchor']+'`)' for s in row['source_locations'])+'.\n\n')
        positions=[]
        for name,data in row['final_pdf_locator'].items():
            pages=sorted({loc['physical_page'] for loc in data['locations']})
            positions.append(name+' physical pp. '+', '.join(map(str,pages)) if pages else name+': author block not rendered')
        parts.append('Verified PDF locations: '+'; '.join(positions)+'. '+row['final_pdf_locator']['main']['note']+'\n\n')
parts.append('''## Remaining scientific, rights and editorial requirements

The missing prospective/cohort, controlled repeat/ablation, native causal, financial-news provenance/domain, counterfactual visual and executable-market evidence are not created by completing the manuscript. Historical reviewed references [14]/[21]/[22]/[23] remain unidentified. Public PID/redistribution rights, corresponding email, editor letter and submission route remain unavailable. The author-required original title and substantial A-F detail remain, so brevity/title preferences are not claimed fully satisfied. U10 completion denotes this evidence-aligned local manuscript handoff, not acceptance, permission to submit, or public publication. No upload, external contact, submission or deployment has occurred.
''')
response_path=Path('\\\\?\\'+str(ROOT/'revision/response_to_reviewers.md'))
response_path.write_text(''.join(parts),encoding='utf-8',newline='\n')
csv_rows=[]
for row in new_rows:
    csv_rows.append({'reviewer':row['reviewer'],'subrequirement':row['id'],'status':row['status'],
        'evidence':'; '.join(e['path']+('::'+e['member'] if 'member' in e else '') for e in row['evidence']),
        'manuscript_locator':'; '.join(name+': '+(', '.join(str(p) for p in sorted({loc['physical_page'] for loc in data['locations']})) or 'author block not rendered') for name,data in row['final_pdf_locator'].items()),
        'remaining_dependency':row['remaining_dependency'],'request_id':row['id'],'request_vi':row['request_vi'],
        'response_anchor':row['response_anchor'],'comment_closed':'false'})
stream=io.StringIO(newline='')
writer=csv.DictWriter(stream,fieldnames=list(csv_rows[0]),lineterminator='\n')
writer.writeheader();writer.writerows(csv_rows)
(ROOT/'revision/reviewer_matrix.csv').write_text(stream.getvalue(),encoding='utf-8',newline='\n')
for row in new_rows:
    text=response_path.read_text(encoding='utf-8')
    anchor='### '+row['id']+'\n'
    row['source_locations'].append({'path':'revision/response_to_reviewers.md','anchor':anchor.strip(),
        'line':text[:text.index(anchor)].count('\n')+1,**bind(response_path.read_bytes())})
(WORK/'response_map.json').write_bytes(encoded(new_rows))
(WORK/'pdf_anchors.json').write_bytes(encoded(labels))
summary={'requests':87,'comments':18,'comments_certified_closed':0,'statuses':dict(Counter(r['status'] for r in new_rows)),
    'historical_evidence_files':len({e['path'] for row in seed for e in row['evidence']}),
    'pdf_pages':{name:len(doc) for name,doc in documents.items()}}
(WORK/'review_summary.json').write_bytes(encoded(summary))
print(json.dumps(summary,ensure_ascii=False))
for document in documents.values():document.close()
