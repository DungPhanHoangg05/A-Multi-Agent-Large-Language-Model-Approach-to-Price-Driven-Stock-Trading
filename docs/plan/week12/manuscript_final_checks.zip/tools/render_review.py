"""Render mọi trang bằng Poppler, tạo contact sheet và dò hình học/chữ/font cho F05."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import re
import shutil
import subprocess

import fitz
from PIL import Image, ImageDraw, ImageOps

ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/'tmp/f05'


def render(name: str) -> dict:
    """Từng PDF có cây ảnh riêng; contact sheet ghi số trang vật lý để kiểm đủ."""
    stage=Path((WORK/'build_root.txt').read_text(encoding='utf-8'))
    target=stage/'rendered'/name
    target.mkdir(parents=True,exist_ok=True)
    run=subprocess.run(['pdftoppm','-r','90','-png',str(stage/name/(name+'.pdf')),str(target/'page')],
        stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (WORK/(name+'_render.log')).write_bytes(run.stdout)
    if run.returncode:
        raise ValueError(run.stdout.decode(errors='replace'))
    doc=fitz.open(WORK/(name+'.pdf'))
    images=sorted(target.glob('page-*.png'))
    assert len(images)==len(doc)
    archive_folder=WORK/'rendered'/name
    archive_folder.mkdir(parents=True,exist_ok=True)
    for previous in archive_folder.glob('page-*.png'):
        previous.unlink()
    for path in images:
        shutil.copyfile(path,archive_folder/path.name)
    sheets=WORK/'sheets'
    sheets.mkdir(exist_ok=True)
    for start in range(0,len(images),4):
        thumbs=[]
        for index,path in enumerate(images[start:start+4],start+1):
            image=Image.open(path).convert('RGB')
            image.thumbnail((700,990))
            tile=Image.new('RGB',(720,1030),'#dddddd')
            tile.paste(image,((720-image.width)//2,30))
            ImageDraw.Draw(tile).text((12,8),f'{name} / trang {index}',fill='black')
            thumbs.append(tile)
        sheet=Image.new('RGB',(1440,2060),'#dddddd')
        for index,tile in enumerate(thumbs):
            sheet.paste(tile,((index%2)*720,(index//2)*1030))
        sheet.save(sheets/f'{name}_{start+1:02d}-{min(start+4,len(images)):02d}.png')
    outside=[]
    replacements=[]
    fonts=set()
    text=[]
    for i,page in enumerate(doc,1):
        text.append(page.get_text())
        if '\ufffd' in text[-1] or '\u25a0' in text[-1]:
            replacements.append(i)
        for x0,y0,x1,y1,*_ in page.get_text('words'):
            if x0<-.5 or y0<-.5 or x1>page.rect.width+.5 or y1>page.rect.height+.5:
                outside.append(i)
        fonts.update(font[2] for font in page.get_fonts())
    (WORK/(name+'_extracted.txt')).write_text('\n\f\n'.join(text),encoding='utf-8')
    log=(WORK/(name+'.log')).read_text(encoding='utf-8',errors='replace')
    result={'entrypoint':name,'pages':len(doc),'rendered_pages':len(images),
        'overfull':len(re.findall(r'Overfull \\[hv]box',log)),
        'undefined_reference_or_citation':bool(re.search(r'undefined|multiply defined',log,re.I)),
        'missing_glyph':bool(re.search(r'Missing character:',log)), 'type3_fonts':'Type3' in fonts,
        'words_outside_page':sorted(set(outside)),'replacement_or_black_square_pages':replacements,
        'log_warnings':[line for line in log.splitlines() if 'Warning:' in line],
        'underfull_notices':len(re.findall(r'Underfull \\[hv]box',log))}
    doc.close()
    return result


with ThreadPoolExecutor(max_workers=2) as pool:
    result=list(pool.map(render,('main','main_submit')))
(WORK/'render_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
