"""Đối soát vị trí caption, thứ tự bảng/hình, khung TikZ và lịch đã khóa."""
from pathlib import Path
import itertools
import json
import re
import subprocess
import sys

import fitz
import PIL

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT/'tmp/f05'
summary = {}
expected_nodes = {'fig:flow':10,'fig:alpha_agent':13,'fig:decision_agent':8,'fig:walkforward':7}
for name in ('main','main_submit'):
    document = fitz.open(WORK/(name+'.pdf'))
    aux = (WORK/(name+'.aux')).read_text(encoding='utf-8')
    locators = {}
    for label, number, logical in re.findall(r'\\newlabel\{((?:fig|tab|alg):[^}]+)\}\{\{([^}]+)\}\{([^}]+)\}',aux):
        kind = {'fig':'Figure','tab':'Table','alg':'Algorithm'}[label.partition(':')[0]]
        pattern = rf'\b{kind}\s*{re.escape(number)}\s*:'
        found = [i+1 for i,page in enumerate(document) if re.search(pattern,page.get_text())]
        assert len(found) == 1, (name,label,found)
        locators[label] = {'type':kind,'number':number,'latex_page':logical,'physical_page':found[0]}
    assert len(locators) == 29
    assert sum(row['type']=='Figure' for row in locators.values()) == 7
    assert sum(row['type']=='Table' for row in locators.values()) == 21
    assert sum(row['type']=='Algorithm' for row in locators.values()) == 1
    assert locators['tab:u09-comparison']['physical_page'] < locators['fig:u09-return-contrasts']['physical_page']
    assert locators['tab:u09-scope']['physical_page'] < locators['fig:walkforward']['physical_page']
    geometry = {}
    for label, expected in expected_nodes.items():
        page = document[locators[label]['physical_page']-1]
        boxes = [item['rect'] for item in page.get_drawings() if item.get('fill') is not None
            and min(item['fill']) > .9 and item['rect'].width > 70 and item['rect'].height > 20]
        assert len(boxes) == expected,(name,label,len(boxes))
        overlap = []
        for (i,a),(j,b) in itertools.combinations(enumerate(boxes),2):
            intersection = a & b
            if intersection.width > .5 and intersection.height > .5:
                overlap.append([i,j])
        assert not overlap,(name,label,overlap)
        overflow = []
        for i,box in enumerate(boxes):
            padded = box + (-1,-1,1,1)
            for x0,y0,x1,y1,word,*_ in page.get_text('words'):
                bounds = fitz.Rect(x0,y0,x1,y1)
                center = fitz.Point((x0+x1)/2,(y0+y1)/2)
                if box.contains(center) and not padded.contains(bounds):
                    overflow.append({'node':i,'word':word})
        assert not overflow,(name,label,overflow)
        geometry[label] = {'node_count':len(boxes),'overlapping_node_pairs':overlap,
            'words_outside_own_node':overflow}
    summary[name] = {'pages':len(document),'locators':locators,'diagram_geometry':geometry}
    document.close()
(WORK/'pdf_locators_geometry.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
points = json.loads((ROOT/'outputs/revision/u09_manuscript_assets_v1/artifacts/points.json').read_bytes())
calendar = {'status':'MATCHED_EXISTING_CALENDAR_TO_FROZEN_U09_POINTS',
    'dates':sorted({row['cutoff'] for row in points}),
    'points':len(points),'BHN_points':sum(row['symbol']=='BHN' for row in points),
    'inspection':'Nhãn 12 ngày và sáu ô BHN bị loại trong PNG gốc khớp points.json; không đổi ảnh hoặc nhãn.'}
assert len(calendar['dates'])==12 and calendar['points']==102 and calendar['BHN_points']==6
(WORK/'calendar_checks.json').write_text(json.dumps(calendar,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
runtime = {'python':sys.version,'pymupdf':fitz.VersionBind,'pillow':PIL.__version__,'tools':{}}
for program,flag in (('pdflatex','--version'),('bibtex','--version'),('pdftoppm','-v')):
    proc = subprocess.run([program,flag],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert proc.returncode==0
    runtime['tools'][program] = {'args':[program,flag],'returncode':0,'version':proc.stdout.decode('utf-8',errors='replace')}
(WORK/'build_runtime.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS_F05_PDF_LOCATORS_AND_GEOMETRY','locators_per_pdf':29,
    'nonoverlapping_tikz_nodes_per_pdf':38,'pages':{name:row['pages'] for name,row in summary.items()}},ensure_ascii=False))
