"""Kiểm gói QA và tái dựng manifest trong tiến trình offline mới."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path(sys.argv[1]).resolve()
package=Path(sys.argv[2]).resolve()
with zipfile.ZipFile(package) as archive:
    manifest=json.loads(archive.read('manifest.json'))
    assert set(archive.namelist())==set(manifest['members'])|{'manifest.json'}, 'Sai thành viên ZIP'
    for name,expected in manifest['members'].items():
        raw=archive.read(name)
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'], name
    assert Path(__file__).read_bytes()==archive.read('verify_package.py'), 'Consumer khác gói'
    for name,expected in manifest['artifact_bindings'].items():
        path=(root/name).resolve()
        assert path.is_relative_to(root), 'Đường dẫn thoát repo'
        raw=path.read_bytes()
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'], name
    accepted=json.loads(archive.read('cold_verify.log'))
result=subprocess.run([sys.executable,'-I','-X','utf8','scripts/prepare_unified_comparison.py','verify'],cwd=root,capture_output=True)
if result.returncode:
    sys.stderr.buffer.write(result.stderr)
    raise SystemExit(result.returncode)
assert json.loads(result.stdout)==accepted, 'Cold preflight khác kết quả đã khóa'
assert accepted['api'] is False and accepted['release_status']=='DESIGN_LOCKED_RELEASE_BLOCKED'
print(json.dumps({'status':'PASS_QA_COLD_PREFLIGHT','source_bindings':554,'release_status':accepted['release_status'],'api':False},sort_keys=True))
