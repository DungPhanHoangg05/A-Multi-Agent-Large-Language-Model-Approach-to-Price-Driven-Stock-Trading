"""Consumer QA U07: băm toàn gói, restore đúng namespace và cold verify không client."""
from __future__ import annotations
import argparse, hashlib, json, pathlib, sys, zipfile
from importlib.metadata import version
import platform

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=pathlib.Path)
    parser.add_argument('package',type=pathlib.Path)
    parser.add_argument('--restore',action='store_true')
    args=parser.parse_args()
    root=args.root.resolve()
    def safe(name):
        rel=pathlib.PurePosixPath(name)
        path=root.joinpath(*rel.parts)
        if not name or rel.is_absolute() or '..' in rel.parts or ':' in name or chr(92) in name or not path.resolve().is_relative_to(root):
            raise ValueError('Đường dẫn QA vượt workspace')
        if any(p.is_symlink() for p in (path,*path.parents)):
            raise ValueError('Đường dẫn QA qua symlink')
        return path
    with zipfile.ZipFile(args.package) as archive:
        manifest=json.loads(archive.read('manifest.json'))
        if manifest['version']!='unified_execution_checks_v1' or manifest['api'] is not False:
            raise ValueError('Gói QA sai version/quyền')
        names=archive.namelist()
        if len(names)!=len(set(names)) or set(names)!=set(manifest['members'])|{'manifest.json'}:
            raise ValueError('Gói QA có member thừa/trùng/thiếu')
        for name,entry in manifest['members'].items():
            raw=archive.read(name)
            if len(raw)!=entry['bytes'] or sha(raw)!=entry['sha256']:
                raise ValueError('Thành viên QA khác byte: '+name)
        sources=json.loads(archive.read('source_bindings.json'))
        for name,entry in sources.items():
            raw=safe(name).read_bytes()
            if len(raw)!=entry['bytes'] or sha(raw)!=entry['sha256']:
                raise ValueError('Nguồn QA khác byte: '+name)
        runtime=json.loads(archive.read('runtime.json'))
        actual={'python':platform.python_version(),'packages':{name:version(name) for name in runtime['packages']}}
        if actual!=runtime:
            raise ValueError('Runtime khác Python/107 package đã khóa')
        total=0
        ids=[]
        for group in ('execution','regression','pit'):
            check=json.loads(archive.read('checks_'+group+'.json'))
            if check['failures'] or check['errors'] or check['skips'] or check['tests']!=len(check['ids']):
                raise ValueError('Nhóm kiểm tra chưa PASS đầy đủ')
            total+=check['tests']
            ids+=check['ids']
        if total!=116 or len(set(ids))!=total:
            raise ValueError('Số test hoặc IDs không khớp')
        prefix=manifest['namespace']+'/'
        for name,entry in manifest['members'].items():
            if name.startswith(prefix):
                path=safe(name)
                raw=archive.read(name)
                if args.restore and not path.exists():
                    path.parent.mkdir(parents=True,exist_ok=True)
                    path.write_bytes(raw)
                if not path.is_file() or path.read_bytes()!=raw:
                    raise ValueError('Run chưa restore hoặc khác byte: '+name)
        sys.path.insert(0,str(root))
        from unittest.mock import patch
        from core.historical_evaluation_journal import load
        from core.unified_execution import verify_execution
        from core.unified_execution_providers import cold_methods
        from core.unified_experiment import source_identity,runtime_identity
        from scripts.check_unified_execution import checked_inputs
        parent=checked_inputs(root)
        directory=safe(manifest['namespace'])
        identity=load(directory/'acceptance_identity.json')
        if identity['implementation']!=source_identity(root) or identity['runtime']!=runtime_identity():
            raise ValueError('Identity implementation/runtime khác run')
        config=json.loads((root/'docs/plan/week11/historical_evaluation_protocol.json').read_bytes())['payload']['inference']['config']
        def deny(event,args):
            if event in ('socket.connect','socket.getaddrinfo'):
                raise AssertionError('QA cấm mạng thật')
            if event=='open' and args and isinstance(args[0],str) and pathlib.Path(args[0]).name.startswith('.env'):
                raise AssertionError('QA cấm đọc credential')
        sys.addaudithook(deny)
        with patch('httpx.Client',side_effect=AssertionError('QA cấm client')), \
             patch('httpx.AsyncClient',side_effect=AssertionError('QA cấm client')), \
             patch('httpx.HTTPTransport',side_effect=AssertionError('QA cấm transport thật')), \
             patch('langchain_groq.ChatGroq',side_effect=AssertionError('QA cấm SDK')), \
             patch('core.unified_execution_providers.StudyProviders',side_effect=AssertionError('QA cấm provider')):
            result=verify_execution(directory,identity,cold_methods(root,config))
        if result!=load(directory/'acceptance_result.json') or result!=manifest['result'] or result['points']!=102 or result['forecast_slots']!=2448:
            raise ValueError('Cold replay không khớp acceptance')
        print(json.dumps({'verification':'PASS_U07_PACKAGE_COLD_REPLAY','source_bindings':len(sources),'tests':total,**result},ensure_ascii=False))
if __name__=='__main__':
    main()
