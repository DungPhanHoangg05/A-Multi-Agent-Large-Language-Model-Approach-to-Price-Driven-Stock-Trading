"""Đối soát QA acceptance FIN04 và giữ riêng chứng nhận nguồn độc lập."""
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys
import zipfile

archive, root = Path(sys.argv[1]), Path(sys.argv[2])
with zipfile.ZipFile(archive) as z:
    envelope = json.loads(z.read('manifest.json'))
    p = envelope['payload']
    encoded = json.dumps(p, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    assert hashlib.sha256(encoded).hexdigest() == envelope['sha256']
    for name, pin in p['members'].items():
        raw = z.read(name)
        assert len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256'], name
    for pin in p['bindings']:
        raw = (root / pin['path']).read_bytes()
        assert len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256'], pin['path']
    assert platform.python_version() == p['runtime']['python']
    assert all(version(k) == v for k, v in p['runtime']['packages'].items())
    assert p['result'] == 'PASS_OWNER_ATTESTED' and not p['independent_price_pit_certified']
    assert p['tests_passed'] == 16 and b'Ran 16 tests' in z.read('tests.log') and b'OK' in z.read('tests.log')
    print('PASS: QA/nguồn/runtime FIN04 owner-attested; không chạy lại test/API, không chứng nhận PIT độc lập')
