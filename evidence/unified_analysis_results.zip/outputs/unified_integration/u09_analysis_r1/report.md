# U09 — Phân tích paired research102

Historical exploratory trên cohort đã exposed; sáu fold lịch, ba Decision repeat/một upstream realization.
Return là mean đều 51 tài khoản mã/fold, mỗi tài khoản mean ba repeat; không phải portfolio return.
LONG all-in fractional vào Open(t+1), ra Close(t+3), phí 0,25% và slippage 0,10% mỗi chiều; SHORT=CASH.

| Vai trò | Mean account return % | BA % | Accuracy % | MCC | F1 UP | F1 DOWN | LONG /306 | Raw Decision | Bypass |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| original_fix | -0.653 | 51.844 | 65.359 | 0.037 | 0.263 | 0.773 | 69 | 306 | 0 |
| original_common | -1.025 | 45.965 | 57.843 | -0.076 | 0.209 | 0.713 | 88 | 306 | 0 |
| bayesian_v1 | -0.698 | 50.095 | 63.399 | 0.002 | 0.243 | 0.759 | 73 | 144 | 162 |
| C2 | -1.030 | 45.749 | 57.516 | -0.080 | 0.208 | 0.710 | 89 | 3 | 303 |
| A_tp_pool | -1.019 | 46.182 | 58.170 | -0.072 | 0.210 | 0.715 | 87 | 24 | 282 |
| B_semantic | -1.030 | 45.749 | 57.516 | -0.080 | 0.208 | 0.710 | 89 | 3 | 303 |
| MT_BICL | -1.253 | 43.169 | 52.941 | -0.124 | 0.200 | 0.667 | 105 | 198 | 108 |
| Fact_Anchor | -1.286 | 42.736 | 52.288 | -0.131 | 0.198 | 0.660 | 107 | 306 | 0 |
| CASH_EVERY_CYCLE | 0.000 | 50.000 | 75.490 | NA | 0.000 | 0.860 | 0 | 0 | 306 |
| ALWAYS_LONG_EVERY_CYCLE_WITH_FULL_COSTS | -3.000 | 50.000 | 24.510 | NA | 0.394 | 0.000 | 306 | 0 | 306 |

## Hai family đã đăng ký

Effect là method trừ baseline, đơn vị điểm phần trăm. Band đồng thời chung 20 endpoint/contrast; bridge và controls không thêm vào family để chọn kết quả thuận lợi.

| Family | Method | Baseline | Endpoint | Effect đpt | Band95% |
| --- | --- | --- | --- | ---: | --- |
| system | bayesian_v1 | original_fix | account_return_percentage_points | -0.045 | [-0.362; 0.271] |
| system | C2 | original_fix | account_return_percentage_points | -0.377 | [-0.866; 0.111] |
| system | A_tp_pool | original_fix | account_return_percentage_points | -0.367 | [-0.867; 0.133] |
| system | B_semantic | original_fix | account_return_percentage_points | -0.377 | [-0.866; 0.111] |
| system | MT_BICL | original_fix | account_return_percentage_points | -0.601 | [-1.090; -0.111] |
| method | bayesian_v1 | original_common | account_return_percentage_points | 0.327 | [0.067; 0.586] |
| method | C2 | original_common | account_return_percentage_points | -0.005 | [-0.016; 0.005] |
| method | A_tp_pool | original_common | account_return_percentage_points | 0.005 | [-0.005; 0.016] |
| method | B_semantic | original_common | account_return_percentage_points | -0.005 | [-0.016; 0.005] |
| method | MT_BICL | original_common | account_return_percentage_points | -0.229 | [-0.576; 0.118] |
| system | bayesian_v1 | original_fix | balanced_accuracy_percentage_points | -1.749 | [-6.374; 2.876] |
| system | C2 | original_fix | balanced_accuracy_percentage_points | -6.095 | [-11.629; -0.561] |
| system | A_tp_pool | original_fix | balanced_accuracy_percentage_points | -5.662 | [-11.771; 0.446] |
| system | B_semantic | original_fix | balanced_accuracy_percentage_points | -6.095 | [-11.629; -0.561] |
| system | MT_BICL | original_fix | balanced_accuracy_percentage_points | -8.675 | [-20.239; 2.888] |
| method | bayesian_v1 | original_common | balanced_accuracy_percentage_points | 4.130 | [2.011; 6.249] |
| method | C2 | original_common | balanced_accuracy_percentage_points | -0.216 | [-0.668; 0.235] |
| method | A_tp_pool | original_common | balanced_accuracy_percentage_points | 0.216 | [-0.235; 0.668] |
| method | B_semantic | original_common | balanced_accuracy_percentage_points | -0.216 | [-0.668; 0.235] |
| method | MT_BICL | original_common | balanced_accuracy_percentage_points | -2.797 | [-11.168; 5.575] |

Band status: `DESCRIPTIVE_BANDS`; joint finite 10000/10000; undefined 0.
Lý do: Đủ điều kiện band mô tả; cột SD zero: [].
Không redraw hoặc bỏ cột suy biến. SD ddof1 trên draw joint finite; higher quantile95% của max |draw−estimate|/SD, cùng PCG64 seed20261110, circular fold block L2.
Sáu fold đã exposed chỉ hỗ trợ sensitivity, không chứng nhận coverage/power hoặc p-value xác nhận.

## Bridge có dependency

| Method | Baseline | D return đpt | D BA đpt | Trùng action /306 |
| --- | --- | ---: | ---: | ---: |
| original_common | original_fix | -0.372 | -5.879 | 273 |
| Fact_Anchor | original_common | -0.262 | -3.229 | 273 |
| MT_BICL | Fact_Anchor | 0.033 | 0.433 | 302 |

Bridge là mô tả. MT so với Fact_Anchor mới tách phần revision/utility khỏi chênh lệch của anchor; không quy toàn bộ D so baseline cho student.

## Kinh tế và sensitivity

accounts.csv giữ 51×3 account cho từng vai trò/control, reset 50 triệu VND từng mã/fold/repeat; cycles.csv giữ phí/slippage/turnover và quantity fractional.
daily_nav.csv giữ đầy đủ phiên cash/held giữa hai query; EOD MTM MDD và cycle-end MDD tách riêng. Sharpe chu kỳ dùng SD ddof1; Sortino dùng RMS phần âm trên mọi cycle, MAR0; annualized=null.
results.json giữ L1/L3, leave-one-fold-out, leave-one-symbol-out và CORE4 đã định trước. Các draw duplicate fold là bản sao account reset, không nối sáu fold thành tài khoản mới.
BA/confusion được tính riêng từng repeat, mean metrics sau đó; không pool 306 forecast làm 306 mẫu thị trường độc lập. Các metric thiếu class/mẫu số zero giữ null kèm lý do.

## Coverage và provenance

Đủ 102/102 planned points và 2448/2448 active slots; không có missing-action imputation. BHN chỉ có ba fold sau, không padding thành CASH ở ba fold đầu.
prior_traces.json giữ trace dedup và predictions.csv giữ trace hash, effective K/age/similarity khi có, cùng raw proposal/veto/final. Regret không được ghi trong trace cho null với lý do.
Brier chỉ dùng numeric student/teacher đã ghi và đúng nhãn, trên eligible support; không chuyển confidence LLM thành probability, không gán probability cho fallback.
Retrieval/prior/MT ablation panels và continuous hold chưa thực thi theo protocol; CASH và ALWAYS_LONG là cycle controls cùng 102 query, không gọi continuous buy-and-hold.
Ledger giữ 1702 HTTP attempts, gồm 15 raw đã nghỉ sau reset được người dùng yêu cầu; không bỏ chi phí hoặc lấy response cũ vào active dataset.

## Giới hạn

- HISTORICAL_EXPOSED_COHORT
- NATIVE_ROWWISE_CAUSAL_FAIL
- WHOLE_SYSTEM_CAUSAL_NOT_CERTIFIED
- USER_AUTHORIZED_REPLACEMENTS_RETAINED_IN_LEDGER
- NO_SUPERIORITY_ANALYSIS_IN_U08
- ONLY_SIX_EXPOSED_TEMPORAL_CLUSTERS
- BHN_ONLY_LAST_THREE_FOLDS
- EXECUTION_VENDOR_DATA_NOT_LIVE_FILL_ACCEPTANCE

Native row-wise causal FAIL; whole-system causal NOT_CERTIFIED. Kết quả có điều kiện trên reports/prices/vendor execution assumptions, không phải kiểm chứng live fills hoặc dự báo chưa exposed.

![Hai family return](return_contrasts.svg)

Đầu ra JSON/CSV/figure có thể dùng cho U10 sau nghiệm thu; lượt này không sửa bản thảo bài báo.
